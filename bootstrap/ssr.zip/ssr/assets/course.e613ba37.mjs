import { useState, Fragment } from "react";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeader } from "./pageheader.c3637c95.mjs";
import { a as jsxs, j as jsx, F as Fragment$1 } from "../ssr.mjs";
import { Container } from "react-bootstrap";
import { a as img3, i as img4 } from "./Hermant-kumar.bd7eb8f5.mjs";
import { F as Fullstack } from "./fullstack-2.a4f71d98.mjs";
import { F as Flutter } from "./Flutter-App-development.33b56beb.mjs";
import { O as OffCanvasExample } from "./DropBottom.c156e3a4.mjs";
import Form from "react-bootstrap/Form";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
import { L as Logo } from "./logo.d6c74f57.mjs";
/* empty css                   *//* empty css                     */import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
import "react-bootstrap/Button";
import "react-bootstrap/Offcanvas";
/* empty css                 */const SkillSelect = ({
  select
}) => {
  return /* @__PURE__ */ jsxs("select", {
    defaultValue: select,
    children: [/* @__PURE__ */ jsx("option", {
      value: "all",
      children: "All Skills"
    }), /* @__PURE__ */ jsx("option", {
      value: "html",
      children: "HTML"
    }), /* @__PURE__ */ jsx("option", {
      value: "css",
      children: "CSS"
    }), /* @__PURE__ */ jsx("option", {
      value: "php",
      children: "PHP"
    }), /* @__PURE__ */ jsx("option", {
      value: "java",
      children: "JAVA"
    }), /* @__PURE__ */ jsx("option", {
      value: "javascript",
      children: "JAVASCRIPT"
    }), /* @__PURE__ */ jsx("option", {
      value: "wordpress",
      children: "WORDPRESS"
    }), /* @__PURE__ */ jsx("option", {
      value: "react",
      children: "REACT"
    }), /* @__PURE__ */ jsx("option", {
      value: "vue",
      children: "VUE"
    }), /* @__PURE__ */ jsx("option", {
      value: "angular",
      children: "ANGULAR"
    })]
  });
};
const CoursePage = () => {
  const {
    flash,
    programs,
    flutter,
    fullstack
  } = usePage().props;
  const longEnUsFormatter = new Intl.DateTimeFormat("en-GB", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const courseList = [
    {
      imgUrl: Fullstack,
      imgAlt: "course vereda vereda",
      price: "$30",
      cate: "Web Development",
      reviewCount: "03 reviews",
      title: "Full Stack Web Development Program",
      totalLeson: "26 week lessons",
      schdule: longEnUsFormatter.format(new Date(`${fullstack.starts}`)),
      authorImgUrl: img3,
      authorImgAlt: "course author vereda vereda",
      authorName: fullstack.trainerName,
      btnText: "Read More",
      coursedtl: "/Program/Full-Stack-Development-Program",
      seats: fullstack.studentsno
    },
    {
      imgUrl: Flutter,
      imgAlt: "course vereda vereda",
      price: "$30",
      cate: "Mobile Development",
      reviewCount: "03 reviews",
      title: "Flutter  Development Program",
      totalLeson: "18 weeks Lesson",
      schdule: longEnUsFormatter.format(new Date(`${flutter.starts}`)),
      authorImgUrl: img4,
      authorImgAlt: "course author vereda vereda",
      authorName: flutter.trainerName,
      btnText: "Read More",
      coursedtl: "/Program/Flutter-Development-Program",
      seats: flutter.studentsno
    }
  ];
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const [values, setValue] = useState({
    "name": "",
    "email": "",
    "phone": "",
    "country": "",
    "state": "",
    "occupation": "",
    "studies": "",
    "language": ""
  });
  const HandleChange = (e) => {
    const key = e.target.id;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/request/call", values);
  };
  const handleClose = () => setShow(false);
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: "Programs offered",
      children: [/* @__PURE__ */ jsx("meta", {
        name: "description",
        content: "Explore your preferred program, get a glance of program contents and skills you will acquire from learning"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:vereda.co.in",
        content: "https://vereda.co.in/pages/view-courses"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Contact"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Contact us by filling the form found on this page. "
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        content: "../Images/banner.jpg"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/pages/view-courses"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/pages/view-courses"
      })]
    }), /* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeader, {
      title: "Archives: Courses",
      curPage: "Course Page"
    }), /* @__PURE__ */ jsx("div", {
      className: "course-section padding-tb section-bg",
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "section-wrapper",
          children: [/* @__PURE__ */ jsx("div", {
            className: "course-showing-part",
            children: /* @__PURE__ */ jsxs("div", {
              className: "d-flex flex-wrap align-items-center justify-content-between",
              children: [/* @__PURE__ */ jsx("div", {
                className: "course-showing-part-left",
                children: /* @__PURE__ */ jsx("p", {
                  children: "Showing 1-2 of 10 results"
                })
              }), /* @__PURE__ */ jsxs("div", {
                className: "course-showing-part-right d-flex flex-wrap align-items-center",
                children: [/* @__PURE__ */ jsx("span", {
                  children: "Sort by :"
                }), /* @__PURE__ */ jsxs("div", {
                  className: "select-item",
                  children: [/* @__PURE__ */ jsx(SkillSelect, {
                    select: "all"
                  }), /* @__PURE__ */ jsx("div", {
                    className: "select-icon",
                    children: /* @__PURE__ */ jsx("i", {
                      className: "icofont-rounded-down"
                    })
                  })]
                })]
              })]
            })
          }), /* @__PURE__ */ jsxs("div", {
            className: "row g-4 justify-content-center row-cols-xl-2 row-cols-md-2 row-cols-1",
            children: [courseList.map((val, i) => /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx("div", {
                className: "course-item",
                children: /* @__PURE__ */ jsxs("div", {
                  className: "course-inner",
                  children: [/* @__PURE__ */ jsx("div", {
                    style: {
                      height: "390px"
                    },
                    className: "course-thumb",
                    children: /* @__PURE__ */ jsx("img", {
                      src: `${val.imgUrl}`,
                      alt: `${val.imgAlt}`
                    })
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "course-content",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "course-category",
                      children: /* @__PURE__ */ jsx("div", {
                        className: "course-cate",
                        children: /* @__PURE__ */ jsx("a", {
                          href: "#",
                          children: val.cate
                        })
                      })
                    }), /* @__PURE__ */ jsx(Link, {
                      href: val.coursedtl,
                      children: /* @__PURE__ */ jsx("h4", {
                        children: val.title
                      })
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "course-details",
                      children: [/* @__PURE__ */ jsxs("div", {
                        className: "couse-count",
                        children: ["  ", /* @__PURE__ */ jsxs("h4", {
                          className: "h3-bullet",
                          children: ["BATCH  ", val.seats >= 15 ? "STARTS ON" : ""]
                        }), /* @__PURE__ */ jsxs("h5", {
                          className: "h5-bullet",
                          children: [val.seats >= 15 ? val.schdule : "Coming Soon", "   "]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "couse-topic",
                        children: [/* @__PURE__ */ jsx("h4", {
                          className: "h3-bullet",
                          children: "Limited Seats"
                        }), /* @__PURE__ */ jsxs("h5", {
                          className: "h5-bullet",
                          children: [20 - val.seats, " Available"]
                        })]
                      })]
                    }), /* @__PURE__ */ jsx("div", {
                      className: "course-footer",
                      children: /* @__PURE__ */ jsx("div", {
                        className: "course-author",
                        children: /* @__PURE__ */ jsx("p", {
                          className: "ca-name",
                          children: val.authorName
                        })
                      })
                    })]
                  })]
                })
              })
            }, i)), /* @__PURE__ */ jsxs("div", {
              className: "call mt-4 mb-4",
              children: [" ", /* @__PURE__ */ jsx("button", {
                onClick: handleShow,
                className: "full-size-btn capitalize full-width-btn",
                children: "request call back"
              })]
            }), /* @__PURE__ */ jsx(OffCanvasExample, {
              show,
              onHide: handleClose,
              title: /* @__PURE__ */ jsx(Fragment$1, {
                children: /* @__PURE__ */ jsxs("div", {
                  className: "block",
                  children: [/* @__PURE__ */ jsx("h4", {
                    children: /* @__PURE__ */ jsx("a", {
                      href: "/",
                      className: "logo-anchor item-center",
                      children: /* @__PURE__ */ jsx("img", {
                        src: Logo,
                        width: "100px",
                        alt: Logo,
                        srcSet: ""
                      })
                    })
                  }), /* @__PURE__ */ jsx("h3", {
                    className: "fw-bold",
                    children: "Talk to Our Expert"
                  })]
                })
              }),
              children: /* @__PURE__ */ jsx(Fragment$1, {
                children: /* @__PURE__ */ jsx(Container, {
                  children: /* @__PURE__ */ jsxs("form", {
                    onSubmit: handleSubmit,
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      children: "Name"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      onChange: HandleChange,
                      value: values.name,
                      id: "name",
                      required: true
                    }), /* @__PURE__ */ jsx(Form.Label, {
                      children: "Email"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "email",
                      onChange: HandleChange,
                      value: values.email,
                      id: "email",
                      required: true
                    }), /* @__PURE__ */ jsx(Form.Label, {
                      children: "Phone"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "number",
                      id: "phone",
                      value: values.phone,
                      onChange: HandleChange,
                      required: true
                    }), /* @__PURE__ */ jsx(Form.Label, {
                      children: "Country"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      value: values.country,
                      id: "country",
                      onChange: HandleChange,
                      required: true
                    }), /* @__PURE__ */ jsx(Form.Label, {
                      children: "Occupation"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      id: "occupation",
                      value: values.occupation,
                      onChange: HandleChange,
                      required: true
                    }), /* @__PURE__ */ jsx(Form.Label, {
                      children: "State"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      id: "state",
                      value: values.state,
                      onChange: HandleChange,
                      required: true
                    }), /* @__PURE__ */ jsx(Form.Label, {
                      children: "Language"
                    }), /* @__PURE__ */ jsxs(Form.Select, {
                      onChange: HandleChange,
                      vlaue: values.language,
                      id: "language",
                      required: true,
                      children: [/* @__PURE__ */ jsx("option", {
                        children: "select Language"
                      }), /* @__PURE__ */ jsx("option", {
                        value: "Telugu",
                        children: "English"
                      }), /* @__PURE__ */ jsx("option", {
                        value: "Hindi",
                        children: "Hindi"
                      })]
                    }), /* @__PURE__ */ jsx(PrimaryButton, {
                      className: "mt-5",
                      children: "submit"
                    }), flash.message && /* @__PURE__ */ jsx("div", {
                      className: "alert alert-success",
                      children: "Request sent successfully"
                    })]
                  })
                })
              })
            })]
          })]
        })
      })
    }), /* @__PURE__ */ jsx(OffCanvasExample, {
      show,
      onHide: handleClose,
      title: /* @__PURE__ */ jsx(Fragment$1, {
        children: /* @__PURE__ */ jsxs("div", {
          className: "block",
          children: [/* @__PURE__ */ jsx("h4", {
            children: /* @__PURE__ */ jsx("a", {
              href: "/",
              className: "logo-anchor item-center",
              children: /* @__PURE__ */ jsx("img", {
                src: Logo,
                width: "100px",
                alt: Logo,
                srcSet: ""
              })
            })
          }), /* @__PURE__ */ jsx("h3", {
            className: "fw-bold",
            children: "Talk to Our Expert"
          })]
        })
      }),
      children: /* @__PURE__ */ jsx(Fragment$1, {
        children: /* @__PURE__ */ jsx(Container, {
          children: /* @__PURE__ */ jsxs("form", {
            onSubmit: handleSubmit,
            children: [/* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              onChange: HandleChange,
              value: values.name,
              id: "name",
              required: true,
              placeholder: "Name",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "email",
              onChange: HandleChange,
              value: values.email,
              id: "email",
              required: true,
              placeholder: "abcd@example.com ",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "number",
              id: "phone",
              value: values.phone,
              onChange: HandleChange,
              required: true,
              placeholder: "+9 9123 567 98",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              value: values.country,
              id: "country",
              onChange: HandleChange,
              required: true,
              placeholder: "Country",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "occupation",
              value: values.occupation,
              onChange: HandleChange,
              required: true,
              placeholder: "Occupation",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "state",
              value: values.state,
              onChange: HandleChange,
              required: true,
              placeholder: "State",
              className: "mt-2"
            }), /* @__PURE__ */ jsxs(Form.Select, {
              onChange: HandleChange,
              vlaue: values.language,
              id: "language",
              required: true,
              className: "mt-2",
              children: [/* @__PURE__ */ jsx("option", {
                children: "select Language"
              }), /* @__PURE__ */ jsx("option", {
                value: "Telugu",
                children: "Telugu"
              }), /* @__PURE__ */ jsx("option", {
                value: "Kannada",
                children: "Kannada"
              }), /* @__PURE__ */ jsx("option", {
                value: "Hindi",
                children: "Hindi"
              }), /* @__PURE__ */ jsx("option", {
                value: "tamil",
                children: "Tamil"
              })]
            }), /* @__PURE__ */ jsx(PrimaryButton, {
              className: "mt-5",
              children: "submit"
            }), flash.message && /* @__PURE__ */ jsx("div", {
              className: "alert alert-success",
              children: "Request sent successfully"
            })]
          })
        })
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
};
export {
  CoursePage as default
};
