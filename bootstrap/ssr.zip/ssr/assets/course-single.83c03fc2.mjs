import { Fragment } from "react";
import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeaderTwo, A as Author, C as CourseSideDetail } from "./course-detail.0fa1020d.mjs";
import { a as jsxs, j as jsx } from "../ssr.mjs";
import "@inertiajs/inertia-react";
import "react-bootstrap";
import "@inertiajs/inertia";
/* empty css                   *//* empty css                     */import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const Rating = () => {
  return /* @__PURE__ */ jsxs("span", {
    className: "ratting",
    children: [/* @__PURE__ */ jsx("i", {
      className: "icofont-ui-rating"
    }), /* @__PURE__ */ jsx("i", {
      className: "icofont-ui-rating"
    }), /* @__PURE__ */ jsx("i", {
      className: "icofont-ui-rating"
    }), /* @__PURE__ */ jsx("i", {
      className: "icofont-ui-rating"
    }), /* @__PURE__ */ jsx("i", {
      className: "icofont-ui-rating"
    })]
  });
};
const title$1 = "02 Comment";
const commentList = [{
  imgUrl: "assets/images/author/02.jpg",
  imgAlt: "speaktosameer",
  name: "Linsa Faith",
  date: "Jun 5, 2022 at 12:41 pm",
  desc: "The inner sanctuary, I throw myself down among the tall grass bye the trckli stream and, as I lie close to the earth"
}, {
  imgUrl: "assets/images/author/03.jpg",
  imgAlt: "speaktosameer",
  name: "Mahdi Mahmud",
  date: "Jun 5, 2022 at 12:41 pm",
  desc: "The inner sanctuary, I throw myself down among the tall grass bye the trckli stream and, as I lie close to the earth"
}];
const Comment = () => {
  return /* @__PURE__ */ jsxs("div", {
    className: "comments",
    children: [/* @__PURE__ */ jsx("h4", {
      className: "title-border",
      children: title$1
    }), /* @__PURE__ */ jsx("ul", {
      className: "comment-list",
      children: commentList.map((val, i) => /* @__PURE__ */ jsxs("li", {
        className: "comment",
        children: [/* @__PURE__ */ jsx("div", {
          className: "com-thumb",
          children: /* @__PURE__ */ jsx("img", {
            src: `${val.imgUrl}`,
            alt: `${val.imgAlt}`
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "com-content",
          children: [/* @__PURE__ */ jsxs("div", {
            className: "com-title",
            children: [/* @__PURE__ */ jsxs("div", {
              className: "com-title-meta",
              children: [/* @__PURE__ */ jsx("h6", {
                children: val.name
              }), /* @__PURE__ */ jsxs("span", {
                children: [" ", val.date, " "]
              })]
            }), /* @__PURE__ */ jsx(Rating, {})]
          }), /* @__PURE__ */ jsx("p", {
            children: val.desc
          })]
        })]
      }, i))
    })]
  });
};
const title = "Leave a Comment";
const btnText = "send comment";
const Respond = () => {
  return /* @__PURE__ */ jsxs("div", {
    id: "respond",
    className: "comment-respond mb-lg-0",
    children: [/* @__PURE__ */ jsx("h4", {
      className: "title-border",
      children: title
    }), /* @__PURE__ */ jsx("div", {
      className: "add-comment",
      children: /* @__PURE__ */ jsxs("form", {
        action: "#",
        method: "post",
        id: "commentform",
        className: "comment-form",
        children: [/* @__PURE__ */ jsx("input", {
          type: "text",
          name: "name",
          placeholder: "Your Name *"
        }), /* @__PURE__ */ jsx("input", {
          type: "text",
          name: "email",
          placeholder: "Your email *"
        }), /* @__PURE__ */ jsx("input", {
          type: "text",
          name: "subject",
          className: "w-100",
          placeholder: "Write a Subject"
        }), /* @__PURE__ */ jsx("textarea", {
          rows: "7",
          type: "text",
          name: "message",
          placeholder: "Your Message"
        }), /* @__PURE__ */ jsx("button", {
          type: "submit",
          className: "lab-btn",
          children: /* @__PURE__ */ jsx("span", {
            children: btnText
          })
        })]
      })
    })]
  });
};
const CourseSingle = () => {
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeaderTwo, {}), /* @__PURE__ */ jsx("div", {
      className: "course-single-section padding-tb section-bg",
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "row justify-content-center",
          children: [/* @__PURE__ */ jsx("div", {
            className: "col-lg-8",
            children: /* @__PURE__ */ jsxs("div", {
              className: "main-part",
              children: [/* @__PURE__ */ jsx("div", {
                className: "course-item",
                children: /* @__PURE__ */ jsx("div", {
                  className: "course-inner",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "course-content",
                    children: [/* @__PURE__ */ jsx("h3", {
                      children: "Course Overview"
                    }), /* @__PURE__ */ jsx("p", {
                      children: "In this course take you from the fundamentals and concepts of data modeling all the way through anumber of best practices and techniques that you\u2019ll need to build data models in your organization. You\u2019ll find many By the end of the course, you\u2019ll be all set to not only put these principles to works but also to maike the key data modeling and design decisions required by the info data modeling that transcend the nuts-and-bolts that clearly the key covered the course and design patterns."
                    }), /* @__PURE__ */ jsx("h4", {
                      children: "What You'll Learn in This Course:"
                    }), /* @__PURE__ */ jsxs("ul", {
                      className: "lab-ul",
                      children: [/* @__PURE__ */ jsxs("li", {
                        children: [/* @__PURE__ */ jsx("i", {
                          className: "icofont-tick-mark"
                        }), "Ready to begin working on real-world data modeling projects"]
                      }), /* @__PURE__ */ jsxs("li", {
                        children: [/* @__PURE__ */ jsx("i", {
                          className: "icofont-tick-mark"
                        }), "Expanded responsibilities as part of an existing role"]
                      }), /* @__PURE__ */ jsxs("li", {
                        children: [/* @__PURE__ */ jsx("i", {
                          className: "icofont-tick-mark"
                        }), "Be able to create Flyers, Brochures, Advertisements"]
                      }), /* @__PURE__ */ jsxs("li", {
                        children: [/* @__PURE__ */ jsx("i", {
                          className: "icofont-tick-mark"
                        }), "Find a new position involving data modeling."]
                      }), /* @__PURE__ */ jsxs("li", {
                        children: [/* @__PURE__ */ jsx("i", {
                          className: "icofont-tick-mark"
                        }), "Work with color and Gradients and Grids"]
                      })]
                    }), /* @__PURE__ */ jsx("p", {
                      children: "In this course take you from the fundamentals and concepts of data modeling all the way through anumber  of best practices and techniques that you\u2019ll need to build data models in your organization. You\u2019ll find many examples that clearly the key covered the course"
                    }), /* @__PURE__ */ jsx("p", {
                      children: "By the end of the course, you\u2019ll be all set to not only put these principles to works but also to maike the key data modeling and design decisions required by the info data modeling that transcend the nuts-and-bolts that clearly the key covered the course and design patterns."
                    })]
                  })
                })
              }), /* @__PURE__ */ jsxs("div", {
                className: "course-video",
                children: [/* @__PURE__ */ jsx("div", {
                  className: "course-video-title",
                  children: /* @__PURE__ */ jsx("h4", {
                    children: "Course Content"
                  })
                }), /* @__PURE__ */ jsx("div", {
                  className: "course-video-content",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "accordion",
                    id: "accordionExample",
                    children: [/* @__PURE__ */ jsxs("div", {
                      className: "accordion-item",
                      children: [/* @__PURE__ */ jsx("div", {
                        className: "accordion-header",
                        id: "accordion01",
                        children: /* @__PURE__ */ jsxs("button", {
                          className: "d-flex flex-wrap justify-content-between",
                          "data-bs-toggle": "collapse",
                          "data-bs-target": "#videolist1",
                          "aria-expanded": "true",
                          "aria-controls": "videolist1",
                          children: [/* @__PURE__ */ jsx("span", {
                            children: "1.Introduction"
                          }), " ", /* @__PURE__ */ jsx("span", {
                            children: "5lessons, 17:37"
                          }), " "]
                        })
                      }), /* @__PURE__ */ jsx("div", {
                        id: "videolist1",
                        className: "accordion-collapse collapse show",
                        "aria-labelledby": "accordion01",
                        "data-bs-parent": "#accordionExample",
                        children: /* @__PURE__ */ jsxs("ul", {
                          className: "lab-ul video-item-list",
                          children: [/* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "1.1 Welcome to the course 02:30 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "1.2 How to set up your photoshop workspace  08:33 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "1.3 Essential Photoshop Tools 03:38 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "1.4 Finding inspiration 02:30 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "1.5 Choosing Your Format 03:48 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          })]
                        })
                      })]
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "accordion-item",
                      children: [/* @__PURE__ */ jsx("div", {
                        className: "accordion-header",
                        id: "accordion02",
                        children: /* @__PURE__ */ jsxs("button", {
                          className: "d-flex flex-wrap justify-content-between",
                          "data-bs-toggle": "collapse",
                          "data-bs-target": "#videolist2",
                          "aria-expanded": "true",
                          "aria-controls": "videolist2",
                          children: [" ", /* @__PURE__ */ jsx("span", {
                            children: "2.How to Create Mixed Media Art in Adobe Photoshop"
                          }), " ", /* @__PURE__ */ jsx("span", {
                            children: "5 lessons, 52:15"
                          }), " "]
                        })
                      }), /* @__PURE__ */ jsx("div", {
                        id: "videolist2",
                        className: "accordion-collapse collapse",
                        "aria-labelledby": "accordion02",
                        "data-bs-parent": "#accordionExample",
                        children: /* @__PURE__ */ jsxs("ul", {
                          className: "lab-ul video-item-list",
                          children: [/* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "2.1 Using Adjustment Layers 06:20 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "2.2 Building the composition 07:33 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "2.3 Photoshop Lighting effects 06:30 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "2.4 Digital Painting using photoshop brushes 08:34 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          }), /* @__PURE__ */ jsxs("li", {
                            className: " d-flex flex-wrap justify-content-between",
                            children: [/* @__PURE__ */ jsx("div", {
                              className: "video-item-title",
                              children: "2.5 Finalizing the details 10:30 minutes"
                            }), /* @__PURE__ */ jsx("div", {
                              className: "video-item-icon",
                              children: /* @__PURE__ */ jsx("a", {
                                href: "https://www.youtube.com/embed/MU3qrgR2Kkc",
                                className: "popup",
                                target: "_blank",
                                children: /* @__PURE__ */ jsx("i", {
                                  className: "icofont-play-alt-2"
                                })
                              })
                            })]
                          })]
                        })
                      })]
                    })]
                  })
                })]
              }), /* @__PURE__ */ jsx(Author, {}), /* @__PURE__ */ jsx(Comment, {}), /* @__PURE__ */ jsx(Respond, {})]
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "col-lg-4",
            children: /* @__PURE__ */ jsx("div", {
              className: "sidebar-part",
              children: /* @__PURE__ */ jsx(CourseSideDetail, {})
            })
          })]
        })
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
};
export {
  CourseSingle as default
};
