import React from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
/* empty css                 */import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import { Divider } from "@mui/material";
import { Col, CloseButton } from "react-bootstrap";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import { Inertia } from "@inertiajs/inertia";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function HandlingBatch(props) {
  const {
    assignments,
    students,
    current_class
  } = usePage().props;
  const HandleConfirmAll = (e) => {
    e.preventDefault();
    Inertia.post("Moderator/cofirmAllAttendance", {
      "batch": current_class.topic.batch
    });
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Moderator Page / Class"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "My CLass"
        })]
      }),
      childs: /* @__PURE__ */ jsx(Fragment, {}),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Full Stack Developement"
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsx("div", {
            className: "overflow-hidden p-2 flex header-block",
            children: students.map((items, index) => {
              return /* @__PURE__ */ jsxs(Card, {
                className: "col-lg-6 col-md-12 col-sm-12 m-3",
                variant: "outlined",
                children: [/* @__PURE__ */ jsxs(CardContent, {
                  children: [/* @__PURE__ */ jsx(Typography, {
                    sx: {
                      fontSize: 14
                    },
                    color: "text.secondary",
                    gutterBottom: true,
                    children: "Program Name"
                  }), /* @__PURE__ */ jsx(Typography, {
                    variant: "h5",
                    component: "div",
                    children: items.name
                  }), /* @__PURE__ */ jsxs(Typography, {
                    sx: {
                      mb: 1.5
                    },
                    color: "text.secondary",
                    children: [/* @__PURE__ */ jsx("b", {
                      children: "by"
                    }), "  ", items.trainerName]
                  }), /* @__PURE__ */ jsxs(Typography, {
                    variant: "body2",
                    children: ["Started", /* @__PURE__ */ jsx("br", {}), new Date(`${items.starts}`).toLocaleDateString()]
                  }), /* @__PURE__ */ jsxs(Typography, {
                    variant: "body2",
                    children: ["Ends", /* @__PURE__ */ jsx("br", {}), new Date(`${items.ends}`).toLocaleDateString()]
                  }), /* @__PURE__ */ jsxs(Typography, {
                    variant: "body2",
                    children: ["Batch", /* @__PURE__ */ jsx("br", {}), items.id]
                  })]
                }), /* @__PURE__ */ jsx(CardActions, {
                  children: /* @__PURE__ */ jsx(Button, {
                    size: "small",
                    children: /* @__PURE__ */ jsx(Link, {
                      href: `/Moderator/view-students/${items.id}`,
                      children: "View Students"
                    })
                  })
                })]
              }, index);
            })
          })
        })
      }), /* @__PURE__ */ jsx(Divider, {}), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsxs("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: [/* @__PURE__ */ jsxs("h2", {
            className: "fs-4 fw-bold mb-4",
            children: [" fixed date is ", /* @__PURE__ */ jsx("span", {
              className: "text-color-dark-blue",
              children: new Date(`${current_class.topic.date}`).toLocaleDateString()
            })]
          }), /* @__PURE__ */ jsxs("div", {
            className: "overflow-hidden bg-white p-2 flex header-block",
            children: [/* @__PURE__ */ jsxs(Col, {
              lg: "5",
              md: "12",
              sm: "12",
              className: "text-center p-5",
              children: [/* @__PURE__ */ jsx("h3", {
                className: "fw-bold text-color-dark-blue",
                children: "BATCH "
              }), /* @__PURE__ */ jsx("h1", {
                className: "fw-bolder  text-color-dark-blue",
                children: current_class.topic.batch
              }), /* @__PURE__ */ jsx("h6", {
                className: "fw-bold",
                children: current_class.topic.sessiontype == "video" && "Live Class" || current_class.topic.sessiontype == "book" && "Study session." || current_class.topic.sessiontype == "test" || "Quiz"
              }), /* @__PURE__ */ jsxs("h6", {
                className: "",
                children: ["topic -- ", /* @__PURE__ */ jsx("span", {
                  className: "fw-bold",
                  children: current_class.topic.topic
                })]
              })]
            }), /* @__PURE__ */ jsxs(Col, {
              lg: "7",
              children: [/* @__PURE__ */ jsx("h3", {
                className: "fs-5 fw-bold text-color-dark-blue m-5 p-3",
                children: "Class Attendance"
              }), /* @__PURE__ */ jsx(List, {
                sx: {
                  width: "100%",
                  maxWidth: 360,
                  bgcolor: "background.paper"
                },
                children: current_class.student.length > 0 ? current_class.student.map((data, index) => {
                  return /* @__PURE__ */ jsxs(ListItem, {
                    alignItems: "flex-start",
                    children: [/* @__PURE__ */ jsx(ListItemAvatar, {
                      children: /* @__PURE__ */ jsx(Avatar, {
                        alt: data.name,
                        src: `../../../storage/jpg/${data.avatar}`
                      })
                    }), /* @__PURE__ */ jsx(ListItemText, {
                      primary: `${data.name}`,
                      secondary: /* @__PURE__ */ jsxs(React.Fragment, {
                        children: [/* @__PURE__ */ jsx(Typography, {
                          sx: {
                            display: "inline"
                          },
                          component: "span",
                          variant: "body2",
                          color: "text.primary",
                          className: "fw-bold",
                          children: new Date(`${data.joined}`).toLocaleTimeString() + " \u2014 "
                        }), /* @__PURE__ */ jsx("button", {
                          children: /* @__PURE__ */ jsxs(Link, {
                            href: `/attendance-cancel/${data.id}/topic/${data.TopicId}`,
                            method: "POST",
                            children: [" cancel attendance ", /* @__PURE__ */ jsx(CloseButton, {
                              style: {
                                fontSize: "10px"
                              }
                            })]
                          })
                        })]
                      })
                    })]
                  }, index);
                }) : "No Student Yet"
              }), current_class.student.length > 0 && /* @__PURE__ */ jsx("div", {
                onClick: HandleConfirmAll,
                style: {
                  cursor: "pointer"
                },
                className: "rounded-full text-center p-3 text-color-white bg-primaries",
                children: "End Class and Confirm all attendance"
              })]
            })]
          })]
        })
      })]
    })
  });
}
export {
  HandlingBatch as default
};
