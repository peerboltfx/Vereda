import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { Row, Col } from "react-bootstrap";
/* empty css                 */import "dompurify";
import { Book } from "react-bootstrap-icons";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Dashboard(props) {
  const {
    programs,
    profile,
    auth,
    myprogram,
    program_links
  } = usePage().props;
  const [values, setValues] = useState({
    "search": ""
  });
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const found = program_links.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(values.search)));
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: profile ? profile.firstname + " " + profile.lastname : auth.user.name
      }), /* @__PURE__ */ jsxs("h3", {
        className: "fs-4 text-color-blue",
        children: [" ", auth.user.role, " "]
      })]
    }),
    Search: /* @__PURE__ */ jsxs("div", {
      className: "Search-container",
      children: [/* @__PURE__ */ jsx("input", {
        onClick: HandleShow,
        type: "text",
        name: "search",
        value: values.search,
        onChange: HandleChange
      }), /* @__PURE__ */ jsxs("div", {
        onBlur: () => setShow(false),
        tabIndex: "0",
        style: {
          height: "400px",
          overflowY: "scroll"
        },
        className: show ? "Searched bg-white active p-2" : "Searched",
        children: [/* @__PURE__ */ jsx("h6", {
          className: "fw-bold text-color-dark-blue text-center",
          children: "Search Course"
        }), found.map((data, index) => {
          return /* @__PURE__ */ jsx("div", {
            className: "bg-white pt-2 mt-1 pb-2 pl-4 shadow-sm sm:rounded-lg",
            children: /* @__PURE__ */ jsx(Row, {
              children: /* @__PURE__ */ jsx(Col, {
                mx: "6",
                children: /* @__PURE__ */ jsx(Link, {
                  href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                  className: "text-color-dark-blue",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "flex pb-3",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "6",
                      className: "pt-0 ",
                      children: /* @__PURE__ */ jsx(Book, {
                        style: {
                          fontSize: "30px",
                          color: "#DC4731"
                        },
                        className: "pl-1"
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      className: "fs-5 fw-bold pl-0 ml-4 text-color-dark-blue",
                      children: data.program
                    })]
                  })
                })
              })
            })
          }, index);
        })]
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: auth.user.name
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "  sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: " overflow-hidden  sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 border-gray-200 profiles-style",
            children: /* @__PURE__ */ jsx(Row, {
              className: "header-block",
              children: /* @__PURE__ */ jsxs(Col, {
                mx: "6",
                children: [/* @__PURE__ */ jsx("h1", {
                  children: "Personal Information"
                }), /* @__PURE__ */ jsxs("ul", {
                  children: [/* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "User Name"
                    }), auth.user.name]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "Full Name :"
                    }), profile ? profile.firstname + " " + profile.lastname : ""]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "Country :"
                    }), profile ? profile.country : ""]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "Gender :"
                    }), profile ? profile.gender : ""]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "DoB :"
                    }), profile ? profile.birthDate : ""]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "Phone :"
                    }), profile ? profile.phone : auth.user.phone]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "Address :"
                    }), profile ? profile.address : auth.user.phone]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "Parent Name :"
                    }), profile ? profile.parentName : auth.user.phone]
                  }), /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("span", {
                      className: "fw-bold mr-5",
                      children: "Desire :"
                    }), profile ? profile.desire : auth.user.phone]
                  })]
                })]
              })
            })
          })
        })
      })
    })]
  });
}
export {
  Dashboard as default
};
