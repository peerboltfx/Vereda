import { useState, useEffect } from "react";
import { C as Checkbox } from "./Checkbox.8dcffd6f.mjs";
import { G as Guest } from "./GuestLayout.05f8bf09.mjs";
import { I as InputError } from "./InputError.2782cac0.mjs";
import { I as InputLabel } from "./InputLabel.4e3bf89c.mjs";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { T as TextInput } from "./TextInput.baa9891c.mjs";
import { useForm, Head, Link } from "@inertiajs/inertia-react";
import { Col, Tabs, Tab, Alert, InputGroup, Form, Spinner } from "react-bootstrap";
import { A as ApplicationLogo } from "./ApplicationLogo.c9284209.mjs";
import axios from "axios";
import { Inertia } from "@inertiajs/inertia";
import { s as signup } from "./sign-up-vector.e1bc22e5.mjs";
import { a as jsxs, j as jsx } from "../ssr.mjs";
/* empty css                 */import "./logo.d6c74f57.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const Vector = "/build/assets/vector-sign-in.16f6ff16.webp";
function Login({
  status,
  canResetPassword
}) {
  const {
    data,
    setData,
    post,
    processing,
    errors,
    reset
  } = useForm({
    email: "",
    password: "",
    remember: "",
    phone: "",
    otp: ""
  });
  const [key, setKey] = useState("OTP");
  const [showAlert, setAlert] = useState(false);
  const [handleLoad, setHandleLoad] = useState(false);
  const [messaging, setMessaging] = useState(null);
  const [counter, setCounter] = useState(null);
  useEffect(() => {
    return () => {
      reset("password");
    };
  }, []);
  const onHandleChange = (event) => {
    setData(event.target.name, event.target.type === "checkbox" ? event.target.checked : event.target.value);
  };
  const submit = (e) => {
    e.preventDefault();
    post(route("login"));
  };
  const submitotp = (e) => {
    e.preventDefault();
    Inertia.post("/login/confirm-otp", {
      "phone": data.phone,
      "otp": data.otp
    });
  };
  useEffect(() => {
    const timer = counter > 0 && setInterval(() => setCounter(counter - 1), 1e3);
    return () => {
      clearInterval(timer);
    };
  }, [counter]);
  const NewOTP = (e) => {
    e.preventDefault();
    setHandleLoad(true);
    axios.post("/login/request-otp", {
      "phoneNo": data.phone
    }).then((res) => {
      if (res.data == "We have sent otp to your number, valid for 2 minutes") {
        setAlert("success");
        setVerify(true);
        setCounter(40);
        setMessaging(res.data);
        setHandleLoad(false);
      } else {
        setAlert("success");
        setMessaging(res.data);
        setHandleLoad(false);
      }
    }).catch((err) => {
      console.log(err);
      setHandleLoad(false);
      setAlert("failed");
      setMessaging("Error processing file, try Again");
    });
  };
  return /* @__PURE__ */ jsxs(Guest, {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: "Log in",
      children: [/* @__PURE__ */ jsx("meta", {
        property: "og:vereda.co.in",
        content: "https://vereda.co.in/login"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Login into your account to continue your studies.  "
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Login"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Login into your account to continue your studies. "
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        itemProp: "image",
        content: signup
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/login"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/login"
      })]
    }), status && /* @__PURE__ */ jsx("div", {
      className: "mb-4 font-medium text-sm text-green-600",
      children: status
    }), /* @__PURE__ */ jsx(Col, {
      md: "6",
      children: /* @__PURE__ */ jsxs("div", {
        className: "min-h-screen flex flex-col p-3 pt-6 sm:pt-0 bg-gray-100",
        children: [/* @__PURE__ */ jsx("div", {
          className: "mt-20 desktop-hide flex flex-col items-center",
          children: /* @__PURE__ */ jsx(Link, {
            href: "/",
            children: /* @__PURE__ */ jsx(ApplicationLogo, {
              width: "190px",
              className: "w-20 h-20 fill-current text-gray-500"
            })
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "",
          children: [/* @__PURE__ */ jsx("div", {
            className: "desktop-hide w-80 ",
            children: /* @__PURE__ */ jsx("img", {
              src: Vector
            })
          }), /* @__PURE__ */ jsx("h4", {
            className: "fw-bold mt-5 capitalize",
            children: "Get started"
          }), /* @__PURE__ */ jsxs("p", {
            className: "fw-bold fs-6 capitalize",
            children: ["Dont have an account? ", /* @__PURE__ */ jsx(Link, {
              href: "/register",
              className: "",
              children: /* @__PURE__ */ jsx("span", {
                className: "text-blue-sm capitalize",
                children: "click here"
              })
            })]
          })]
        }), /* @__PURE__ */ jsxs(Tabs, {
          id: "justify-tab-example",
          activeKey: key,
          onSelect: (k) => setKey(k),
          className: "mb-3 mr-5 ml-0 bg-white shadow-sm sm:rounded-lg pt-2 pb-2",
          justify: true,
          children: [/* @__PURE__ */ jsx(Tab, {
            eventKey: "OTP",
            title: "OTP Login",
            children: /* @__PURE__ */ jsx("div", {
              className: "w-full mt-6 overflow-hidden sm:rounded-lg",
              children: /* @__PURE__ */ jsxs("form", {
                onSubmit: submitotp,
                className: "w-100 flex items-center flex-col",
                children: [showAlert == "success" && /* @__PURE__ */ jsxs(Alert, {
                  variant: "",
                  children: [messaging + " ", /* @__PURE__ */ jsx("span", {
                    className: "fw-bold"
                  }), " "]
                }), showAlert == "failed" && /* @__PURE__ */ jsx(Alert, {
                  variant: "danger",
                  children: messaging
                }), /* @__PURE__ */ jsxs("div", {
                  className: "mt-6 px-6 py-4 bg-white login-tab shadow-md overflow-hidden sm:rounded-lg",
                  children: [/* @__PURE__ */ jsxs("div", {
                    children: [/* @__PURE__ */ jsx(InputLabel, {
                      forInput: "phone",
                      value: "Phone"
                    }), /* @__PURE__ */ jsxs(InputGroup, {
                      className: "mb-3",
                      children: [/* @__PURE__ */ jsx(InputGroup.Text, {
                        children: "+91"
                      }), /* @__PURE__ */ jsx(Form.Control, {
                        type: "text",
                        name: "phone",
                        value: data.phone,
                        onChange: onHandleChange
                      }), /* @__PURE__ */ jsx(InputError, {
                        message: errors.phone,
                        className: "mt-2"
                      })]
                    })]
                  }), /* @__PURE__ */ jsx("div", {
                    className: "mt-4",
                    children: /* @__PURE__ */ jsxs(InputGroup, {
                      className: "mb-3",
                      children: [/* @__PURE__ */ jsx(Form.Control, {
                        type: "text",
                        name: "otp",
                        value: data.otp,
                        onChange: onHandleChange
                      }), /* @__PURE__ */ jsx("button", {
                        onClick: NewOTP,
                        className: data.phone.length < 10 ? "disabled bg-primaries sm:rounded-full text-color-white pl-4 pr-4 " : "bg-primaries sm:rounded-full text-color-white ",
                        children: handleLoad ? /* @__PURE__ */ jsx("span", {
                          className: "mr-5 ml-5",
                          children: /* @__PURE__ */ jsx(Spinner, {
                            animation: "border",
                            size: "sm",
                            className: "ml-5 mr-5",
                            role: "status"
                          })
                        }) : "get otp"
                      })]
                    })
                  })]
                }), /* @__PURE__ */ jsx("div", {
                  className: "block items-center w-80 justify-end mt-10 mb-5",
                  children: /* @__PURE__ */ jsx(PrimaryButton, {
                    processing,
                    children: "Verify OTP"
                  })
                })]
              })
            })
          }), /* @__PURE__ */ jsx(Tab, {
            eventKey: "Email",
            title: "Email Login",
            children: /* @__PURE__ */ jsx("div", {
              className: "w-full mt-6 overflow-hidden sm:rounded-lg",
              children: /* @__PURE__ */ jsxs("form", {
                onSubmit: submit,
                className: "w-100 flex items-center flex-col",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "mt-6 px-6 py-4 bg-white  login-tab shadow-md overflow-hidden sm:rounded-lg",
                  children: [/* @__PURE__ */ jsxs("div", {
                    children: [/* @__PURE__ */ jsx(InputLabel, {
                      forInput: "email",
                      value: "Email"
                    }), /* @__PURE__ */ jsx(TextInput, {
                      type: "text",
                      name: "email",
                      value: data.email,
                      className: "mt-1 block w-full",
                      autoComplete: "username",
                      isFocused: true,
                      handleChange: onHandleChange
                    }), /* @__PURE__ */ jsx(InputError, {
                      message: errors.email,
                      className: "mt-2"
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-4",
                    children: [/* @__PURE__ */ jsx(InputLabel, {
                      forInput: "password",
                      value: "Password"
                    }), /* @__PURE__ */ jsx(TextInput, {
                      type: "password",
                      name: "password",
                      value: data.password,
                      className: "mt-1 block w-full",
                      autoComplete: "current-password",
                      handleChange: onHandleChange
                    }), /* @__PURE__ */ jsx(InputError, {
                      message: errors.password,
                      className: "mt-2"
                    })]
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "block items-center justify-end mt-10 mb-5",
                  children: [canResetPassword && /* @__PURE__ */ jsx(Link, {
                    href: route("password.request"),
                    className: "underline text-sm float-right mr-2 text-blue-sm hover:text-gray-900",
                    children: "Forgot your password?"
                  }), /* @__PURE__ */ jsxs("label", {
                    className: "flex float-left",
                    children: [/* @__PURE__ */ jsx(Checkbox, {
                      name: "remember",
                      value: data.remember,
                      handleChange: onHandleChange
                    }), /* @__PURE__ */ jsx("span", {
                      className: "ml-2 mb-4 text-sm text-gray-600",
                      children: "Remember me"
                    })]
                  }), /* @__PURE__ */ jsx(PrimaryButton, {
                    processing,
                    children: "Log in"
                  })]
                })]
              })
            })
          })]
        })]
      })
    }), /* @__PURE__ */ jsx(Col, {
      md: "6",
      children: /* @__PURE__ */ jsxs("div", {
        className: "min-h-screen mobile-hide flex flex-col sm:justify-center item-center pt-6 sm:pt-0",
        children: [/* @__PURE__ */ jsx("div", {
          className: "mt-20 ml-auto mr-auto",
          children: /* @__PURE__ */ jsx(Link, {
            href: "/",
            children: /* @__PURE__ */ jsx(ApplicationLogo, {
              width: "250px",
              className: "w-20 h-20 fill-current text-gray-500"
            })
          })
        }), /* @__PURE__ */ jsx("div", {
          style: {
            width: "70%"
          },
          className: "ml-auto mr-auto",
          children: /* @__PURE__ */ jsx("img", {
            src: Vector
          })
        })]
      })
    })]
  });
}
export {
  Login as default
};
