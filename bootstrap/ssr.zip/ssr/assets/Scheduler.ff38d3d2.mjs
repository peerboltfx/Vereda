import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
import { Row, Col, Form, CloseButton } from "react-bootstrap";
/* empty css                 */import { Inertia } from "@inertiajs/inertia";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import Alert from "react-bootstrap/Alert";
import { Editor } from "react-draft-wysiwyg";
import { EditorState } from "draft-js";
import { convertToHTML } from "draft-convert";
/* empty css                               */import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function FullStackSession(props) {
  const {
    flash,
    batch,
    program
  } = usePage().props;
  const [show, setShow] = useState(true);
  const [values, setValues] = useState({
    "date": "",
    "topic": "",
    "sessiontype": "",
    "batch": "",
    "programs_code": "",
    "assignment": "",
    "about": "",
    "links": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const [editorState, setEditorState] = useState(() => EditorState.createEmpty());
  const [convertedContent, setConvertedContent] = useState(null);
  const HandleEditorChange = (state) => {
    setEditorState(state);
    convertContentToHTML();
  };
  const convertContentToHTML = () => {
    let currentContentAsHTML = convertToHTML(editorState.getCurrentContent());
    setConvertedContent(currentContentAsHTML);
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/create/schedule-daily-plan", {
      "first": values,
      "second": convertedContent
    });
  };
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Moderator Page"
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-4 text-color-blue",
        children: "Daily Plan Scheduling"
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Moderator / Scheduler"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsxs("div", {
            className: "p-6 border-b border-gray-200",
            children: [/* @__PURE__ */ jsxs("form", {
              onSubmit: HandleSubmit,
              method: "POST",
              children: [/* @__PURE__ */ jsxs(Row, {
                className: "header-block",
                children: [/* @__PURE__ */ jsxs(Col, {
                  children: [/* @__PURE__ */ jsx(Form.Label, {
                    children: "Description Content."
                  }), /* @__PURE__ */ jsx(Editor, {
                    editorState,
                    onEditorStateChange: HandleEditorChange,
                    toolbarClassName: "toolbar-class",
                    wrapperClassName: "wrapper-class",
                    editorClassName: "editor-class",
                    name: "description"
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-2",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      children: "Assignment."
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      as: "textarea",
                      name: "assignment",
                      value: values.assignment,
                      onChange: HandleChange
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-2",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      children: "Google Meet Link"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      placeholder: "Normal text",
                      name: "links",
                      onChange: HandleChange,
                      value: values.links
                    })]
                  })]
                }), /* @__PURE__ */ jsxs(Col, {
                  children: [/* @__PURE__ */ jsxs("div", {
                    className: "mt-2",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      children: "Topic"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      placeholder: "Normal text",
                      name: "topic",
                      onChange: HandleChange,
                      value: values.topic,
                      required: true
                    })]
                  }), /* @__PURE__ */ jsx("div", {
                    className: "mt-2 row",
                    children: /* @__PURE__ */ jsxs(Col, {
                      children: [/* @__PURE__ */ jsx(Form.Label, {
                        children: "Schedule Date and Time"
                      }), /* @__PURE__ */ jsx(Form.Control, {
                        type: "datetime-local",
                        onChange: HandleChange,
                        value: values.date,
                        name: "date",
                        required: true
                      })]
                    })
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-2 row",
                    children: [/* @__PURE__ */ jsxs(Col, {
                      children: [/* @__PURE__ */ jsx(Form.Label, {
                        children: "Session type"
                      }), /* @__PURE__ */ jsxs(Form.Select, {
                        value: values.sessiontype,
                        size: "sm",
                        required: true,
                        onChange: HandleChange,
                        name: "sessiontype",
                        children: [/* @__PURE__ */ jsx("option", {
                          value: "",
                          children: "Select session type"
                        }), /* @__PURE__ */ jsx("option", {
                          value: "video",
                          children: "Live Video session"
                        }), /* @__PURE__ */ jsx("option", {
                          value: "book",
                          children: "Study session"
                        }), /* @__PURE__ */ jsx("option", {
                          value: "test",
                          children: "Practice / test"
                        })]
                      })]
                    }), /* @__PURE__ */ jsxs(Col, {
                      children: [/* @__PURE__ */ jsx(Form.Label, {
                        children: "Batch ?"
                      }), /* @__PURE__ */ jsxs(Form.Select, {
                        value: values.batch,
                        size: "sm",
                        required: true,
                        name: "batch",
                        onChange: HandleChange,
                        children: [/* @__PURE__ */ jsx("option", {
                          children: "select batch"
                        }), batch.map((data, index) => {
                          return /* @__PURE__ */ jsxs("option", {
                            value: data.id,
                            children: ["Batch ", data.id, " "]
                          }, index);
                        })]
                      })]
                    }), /* @__PURE__ */ jsxs(Col, {
                      children: [/* @__PURE__ */ jsx(Form.Label, {
                        children: "Program ?"
                      }), /* @__PURE__ */ jsxs(Form.Select, {
                        value: values.programs_code,
                        size: "sm",
                        required: true,
                        name: "programs_code",
                        onChange: HandleChange,
                        children: [/* @__PURE__ */ jsx("option", {
                          children: "select program"
                        }), program.map((data) => {
                          return /* @__PURE__ */ jsx("option", {
                            value: data.random,
                            children: data.program
                          }, data.id);
                        })]
                      })]
                    })]
                  })]
                })]
              }), /* @__PURE__ */ jsx("div", {
                className: "pt-12 col-6",
                children: /* @__PURE__ */ jsx(PrimaryButton, {
                  children: "save"
                })
              })]
            }), flash.message && /* @__PURE__ */ jsxs(Fragment, {
              children: ["  ", /* @__PURE__ */ jsxs(Alert, {
                show,
                variant: "success",
                children: [/* @__PURE__ */ jsxs(Alert.Heading, {
                  children: ["Successful ", /* @__PURE__ */ jsx("span", {
                    style: {
                      float: "right",
                      fontSize: "15px"
                    },
                    children: /* @__PURE__ */ jsx(CloseButton, {
                      onClick: () => {
                        setShow(false);
                      }
                    })
                  })]
                }), /* @__PURE__ */ jsx("p", {
                  children: flash.message
                })]
              })]
            })]
          })
        })
      })
    })]
  });
}
export {
  FullStackSession as default
};
