import "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
import { Col, Card, Button } from "react-bootstrap";
/* empty css                 */import { QuestionCircleFill } from "react-bootstrap-icons";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Plantable(props) {
  const {
    assignments,
    flash
  } = usePage().props;
  console.log(assignments);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Admin Page / Moderator"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Moderator Table"
        })]
      }),
      childs: /* @__PURE__ */ jsx(Fragment, {}),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Full Stack Developement"
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsx("div", {
            className: "overflow-hidden p-2 shadow-sm ",
            children: assignments.map((data, index) => {
              return /* @__PURE__ */ jsx(Col, {
                md: "6",
                sm: "12",
                lg: "5",
                children: /* @__PURE__ */ jsxs(Card, {
                  className: "sm:rounded-lg bg-white",
                  children: [/* @__PURE__ */ jsxs(Card.Title, {
                    className: "p-2 capitalize",
                    children: [" ", data.topic]
                  }), /* @__PURE__ */ jsxs(Card.Header, {
                    className: "flex",
                    children: [/* @__PURE__ */ jsx("span", {
                      children: /* @__PURE__ */ jsx(QuestionCircleFill, {
                        className: "text-color-dark-blue mt-1 mr-2"
                      })
                    }), " ", data.assignment]
                  }), /* @__PURE__ */ jsx(Card.Footer, {
                    children: /* @__PURE__ */ jsx(Link, {
                      href: `/moderator/assignment-${data.id}`,
                      children: /* @__PURE__ */ jsx(Button, {
                        className: "bg-primaries w-full",
                        children: "View Progress"
                      })
                    })
                  })]
                })
              }, index);
            })
          })
        })
      })]
    })
  });
}
export {
  Plantable as default
};
