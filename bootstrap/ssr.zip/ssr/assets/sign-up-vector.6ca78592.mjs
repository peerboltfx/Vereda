const Vector = "/build/assets/sign-up-vector.db52572f.webp";
export {
  Vector as V
};
