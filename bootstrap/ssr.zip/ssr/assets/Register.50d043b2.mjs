import { useEffect } from "react";
import { G as Guest } from "./GuestLayout.05f8bf09.mjs";
import { I as InputError } from "./InputError.2782cac0.mjs";
import { I as InputLabel } from "./InputLabel.4e3bf89c.mjs";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { T as TextInput } from "./TextInput.baa9891c.mjs";
import { useForm, Head, Link } from "@inertiajs/inertia-react";
import { Col } from "react-bootstrap";
import { A as ApplicationLogo } from "./ApplicationLogo.c9284209.mjs";
import { V as Vector } from "./sign-up-vector.6ca78592.mjs";
import { PersonCircle } from "react-bootstrap-icons";
import { s as signup } from "./sign-up-vector.e1bc22e5.mjs";
import { a as jsxs, j as jsx } from "../ssr.mjs";
/* empty css                 */import "./logo.d6c74f57.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Register() {
  let referral;
  let ref_id;
  if (window.sessionStorage.getItem("referral")) {
    referral = window.sessionStorage.getItem("name");
    ref_id = window.sessionStorage.getItem("referral");
  }
  const {
    data,
    setData,
    post,
    processing,
    errors,
    reset
  } = useForm({
    name: "",
    phone: "",
    email: "",
    password: "",
    password_confirmation: "",
    referred: ref_id
  });
  useEffect(() => {
    return () => {
      reset("password", "password_confirmation");
    };
  }, []);
  const onHandleChange = (event) => {
    setData(event.target.name, event.target.type === "checkbox" ? event.target.checked : event.target.value);
  };
  const submit = (e) => {
    e.preventDefault();
    post(route("register"));
  };
  return /* @__PURE__ */ jsxs(Guest, {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: "Register",
      children: [/* @__PURE__ */ jsx("meta", {
        property: "og:vereda.co.in",
        content: "https://vereda.co.in/register"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Register a free account in vereda digital and start studying at your own comfort. "
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Register"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Register a free account in vereda digital and start studying at your own comfort."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        itemProp: "image",
        content: signup
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/register"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/register"
      })]
    }), status && /* @__PURE__ */ jsx("div", {
      className: "mb-4 font-medium text-sm text-green-600",
      children: status
    }), /* @__PURE__ */ jsxs(Col, {
      md: "6",
      children: [referral && /* @__PURE__ */ jsxs("button", {
        style: {
          position: "relative",
          top: "10px",
          left: "10px"
        },
        className: "text-color-white  mobile-hide shadow rounded-full pl-5 pb-1 pt-1 pr-5 bg-primary flex",
        children: [/* @__PURE__ */ jsx("span", {
          className: "mr-3 mt-1",
          children: /* @__PURE__ */ jsx(PersonCircle, {
            className: "text-color-white  fw-bold"
          })
        }), " ", referral]
      }), /* @__PURE__ */ jsxs("div", {
        className: "min-h-screen mobile-hide flex flex-col sm:justify-center item-center pt-6 sm:pt-0",
        children: [/* @__PURE__ */ jsx("div", {
          className: "mt-10 ml-auto mr-auto",
          children: /* @__PURE__ */ jsx(Link, {
            href: "/",
            children: /* @__PURE__ */ jsx(ApplicationLogo, {
              width: "250px",
              className: "w-20 h-20 fill-current text-gray-500"
            })
          })
        }), /* @__PURE__ */ jsx("div", {
          style: {
            width: "70%"
          },
          className: "ml-auto mr-auto",
          children: /* @__PURE__ */ jsx("img", {
            src: Vector
          })
        })]
      })]
    }), /* @__PURE__ */ jsx(Col, {
      md: "6",
      children: /* @__PURE__ */ jsxs("div", {
        className: "min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100",
        children: [/* @__PURE__ */ jsx("div", {
          className: "desktop-hide mt-10 ml-auto mr-auto",
          children: /* @__PURE__ */ jsx(Link, {
            href: "/",
            children: /* @__PURE__ */ jsx(ApplicationLogo, {
              width: "190px",
              className: "w-20 h-20 fill-current text-gray-500"
            })
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "",
          children: [/* @__PURE__ */ jsx("div", {
            className: "ml-auto desktop-hide w-80 mr-auto",
            children: /* @__PURE__ */ jsx("img", {
              src: Vector
            })
          }), /* @__PURE__ */ jsx("h4", {
            className: "fw-bold ml-auto capitalize  mt-4",
            children: "Get started"
          }), /* @__PURE__ */ jsxs("p", {
            className: "fs-6 fw-bold Capitalize",
            children: ["Already Have an account? ", /* @__PURE__ */ jsx(Link, {
              href: route("login"),
              className: "",
              children: /* @__PURE__ */ jsx("span", {
                className: "text-blue-sm capitalize",
                children: "sign in"
              })
            })]
          })]
        }), /* @__PURE__ */ jsx("div", {
          className: "w-full sm:max-w-md mt-3 overflow-hidden bg-white p-3 sm:rounded-lg",
          children: /* @__PURE__ */ jsxs("form", {
            onSubmit: submit,
            children: [/* @__PURE__ */ jsxs("div", {
              children: [/* @__PURE__ */ jsx(InputLabel, {
                forInput: "name",
                value: "Name"
              }), /* @__PURE__ */ jsx(TextInput, {
                type: "text",
                name: "name",
                value: data.name,
                className: "mt-1 block w-full",
                autoComplete: "name",
                isFocused: true,
                handleChange: onHandleChange,
                required: true
              }), /* @__PURE__ */ jsx(InputError, {
                message: errors.name,
                className: "mt-2"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(InputLabel, {
                forInput: "name",
                value: "Phone"
              }), /* @__PURE__ */ jsx(TextInput, {
                type: "tel",
                name: "phone",
                value: data.phone,
                className: "mt-1 block w-full",
                autoComplete: "phone",
                isFocused: true,
                handleChange: onHandleChange,
                required: true
              }), /* @__PURE__ */ jsx(InputError, {
                message: errors.phone,
                className: "mt-2"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(InputLabel, {
                forInput: "email",
                value: "Email"
              }), /* @__PURE__ */ jsx(TextInput, {
                type: "email",
                name: "email",
                value: data.email,
                className: "mt-1 block w-full",
                autoComplete: "username",
                handleChange: onHandleChange,
                required: true
              }), /* @__PURE__ */ jsx(InputError, {
                message: errors.email,
                className: "mt-2"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(InputLabel, {
                forInput: "password",
                value: "Password"
              }), /* @__PURE__ */ jsx(TextInput, {
                type: "password",
                name: "password",
                value: data.password,
                className: "mt-1 block w-full",
                autoComplete: "new-password",
                handleChange: onHandleChange,
                required: true
              }), /* @__PURE__ */ jsx(InputError, {
                message: errors.password,
                className: "mt-2"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(InputLabel, {
                forInput: "password_confirmation",
                value: "Confirm Password"
              }), /* @__PURE__ */ jsx(TextInput, {
                type: "password",
                name: "password_confirmation",
                value: data.password_confirmation,
                className: "mt-1 block w-full",
                handleChange: onHandleChange,
                required: true
              }), /* @__PURE__ */ jsx(InputError, {
                message: errors.password_confirmation,
                className: "mt-2"
              })]
            }), /* @__PURE__ */ jsx("div", {
              className: "mt-3",
              children: /* @__PURE__ */ jsx("input", {
                type: "text",
                value: data.referred,
                name: "referred",
                hidden: true,
                className: "mt-1 block w-full",
                handleChange: onHandleChange
              })
            }), /* @__PURE__ */ jsxs("div", {
              className: "block items-center justify-end mt-3",
              children: [/* @__PURE__ */ jsx(PrimaryButton, {
                processing,
                children: "Register"
              }), referral && /* @__PURE__ */ jsxs("button", {
                style: {
                  position: "relative",
                  top: "10px",
                  left: "10px"
                },
                className: "text-color-white  desktop-hide shadow rounded-full pl-5 pb-1 pt-1 pr-5 bg-color-baby-blue flex",
                children: [/* @__PURE__ */ jsx("span", {
                  className: "mr-3 mt-1",
                  children: /* @__PURE__ */ jsx(PersonCircle, {
                    className: "text-color-white  fw-bold"
                  })
                }), " ", referral]
              })]
            })]
          })
        })]
      })
    })]
  });
}
export {
  Register as default
};
