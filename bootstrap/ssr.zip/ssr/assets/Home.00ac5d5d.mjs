import { useState, Fragment as Fragment$1 } from "react";
import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { i as img1, a as img2, b as img3, I as Instructor, M as Mentor } from "./mentor.989b08a1.mjs";
import { j as jsx, a as jsxs, F as Fragment } from "../ssr.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { O as OffCanvasExample } from "./DropBottom.c156e3a4.mjs";
import { L as Logo } from "./logo.d6c74f57.mjs";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
import Form from "react-bootstrap/Form";
import { Container } from "reactstrap";
import { F as Fullstack } from "./fullstack-2.a4f71d98.mjs";
import { F as Flutter } from "./Flutter-App-development.33b56beb.mjs";
import "react-bootstrap/Button";
import "react-bootstrap/Offcanvas";
/* empty css                 */import "react-player";
/* empty css                   *//* empty css                     */import "react-bootstrap";
import "./Hermant-kumar.bd7eb8f5.mjs";
import "react-bootstrap/Carousel";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const Student2 = "/build/assets/img-1.e5d0adbf.webp";
const subTitle$2 = "About Our Vereda";
const title$2 = "Good Qualification Services And Better Skills";
const desc = " Vereda Digital Technologies Private Limited is an emerging bootcamp provider that enables learners through rigorous and highly specialized training. Our aim is to revolutionise tech education in India. We believe in outcomes and skills over degrees and Certificates.";
const aboutList = [{
  imgUrl: img1,
  imgAlt: "about icon vereda vereda",
  title: "Skilled Instructors",
  desc: "Our instructor are provided with tools and skills to teach what you love."
}, {
  imgUrl: img2,
  imgAlt: "about icon vereda vereda",
  title: "Get Certificate",
  desc: "When you complete all of the courses in the program, you`ll earn a certificate to share with your professional network as well as unlock access to career support resources to help you kickstart your new career"
}, {
  imgUrl: img3,
  imgAlt: "about icon vereda vereda",
  title: "Online Classes",
  desc: "Our classes are all online base studies, students can study at their own comfort zone."
}];
const About = () => {
  return /* @__PURE__ */ jsx("div", {
    className: "about-section",
    children: /* @__PURE__ */ jsx("div", {
      className: "container",
      children: /* @__PURE__ */ jsxs("div", {
        className: "row justify-content-center row-cols-xl-2 row-cols-1 align-items-end flex-row-reverse",
        children: [/* @__PURE__ */ jsx("div", {
          className: "col",
          children: /* @__PURE__ */ jsxs("div", {
            className: "about-right padding-tb",
            children: [/* @__PURE__ */ jsxs("div", {
              className: "section-header",
              children: [/* @__PURE__ */ jsx("span", {
                className: "subtitle",
                children: subTitle$2
              }), /* @__PURE__ */ jsx("h2", {
                className: "title",
                children: title$2
              }), /* @__PURE__ */ jsx("p", {
                children: desc
              })]
            }), /* @__PURE__ */ jsx("div", {
              className: "section-wrapper",
              children: /* @__PURE__ */ jsx("ul", {
                className: "lab-ul",
                children: aboutList.map((val, i) => /* @__PURE__ */ jsxs("li", {
                  children: [/* @__PURE__ */ jsx("div", {
                    className: "sr-left",
                    children: /* @__PURE__ */ jsx("img", {
                      src: `${val.imgUrl}`,
                      alt: `${val.imgAlt}`
                    })
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "sr-right",
                    children: [/* @__PURE__ */ jsx("h5", {
                      children: val.title
                    }), /* @__PURE__ */ jsx("p", {
                      children: val.desc
                    })]
                  })]
                }, i))
              })
            })]
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "col",
          children: /* @__PURE__ */ jsx("div", {
            className: "about-left",
            children: /* @__PURE__ */ jsx("div", {
              className: "about-thumb",
              children: /* @__PURE__ */ jsx("img", {
                src: Student2,
                alt: "about"
              })
            })
          })
        })]
      })
    })
  });
};
const BannerImg = "/build/assets/hero1.84435c9e.png";
const subTitle$1 = "Online education";
const title$1 = /* @__PURE__ */ jsxs("h2", {
  className: "title",
  children: [/* @__PURE__ */ jsx("span", {
    className: "d-lg-block",
    children: "Up Your Skills"
  }), " To Advance Your ", /* @__PURE__ */ jsx("span", {
    className: "d-lg-block",
    children: "Carrer Path"
  })]
});
const Banner = () => {
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const {
    flash
  } = usePage().props;
  const [values, setValue] = useState({
    "name": "",
    "email": "",
    "phone": "",
    "country": "",
    "state": "",
    "occupation": "",
    "studies": "",
    "language": ""
  });
  const HandleChange = (e) => {
    const key = e.target.id;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/request/call", values);
  };
  const handleClose = () => setShow(false);
  return /* @__PURE__ */ jsxs("section", {
    className: "banner-section",
    children: [/* @__PURE__ */ jsx("div", {
      className: "container",
      children: /* @__PURE__ */ jsx("div", {
        className: "section-wrapper",
        children: /* @__PURE__ */ jsxs("div", {
          className: "row align-items-center",
          children: [/* @__PURE__ */ jsx("div", {
            className: "col-xxl-8 col-xl-6 col-lg-10",
            children: /* @__PURE__ */ jsxs("div", {
              className: "banner-content",
              children: [/* @__PURE__ */ jsx("h6", {
                className: "subtitle text-uppercase fw-medium",
                children: subTitle$1
              }), title$1, /* @__PURE__ */ jsxs("p", {
                className: "desc capitalize",
                children: [" digital training program by indian's Leading experts.", /* @__PURE__ */ jsx("br", {}), " join many Learners today, acquire a tech skill."]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mb-5",
                children: [/* @__PURE__ */ jsx("button", {
                  className: "bg-primaries",
                  type: "#",
                  children: /* @__PURE__ */ jsx("a", {
                    className: "text-white",
                    href: "register",
                    children: "Get Started"
                  })
                }), /* @__PURE__ */ jsx("button", {
                  className: "bg-primaries ml-2 text-white",
                  type: "#",
                  onClick: handleShow,
                  children: "Request Call Back"
                })]
              })]
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "col-xxl-4 col-xl-6",
            children: /* @__PURE__ */ jsx("div", {
              className: "banner-thumb",
              children: /* @__PURE__ */ jsx("img", {
                src: BannerImg,
                width: "80%",
                style: {
                  position: "relative",
                  top: "10px"
                },
                alt: "img"
              })
            })
          })]
        })
      })
    }), /* @__PURE__ */ jsx("div", {
      className: "all-shapes"
    }), /* @__PURE__ */ jsx("div", {
      className: "cbs-content-list d-none"
    }), /* @__PURE__ */ jsx(OffCanvasExample, {
      show,
      onHide: handleClose,
      title: /* @__PURE__ */ jsx(Fragment, {
        children: /* @__PURE__ */ jsxs("div", {
          className: "block",
          children: [/* @__PURE__ */ jsx("h4", {
            children: /* @__PURE__ */ jsx("a", {
              href: "/",
              className: "logo-anchor item-center",
              children: /* @__PURE__ */ jsx("img", {
                src: Logo,
                width: "100px",
                alt: Logo,
                srcSet: ""
              })
            })
          }), /* @__PURE__ */ jsx("h3", {
            className: "fw-bold",
            children: "Talk to Our Expert"
          })]
        })
      }),
      children: /* @__PURE__ */ jsx(Fragment, {
        children: /* @__PURE__ */ jsx(Container, {
          children: /* @__PURE__ */ jsxs("form", {
            onSubmit: handleSubmit,
            children: [/* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              onChange: HandleChange,
              value: values.name,
              id: "name",
              required: true,
              placeholder: "Name",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "email",
              onChange: HandleChange,
              value: values.email,
              id: "email",
              required: true,
              placeholder: "abcd@example.com ",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "number",
              id: "phone",
              value: values.phone,
              onChange: HandleChange,
              required: true,
              placeholder: "+9 9123 567 98",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              value: values.country,
              id: "country",
              onChange: HandleChange,
              required: true,
              placeholder: "Country",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "occupation",
              value: values.occupation,
              onChange: HandleChange,
              required: true,
              placeholder: "Occupation",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "state",
              value: values.state,
              onChange: HandleChange,
              required: true,
              placeholder: "State",
              className: "mt-2"
            }), /* @__PURE__ */ jsxs(Form.Select, {
              onChange: HandleChange,
              vlaue: values.language,
              id: "language",
              required: true,
              className: "mt-2",
              children: [/* @__PURE__ */ jsx("option", {
                children: "select Language"
              }), /* @__PURE__ */ jsx("option", {
                value: "English",
                children: "English"
              }), /* @__PURE__ */ jsx("option", {
                value: "Hindi",
                children: "Hindi"
              })]
            }), /* @__PURE__ */ jsx(PrimaryButton, {
              className: "mt-5",
              children: "submit"
            }), flash.message && /* @__PURE__ */ jsx("div", {
              className: "alert alert-success",
              children: "Request sent successfully"
            })]
          })
        })
      })
    })]
  });
};
const authotImg1 = "/build/assets/01.7a124358.jpg";
const authotImg2 = "/build/assets/02.16cc76dc.jpg";
const subTitle = "Featured Courses";
const title = "Pick A Course To Get Started";
const Course = () => {
  const {
    flash,
    programs,
    flutter,
    fullstack
  } = usePage().props;
  const longEnUsFormatter = new Intl.DateTimeFormat("en-GB", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const courseList = [
    {
      imgUrl: Fullstack,
      imgAlt: "course vereda vereda",
      price: "$30",
      cate: "Web Development",
      reviewCount: "03 reviews",
      title: "Full Stack Web Development Program",
      totalLeson: "18x Lesson",
      schdule: longEnUsFormatter.format(new Date(`${fullstack.starts}`)),
      authorImgUrl: authotImg1,
      authorImgAlt: "course author vereda vereda",
      authorName: fullstack.trainerName,
      btnText: "",
      coursedtl: "/Program/Full-Stack-Development-Program",
      seats: fullstack.studentsno
    },
    {
      imgUrl: Flutter,
      imgAlt: "course vereda vereda",
      price: "$30",
      cate: "Mobile Development",
      reviewCount: "03 reviews",
      title: "Flutter Development Program",
      totalLeson: "18x Lesson",
      schdule: longEnUsFormatter.format(new Date(`${flutter.starts}`)),
      authorImgUrl: authotImg2,
      authorImgAlt: "course author vereda vereda",
      authorName: flutter.trainerName,
      btnText: "",
      coursedtl: "/Program/Flutter-Development-Program",
      seats: flutter.studentsno
    }
  ];
  useState(false);
  useState({
    "name": "",
    "email": "",
    "phone": "",
    "country": "",
    "state": "",
    "occupation": "",
    "studies": "",
    "language": ""
  });
  return /* @__PURE__ */ jsx("div", {
    className: "course-section padding-tb section-bg",
    children: /* @__PURE__ */ jsxs("div", {
      className: "container",
      children: [/* @__PURE__ */ jsxs("div", {
        className: "section-header text-center",
        children: [/* @__PURE__ */ jsx("span", {
          className: "subtitle",
          children: subTitle
        }), /* @__PURE__ */ jsx("h2", {
          className: "title",
          children: title
        })]
      }), /* @__PURE__ */ jsx("div", {
        className: "section-wrapper",
        children: /* @__PURE__ */ jsx("div", {
          className: "row g-4 justify-content-center row-cols-xl-2 row-cols-md-2 row-cols-1",
          children: courseList.map((val, i) => /* @__PURE__ */ jsx("div", {
            className: "col",
            children: /* @__PURE__ */ jsx("div", {
              className: "course-item",
              children: /* @__PURE__ */ jsxs("div", {
                className: "course-inner",
                children: [/* @__PURE__ */ jsx("div", {
                  className: "course-thumb rounded",
                  children: /* @__PURE__ */ jsx("img", {
                    src: `${val.imgUrl}`,
                    alt: `${val.imgAlt}`
                  })
                }), /* @__PURE__ */ jsxs("div", {
                  className: "course-content",
                  children: [/* @__PURE__ */ jsx("div", {
                    className: "course-category",
                    children: /* @__PURE__ */ jsx("div", {
                      className: "course-cate",
                      children: /* @__PURE__ */ jsx("a", {
                        href: "#",
                        children: val.cate
                      })
                    })
                  }), /* @__PURE__ */ jsx(Link, {
                    href: val.coursedtl,
                    children: /* @__PURE__ */ jsx("h4", {
                      children: val.title
                    })
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "course-details",
                    children: [/* @__PURE__ */ jsxs("div", {
                      className: "couse-count",
                      children: ["  ", /* @__PURE__ */ jsxs("h4", {
                        className: "h3-bullet",
                        children: ["BATCH ", val.seats >= 15 ? "STARTS ON" : ""]
                      }), /* @__PURE__ */ jsxs("h5", {
                        className: "h5-bullet",
                        children: [val.seats >= 15 ? val.schdule : "Coming Soon", "   "]
                      })]
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "couse-topic",
                      children: [/* @__PURE__ */ jsx("h4", {
                        className: "h3-bullet",
                        children: " Limited Seats"
                      }), /* @__PURE__ */ jsxs("h5", {
                        className: "h5-bullet",
                        children: [20 - val.seats, " Available"]
                      })]
                    })]
                  }), /* @__PURE__ */ jsx("div", {
                    className: "course-footer",
                    children: /* @__PURE__ */ jsx("div", {
                      className: "course-author",
                      children: /* @__PURE__ */ jsx(Link, {
                        to: "#",
                        className: "ca-name fw-bold capitalize",
                        children: val.authorName
                      })
                    })
                  })]
                })]
              })
            })
          }, i))
        })
      })]
    })
  });
};
const recogn1 = "/build/assets/livehindustan.d866c2cd.svg";
const recogn2 = "/build/assets/Dainik_Bhaskar_Logo.d5cafa96.png";
const Featured = () => {
  useState(false);
  usePage().props;
  useState({
    "name": "",
    "email": "",
    "phone": "",
    "country": "",
    "state": "",
    "occupation": "",
    "studies": "",
    "language": ""
  });
  return /* @__PURE__ */ jsxs("section", {
    className: "section-7",
    children: [/* @__PURE__ */ jsxs("div", {
      className: "section-header text-center",
      children: [/* @__PURE__ */ jsx("span", {
        className: "subtitle",
        children: "Featured"
      }), /* @__PURE__ */ jsx("h2", {
        className: "title",
        children: "Our Featured Program"
      })]
    }), "                ", /* @__PURE__ */ jsx("div", {
      className: "container",
      children: /* @__PURE__ */ jsxs("div", {
        className: "recognition row header-block ",
        children: [/* @__PURE__ */ jsx("div", {
          className: "col mt-0 p-2",
          children: /* @__PURE__ */ jsx("img", {
            className: "",
            src: recogn2,
            alt: recogn2
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "col mt-5 p-2",
          children: [" ", /* @__PURE__ */ jsx("img", {
            className: "",
            src: recogn1,
            alt: recogn1
          })]
        })]
      })
    })]
  });
};
const Home = () => {
  const {
    flash,
    programs,
    flutter,
    fullstack
  } = usePage().props;
  if (flash.data) {
    window.sessionStorage.setItem("name", flash.data.name);
    window.sessionStorage.setItem("referral", flash.data.referral);
  }
  return /* @__PURE__ */ jsxs(Fragment$1, {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: "Welcome",
      children: [/* @__PURE__ */ jsx("meta", {
        name: "description",
        content: "welcome to Vereda.co.in, one of the leading digital learning in India."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:Vereda.co.in",
        content: "https://vereda.co.in"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Vereda DIgital Technologies"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Kickstart your career in application development."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        content: "../Images/banner.jpg"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in"
      })]
    }), /* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(Banner, {}), /* @__PURE__ */ jsx(Course, {}), /* @__PURE__ */ jsx(About, {}), /* @__PURE__ */ jsx(Featured, {}), /* @__PURE__ */ jsx(Instructor, {}), /* @__PURE__ */ jsx(Mentor, {}), /* @__PURE__ */ jsx(Footer, {})]
  });
};
export {
  Home as default
};
