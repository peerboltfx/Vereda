import "react";
import Container from "react-bootstrap/Container";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
/* empty css                 *//* empty css                 */import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeader } from "./pageheader.c3637c95.mjs";
/* empty css                   *//* empty css                     */import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "react-bootstrap";
import "@inertiajs/inertia";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function termsAndCondition(props) {
  usePage().props;
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Terms and Conditions",
      children: /* @__PURE__ */ jsx("meta", {
        name: "description",
        content: "Terms associated to our site."
      })
    }), /* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeader, {
      title: "Terms and Conditions",
      curPage: "Terms and Condition"
    }), /* @__PURE__ */ jsx("section", {
      children: /* @__PURE__ */ jsxs(Container, {
        className: "mt-5 mb-5 pb-5",
        children: [/* @__PURE__ */ jsx("h4", {
          className: " fw-bold mt-5 p-4 pb-4",
          children: "Usage of this site is bounded by these Terms."
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-5 mb-5",
          children: ['Vereda.co.in maintains this website, any courses and other linked and related sites (the "Site") for the use of it`s customers, vendors, students, and other sites users (*Users*) upoh agreement to the following terms. Please read the terms carefully before using the Site. Use of this website indicates acceptance of these "Terms and Use" and forms a binding agreement between you and Vereda.co.in. If you do not agree to these terms, do not use this Site. ', /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "In addition to these terms, all the purchases made on this site are governed by our refund policy found ", /* @__PURE__ */ jsx(Link, {
            href: route("RefundPolicy"),
            children: "here"
          }), " ", " ", "and all activity is governed by our privacy policy ", /* @__PURE__ */ jsx(Link, {
            href: route("PrivacyPolicy"),
            children: "Here"
          }), " ", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "Minors or people below 16 years old are not allowed to use this website."]
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4",
            children: "1.Use of Site"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "Vereda.co.in provides various materials, information, quizzes, tests, questions, articles, news and other information on this and related sites and in courses offered through this site (the \u201CMaterials\u201D). Vereda.co.in authorizes each User to view and download one copy of the Materials. Materials may be downloaded and a maximum of one copy of the Materials may be printed provided that Users make no modifications to the Materials and you retain all copyright and other proprietary notices contained in the original Materials on any copies of the Materials. Users may not modify the Materials at this Site in any way or reproduce, share or distribute them. Users will keep all Materials confidential, and will not sell, auction, loan, rent, give away, describe, summarize, or otherwise reveal the Materials or their contents, to any other person or entity. Any breach of these Terms of Use automatically terminates your authorized use of the Site"
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4",
            children: "2.Geographic location"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "If you, as a User, purchase Materials from this Site or Vereda.co.in while outside of India, you may not use or access the materials while inside India."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4",
            children: "3. User Warranty"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-4",
          children: "As a User, you warrant that you are not an agent or employee of any other test preparation company and the Site and Materials solely for your own personal career advancement or personal use."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mb-4 mt-4",
            children: "4. Trademark and Copyright"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "Vereda.co.in, and certain other brands, trademarks, and service marks are marks of Vereda.co.in and its affiliates. The Materials on this Site are copyrighted, and any unauthorized use of any Materials on this Site may violate copyright, trademark, and other laws"
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4 mb-4",
            children: " 5. Hyperlinks"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "Links to external websites are provided solely as a convenience to you. Vereda.co.in has not reviewed all of these external websites, does not control and is not responsible for any of these sites or their content. If you decide to access any of the external websites linked to this Site, you do so entirely at your own risk."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5",
            children: "6. No Warranty"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "The Materials provided at this site are provided \u201Cas is\u201D without any warranties of any kind including warranties of merchantability, fitness for a particular purpose, or non-infringement of intellectual property. Vereda.co.in further does not warrant the accuracy and completeness of the Materials at this Site. Vereda.co.in may make changes to the Materials at this Site, or to the services and prices described in them, at any time without notice. The Materials at this Site may be out of date and makes no commitment to update the Materials at this Site."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5 mb-2",
            children: "7. Limitation of Liability"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "In no event will Vereda.co.in, its suppliers or other third parties mentioned at this Site be liable for any damages whatsoever (including, without limitation, those resulting from lower test scores, interruption of services or inaccurate information) arising out of the use, inability to use, or the results of the use of this Site, any websites liked to this Site, or the Materials or information contained at any or all such sites, whether based on warranty, contract, tort or any other legal theory and whether or not advised of the possibility of such damages. If your use of the Materials or information from this Site results in the need for servicing, repair or correction of equipment or data, you assume all costs thereof."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5 mb-2",
            children: "8. Account Termination"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "Any and all accounts may be terminated for any reason(s), at any time, at the sole discretion of the administrators of this website."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5 mb-2",
            children: "9. Applicable Law"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "The Terms of Use are governed by the laws of India. Failure to enforce strict performance of the Terms of Use of Use shall not be construed as a waiver of any provision or right. Vereda.co.in may assign its rights and duties under the Terms of Use without notice to any party at any time."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5 mb-2",
            children: "10. Effective Date and Updates"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "The Terms are effective as of November 11th, 2022 and are subject to change without notice by Vereda.co.in at any time. Please check for changes regularly. Your use of this Site after such changes constitutes your agreement to such changes."
        })]
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
}
export {
  termsAndCondition as default
};
