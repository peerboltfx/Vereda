import { useState } from "react";
/* empty css                 */import { RouterDom } from "./RRouterDom.b83a7118.mjs";
import Container from "react-bootstrap/Container";
import { CheckCircleFill } from "react-bootstrap-icons";
import { F as Faqs, u as ujjwal, H as Hermant, v as vishal } from "./Faq.41215779.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
import { Col } from "react-bootstrap";
import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeaderTwo, C as CourseSideDetail, A as Author } from "./course-detail.0fa1020d.mjs";
import { a as jsxs, j as jsx, F as Fragment } from "../ssr.mjs";
import { F as Fullstack } from "./fullstack-2.a4f71d98.mjs";
import { O as OffCanvasExample } from "./DropBottom.c156e3a4.mjs";
import Form from "react-bootstrap/Form";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { L as Logo } from "./logo.d6c74f57.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
import "@inertiajs/inertia";
/* empty css                   *//* empty css                     */import "react-bootstrap/Button";
import "react-bootstrap/Offcanvas";
const workVector = "/build/assets/work-vector.2457a124.png";
function FullStackDev(props) {
  const {
    name,
    programs,
    pricing,
    flash
  } = usePage().props;
  const [dropDown, setDropDown] = useState(false);
  const [enrollFloat, setEnroll] = useState(false);
  useState(false);
  useState(false);
  useState(false);
  useState(false);
  const HandleEnroll = () => {
    if (window.scrollY > 500 && window.scrollY < 2300) {
      setEnroll(true);
    } else {
      setEnroll(false);
    }
  };
  window.addEventListener("scroll", HandleEnroll);
  const handleDropDown = () => {
    setDropDown(!dropDown);
  };
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const [values, setValue] = useState({
    "name": "",
    "email": "",
    "phone": "",
    "country": "",
    "state": "",
    "occupation": "",
    "studies": "",
    "language": ""
  });
  const HandleChange = (e) => {
    const key = e.target.id;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/request/call", values);
  };
  const handleClose = () => setShow(false);
  return /* @__PURE__ */ jsxs("div", {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: name.program,
      children: [/* @__PURE__ */ jsx("meta", {
        property: "og:Vereda.co.in",
        content: "https://vereda.co.in/Full-Stack-Development-Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Full Stack Development Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Become expert in developing web and mobile applications using Flutter Development."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        itemProp: "image",
        content: Fullstack
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/Full-Stack-Development-Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/Full-Stack-Development-Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "description",
        content: "Learn full Stack developement and become a Professional Developer with a Certificate"
      })]
    }), /* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeaderTwo, {
      programImage: Fullstack,
      title: name.program,
      subject: "Learn full Stack developement and become a Professional Developer with a Certificate"
    }), /* @__PURE__ */ jsx("div", {
      className: " padding-tb section-bg",
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "row justify-content-center",
          children: [/* @__PURE__ */ jsx("div", {
            className: "col-lg-8",
            children: /* @__PURE__ */ jsxs("div", {
              className: "main-part",
              children: [/* @__PURE__ */ jsx("div", {
                className: "course-item",
                children: /* @__PURE__ */ jsx("div", {
                  className: "course-inner",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: " ml-2",
                    children: [/* @__PURE__ */ jsx("h3", {
                      children: "Course Overview"
                    }), /* @__PURE__ */ jsx("p", {
                      children: "Kickstart your career in application development. Master Cloud Native and Full Stack Development using hands-on projects involving HTML, Javascript, Node.js, Object Oriented Programming and more. No prior experience required."
                    }), /* @__PURE__ */ jsx("h4", {
                      children: "What You'll Learn in This Course:"
                    }), /* @__PURE__ */ jsxs(Col, {
                      className: "block col pb-4",
                      children: [/* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 1 & 2"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Basic of HTML, CSS and Project"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 3 & 4"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Learn Javascript with simple task"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 5 "
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Learn Bootstrap and tailwinds"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 6"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "React, Redux, Router"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 7"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Learn about Git and Github"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 8 & 9"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Learn MySql and MongoDB"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 10 & 11"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Learn Advanced Javascript"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 12 & 13"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Learn Rest API or Json API"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 14 & 15"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Learn aws or Google Cloud"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 16 & 17"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Revise of the course"
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: "Week 18 & 23"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: "Multiple Projects."
                          })]
                        })]
                      })]
                    }), /* @__PURE__ */ jsxs("div", {
                      children: [/* @__PURE__ */ jsxs("div", {
                        className: dropDown ? "dropDownBox show pt-2" : "dropDownBox pt-2 pb-4",
                        children: [/* @__PURE__ */ jsx("div", {
                          className: "course-video-title mb-5",
                          children: /* @__PURE__ */ jsx("h4", {
                            children: "Course Content"
                          })
                        }), /* @__PURE__ */ jsx("p", {
                          className: "pb-1",
                          children: "This Professional Certificate will equip you with all the key skill and technical know-how to kickstart your career as a full Stack Web Developer, guided by expert at Vereda, you will learn to build your own web applications and practice working with the technologies behind them. This program consists of ample instructional content as well as hands-on-excercises and projects designed to hone your skills and help you build your portfolio."
                        }), /* @__PURE__ */ jsx("p", {
                          className: "pb-1",
                          children: "No prior programming experience is required. you'll skill up with the tools and technologies that successful software developers use to build, deploy, test, run, and manage Full Stack Web Development, giving you the practical skills to begin a new career in a highly in-demand area."
                        }), /* @__PURE__ */ jsx("p", {
                          className: "pb-1",
                          children: "The courses in this program will help you develope skill set in a variety of technologies including: HTML, CSS, Javascript, GitHub, Node.js, React.js, Database, SQL, Bootstrap, Application Security, PHP and more."
                        }), /* @__PURE__ */ jsx("p", {
                          className: "pb-1",
                          children: "After completing the program, you will have developed several applicationd using front-end and back-end technologies and deployed them on cloud platform possibly using Cloud Native."
                        })]
                      }), /* @__PURE__ */ jsx("h6", {
                        onClick: handleDropDown,
                        className: "text-center mt-4 text-color-blue fw-bold",
                        children: "see more"
                      })]
                    })]
                  })
                })
              }), /* @__PURE__ */ jsx("div", {
                className: "course-video",
                children: /* @__PURE__ */ jsx("div", {
                  className: "course-video-content"
                })
              })]
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "col-lg-4",
            children: /* @__PURE__ */ jsx("div", {
              className: "sidebar-part",
              children: /* @__PURE__ */ jsx(CourseSideDetail, {
                price: pricing.toString("fi-FI").replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                enroll: `/en/${name.program.split(" ").join("-")}/session/${name.random}`,
                tweet: `https://twitter.com/intent/tweet?text=Awesomee%20Blog!&url=vereda.co.in/Program/${name.program.split(" ").join("-")}`,
                linked: `https://www.linkedin.com/sharing/share-offsite/?url=vereda.co.in/Program/${name.program.split(" ").join("-")}`,
                ping: `https://www.facebook.com/sharer.php?u=vereda.co.in/Program/${name.program.split(" ").join("-")}&quote=Awesome%20Blog!`
              })
            })
          })]
        })
      })
    }), /* @__PURE__ */ jsx(RouterDom, {
      children: /* @__PURE__ */ jsxs(Container, {
        children: [/* @__PURE__ */ jsxs("div", {
          className: "row",
          children: [/* @__PURE__ */ jsxs(Col, {
            lg: "6",
            md: "6",
            sm: "12",
            className: "p-2 text-color-white",
            children: [/* @__PURE__ */ jsx("h4", {
              className: "fw-bold pl-1 pt-2 pb-4",
              children: "Build Job-ready skills by learning from the best"
            }), /* @__PURE__ */ jsxs("div", {
              className: "row header-block",
              children: [/* @__PURE__ */ jsx("div", {
                className: "col",
                children: /* @__PURE__ */ jsx("p", {
                  children: "Get started in the in-demand field of Full Stack Web Application Development with professional Certificate from Vereda. Learn the tools and technologies, that software developers use to build, deploy, test, run, and manage cloud-based applications. "
                })
              }), /* @__PURE__ */ jsx("div", {
                className: "col",
                children: /* @__PURE__ */ jsx("img", {
                  src: workVector,
                  width: "200px"
                })
              })]
            }), /* @__PURE__ */ jsxs("p", {
              className: "pl-1 pt-2 pb-4",
              children: [/* @__PURE__ */ jsx("b", {
                children: "Common Job titles:"
              }), "Web Application Developer, Junior Full Sttack Developer, Full Stack Developer, Front-end Developer, back-end Developer, Software Engineering, etc."]
            })]
          }), /* @__PURE__ */ jsx(Col, {
            lg: "6",
            md: "6",
            sm: "12",
            children: /* @__PURE__ */ jsx(Faqs, {})
          })]
        }), /* @__PURE__ */ jsxs("div", {
          id: "trainers",
          className: "",
          children: [/* @__PURE__ */ jsx("h4", {
            className: "pt-4 pb-3",
            children: "Instructors"
          }), /* @__PURE__ */ jsxs("div", {
            className: "row header-block trainer",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx(Author, {
                teacherSrc: ujjwal,
                name: "Ujjwal Verma",
                task: "Lead Software Developer IIT",
                linkedin: "https://www.linkedin.com/in/ujjwalverma007"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx(Author, {
                teacherSrc: Hermant,
                name: "Hermant Kumar",
                task: "Co-Founder B. Tech",
                linkedin: "https://www.linkedin.com/in/hermant-kumar-sedhanshu-42142390"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx(Author, {
                teacherSrc: vishal,
                name: "Vishal Pankaj",
                task: "Technical domain Expert",
                linkedin: "https://www.linkedin.com/in/vishal-pankaj-30503a103"
              })
            })]
          })]
        }), /* @__PURE__ */ jsxs("div", {
          className: "call mt-4 mb-4",
          children: [" ", /* @__PURE__ */ jsx("button", {
            onClick: handleShow,
            className: "full-size-btn capitalize full-width-btn",
            children: "request call back"
          })]
        }), /* @__PURE__ */ jsx(OffCanvasExample, {
          show,
          onHide: handleClose,
          title: /* @__PURE__ */ jsx(Fragment, {
            children: /* @__PURE__ */ jsxs("div", {
              className: "block",
              children: [/* @__PURE__ */ jsx("h4", {
                children: /* @__PURE__ */ jsx("a", {
                  href: "/",
                  className: "logo-anchor item-center",
                  children: /* @__PURE__ */ jsx("img", {
                    src: Logo,
                    width: "100px",
                    alt: Logo,
                    srcSet: ""
                  })
                })
              }), /* @__PURE__ */ jsx("h3", {
                className: "fw-bold",
                children: "Talk to Our Expert"
              })]
            })
          }),
          children: /* @__PURE__ */ jsx(Fragment, {
            children: /* @__PURE__ */ jsx(Container, {
              children: /* @__PURE__ */ jsxs("form", {
                onSubmit: handleSubmit,
                children: [/* @__PURE__ */ jsx(Form.Control, {
                  type: "text",
                  onChange: HandleChange,
                  value: values.name,
                  id: "name",
                  required: true,
                  placeholder: "Name",
                  className: "mt-2"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "email",
                  onChange: HandleChange,
                  value: values.email,
                  id: "email",
                  required: true,
                  placeholder: "abcd@example.com ",
                  className: "mt-2"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "number",
                  id: "phone",
                  value: values.phone,
                  onChange: HandleChange,
                  required: true,
                  placeholder: "+9 9123 567 98",
                  className: "mt-2"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "text",
                  value: values.country,
                  id: "country",
                  onChange: HandleChange,
                  required: true,
                  placeholder: "Country",
                  className: "mt-2"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "text",
                  id: "occupation",
                  value: values.occupation,
                  onChange: HandleChange,
                  required: true,
                  placeholder: "Occupation",
                  className: "mt-2"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "text",
                  id: "state",
                  value: values.state,
                  onChange: HandleChange,
                  required: true,
                  placeholder: "State",
                  className: "mt-2"
                }), /* @__PURE__ */ jsxs(Form.Select, {
                  onChange: HandleChange,
                  vlaue: values.language,
                  id: "language",
                  required: true,
                  className: "mt-2",
                  children: [/* @__PURE__ */ jsx("option", {
                    children: "select Language"
                  }), /* @__PURE__ */ jsx("option", {
                    value: "English",
                    children: "English"
                  }), /* @__PURE__ */ jsx("option", {
                    value: "Hindi",
                    children: "Hindi"
                  })]
                }), /* @__PURE__ */ jsx(PrimaryButton, {
                  className: "mt-5",
                  children: "submit"
                }), flash.message && /* @__PURE__ */ jsx("div", {
                  className: "alert alert-success",
                  children: "Request sent successfully"
                })]
              })
            })
          })
        })]
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
}
export {
  FullStackDev as default
};
