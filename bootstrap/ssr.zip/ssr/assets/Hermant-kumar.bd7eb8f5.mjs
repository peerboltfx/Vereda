const img3 = "/build/assets/Ujjwal-Verma.b71e26eb.webp";
const img4 = "/build/assets/Hermant-kumar.f9e6f93a.webp";
export {
  img3 as a,
  img4 as i
};
