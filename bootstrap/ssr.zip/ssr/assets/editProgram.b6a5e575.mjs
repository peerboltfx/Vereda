import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { Row, Col, Form } from "react-bootstrap";
/* empty css                 */import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
import { Editor } from "react-draft-wysiwyg";
import { EditorState } from "draft-js";
import { convertToHTML } from "draft-convert";
/* empty css                               */import { Book } from "react-bootstrap-icons";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function editProgram(props) {
  const {
    program,
    programs
  } = usePage().props;
  const [values, setValue] = useState({
    "price": program.price || "",
    "program": program.program || "",
    "period": program.period || "",
    "inrprice": program.inrprice || ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const [searchvalues, setValues] = useState({
    "search": ""
  });
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const [editorState, setEditorState] = useState(() => EditorState.createEmpty());
  const [convertedContent, setConvertedContent] = useState(program.descriptiom || null);
  const HandleEditorChange = (state) => {
    setEditorState(state);
    convertContentToHTML();
  };
  const convertContentToHTML = () => {
    let currentContentAsHTML = convertToHTML(editorState.getCurrentContent());
    setConvertedContent(currentContentAsHTML);
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    Inertia.post(`/admin/edit-post-program/${program.random}`, {
      "first": values,
      "second": convertedContent
    });
  };
  const found = programs.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(searchvalues.search)));
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Admin Page"
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-4 text-color-blue",
        children: " Edit Moderator Role"
      })]
    }),
    Search: /* @__PURE__ */ jsxs("div", {
      className: "Search-container",
      children: [/* @__PURE__ */ jsx("input", {
        onBlur: () => setShow(false),
        onClick: HandleShow,
        type: "text",
        name: "search",
        value: searchvalues.search,
        onChange: HandleChange
      }), /* @__PURE__ */ jsx("div", {
        tabIndex: "0",
        className: show ? "Searched active" : "Searched",
        children: found.map((data, index) => {
          return /* @__PURE__ */ jsx(Row, {
            children: /* @__PURE__ */ jsx(Col, {
              mx: "6",
              children: /* @__PURE__ */ jsx(Link, {
                href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                className: "text-color-dark-blue",
                children: /* @__PURE__ */ jsxs("div", {
                  className: "flex mt-3 pb-3",
                  children: [/* @__PURE__ */ jsx(Col, {
                    md: "1",
                    className: "pt-0 ml-2 ",
                    children: /* @__PURE__ */ jsx(Book, {
                      style: {
                        fontSize: "30px",
                        color: "#DC4731"
                      },
                      className: "pl-1"
                    })
                  }), /* @__PURE__ */ jsx(Col, {
                    md: "6",
                    className: "fs-5 fw-bold pl-0 ml-4 text-color-dark-blue",
                    children: data.program
                  })]
                })
              })
            })
          }, index);
        })
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Edit - " + program.program
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-2xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 border-b border-gray-200",
            children: /* @__PURE__ */ jsxs("form", {
              method: "POST",
              onSubmit: HandleSubmit,
              className: "mt-5",
              children: [/* @__PURE__ */ jsxs("h1", {
                children: ["Edit", " " + program.program]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-3",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  children: "Program/Service Name"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "text",
                  value: values.program,
                  onChange: HandleChange,
                  name: "program",
                  required: true
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-3",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  htmlFor: "price",
                  children: "Price in Indian Rupee"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "number",
                  value: values.price,
                  onChange: HandleChange,
                  name: "price",
                  required: true
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-3",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  htmlFor: "period",
                  children: "Period "
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "number",
                  value: values.period,
                  onChange: HandleChange,
                  name: "period",
                  required: true
                })]
              }), /* @__PURE__ */ jsxs("div", {
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  children: "Description Content."
                }), /* @__PURE__ */ jsx(Editor, {
                  editorState,
                  onEditorStateChange: HandleEditorChange,
                  toolbarClassName: "toolbar-class",
                  wrapperClassName: "wrapper-class",
                  editorClassName: "editor-class",
                  name: "description"
                })]
              }), /* @__PURE__ */ jsx(Col, {
                children: /* @__PURE__ */ jsx(PrimaryButton, {
                  className: "mt-4",
                  children: "Submit"
                })
              })]
            })
          })
        })
      })
    })]
  });
}
export {
  editProgram as default
};
