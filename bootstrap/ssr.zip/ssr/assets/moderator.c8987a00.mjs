import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { Row, Col, Table } from "react-bootstrap";
/* empty css                 */import { Book } from "react-bootstrap-icons";
import Pagination from "@mui/material/Pagination";
import { u as usePagination } from "./pagination.eea5d8a8.mjs";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Moderators(props) {
  const {
    moderators,
    programs
  } = usePage().props;
  let [page, setPage] = useState(1);
  const PER_PAGE = 10;
  const [searchvalues, setValues] = useState({
    "search": ""
  });
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValue((values) => ({
      ...values,
      [key]: value
    }));
  };
  const count = Math.ceil(moderators.length / PER_PAGE);
  const _DATA = usePagination(moderators, PER_PAGE);
  const handleChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  };
  const found = programs.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(searchvalues.search)));
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Admin Page / Moderator"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Moderator Table"
        })]
      }),
      Search: /* @__PURE__ */ jsxs("div", {
        className: "Search-container  sm:rounded-lg",
        children: [/* @__PURE__ */ jsx("input", {
          onBlur: () => setShow(false),
          onClick: HandleShow,
          type: "text",
          name: "search",
          value: searchvalues.search,
          onChange: HandleChange
        }), /* @__PURE__ */ jsx("div", {
          tabIndex: "0",
          className: show ? "Searched  bg-white active" : "Searched",
          children: found.map((data, index) => {
            return /* @__PURE__ */ jsx(Row, {
              children: /* @__PURE__ */ jsx(Col, {
                mx: "6",
                children: /* @__PURE__ */ jsx(Link, {
                  href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                  className: "text-color-dark-blue",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "flex mt-3 pb-3",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "1",
                      className: "pt-0 ml-2 ",
                      children: /* @__PURE__ */ jsx(Book, {
                        style: {
                          fontSize: "30px",
                          color: "#DC4731"
                        },
                        className: "pl-1"
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      className: "fs-5 fw-bold pl-0 ml-4 text-color-dark-blue",
                      children: data.program
                    })]
                  })
                })
              })
            }, index);
          })
        })]
      }),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Moderator Table"
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsx("div", {
            className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
            children: /* @__PURE__ */ jsxs("div", {
              style: {
                overflowY: "scroll"
              },
              className: "p-6 border-b border-gray-200",
              children: [/* @__PURE__ */ jsxs(Table, {
                striped: true,
                bordered: true,
                hover: true,
                children: [/* @__PURE__ */ jsx("thead", {
                  children: /* @__PURE__ */ jsxs("tr", {
                    children: [/* @__PURE__ */ jsx("th", {
                      children: "#"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "name"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "email"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "phone"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "role"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "action"
                    })]
                  })
                }), /* @__PURE__ */ jsx("tbody", {
                  children: _DATA.currentData().map((data, index) => {
                    return /* @__PURE__ */ jsxs("tr", {
                      children: [/* @__PURE__ */ jsx("td", {
                        children: data.id
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.name
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.email
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.phone
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.role
                      }), /* @__PURE__ */ jsx("td", {
                        children: /* @__PURE__ */ jsx(Link, {
                          href: `/edit-moderator/${data.id}`,
                          children: "edit"
                        })
                      })]
                    }, index);
                  })
                })]
              }), /* @__PURE__ */ jsx("div", {
                className: "flex items-center flex-col sm:justify-center",
                children: /* @__PURE__ */ jsx(Pagination, {
                  count,
                  size: "large",
                  page,
                  variant: "outlined",
                  shape: "circular",
                  onChange: handleChange
                })
              })]
            })
          })
        })
      })]
    })
  });
}
export {
  Moderators as default
};
