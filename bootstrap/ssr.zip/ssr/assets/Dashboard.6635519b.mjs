import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
import { Col } from "react-bootstrap";
/* empty css                 */import { Bell, Telephone } from "react-bootstrap-icons";
import "dompurify";
import { Chart, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from "chart.js";
import { Bar, Pie } from "react-chartjs-2";
import { j as jsx, a as jsxs, F as Fragment } from "../ssr.mjs";
import "./LineChart.02c06b2c.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
const options = {
  responsive: true,
  plugins: {
    legend: {
      position: "top"
    },
    title: {
      display: true,
      text: false
    }
  }
};
function HorizontalChart({
  datas
}) {
  return /* @__PURE__ */ jsx(Bar, {
    options,
    data: datas
  });
}
Chart.register(ArcElement, Tooltip, Legend);
function PieChart() {
  const {
    programs,
    users
  } = usePage().props;
  const data = {
    labels: ["Admin", "Moderators", "Students", "No Roles Users"],
    datasets: [{
      label: "# of Users",
      data: [users.admin, users.moderator, users.students, users.optionl_students],
      backgroundColor: ["#7EC8E3 ", "#DC4731", "#050A30", "#F8CF40"],
      borderColor: ["#7EC8E3 ", "#DC4731", "#050A30", "#F8CF40"],
      borderWidth: 1
    }]
  };
  return /* @__PURE__ */ jsx(Pie, {
    data
  });
}
function AdminDashboard(props) {
  const {
    programs,
    users,
    subscribe,
    batch,
    course,
    calls
  } = usePage().props;
  for (let i = 0; i < batch.length; i++) {
    batch[i].id + ",";
  }
  const [values, setValues] = useState({
    "search": ""
  });
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const found = programs.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(values.search)));
  const labels = batch.map((data, index) => {
    return ["batch " + data.id];
  });
  const datainfo = {
    labels,
    datasets: [{
      label: "Dataset 1",
      data: batch.map((data, index) => {
        return [data.studentsno];
      }),
      backgroundColor: "#DC4731"
    }]
  };
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Dashboard"
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-4 text-color-blue",
        children: " Programs "
      })]
    }),
    Search: /* @__PURE__ */ jsxs("div", {
      className: "Search-container",
      children: [/* @__PURE__ */ jsx("input", {
        onBlur: () => setShow(false),
        onClick: HandleShow,
        type: "text",
        name: "search",
        value: values.search,
        onChange: HandleChange
      }), /* @__PURE__ */ jsx("div", {
        tabIndex: "0",
        className: show ? "Searched active" : "Searched",
        children: found.map((val) => {
          return /* @__PURE__ */ jsx("div", {
            children: val.program
          }, val.id);
        })
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Dashboard"
    }), /* @__PURE__ */ jsxs("div", {
      className: "flex dashboard-container header-block items-center",
      children: [/* @__PURE__ */ jsxs(Col, {
        lg: "8",
        className: "p-2  dashboard-content",
        children: [/* @__PURE__ */ jsx("div", {
          className: "bg-white progress-container flex flex-col sm:justify-center w-100 sm:rounded-lg",
          children: /* @__PURE__ */ jsxs("div", {
            className: "flex header-block",
            children: [/* @__PURE__ */ jsxs("div", {
              className: "flex p-4",
              children: [/* @__PURE__ */ jsxs("div", {
                style: {
                  width: "60px",
                  height: "60px"
                },
                className: " bg-primary rounded-full ml-2 flex flex-column-center items-center",
                children: [/* @__PURE__ */ jsx("h5", {
                  className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                  children: programs.length
                }), " "]
              }), /* @__PURE__ */ jsx("h6", {
                className: "text-color-dark-blue mt-2  ml-5 fw-bold w-50",
                children: "Total Course"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "flex  p-4",
              children: [/* @__PURE__ */ jsxs("div", {
                style: {
                  width: "60px",
                  height: "60px"
                },
                className: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center",
                children: [/* @__PURE__ */ jsx("h5", {
                  className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                  children: batch.length
                }), " "]
              }), /* @__PURE__ */ jsx("h6", {
                className: "text-color-dark-blue mt-2  ml-5 fw-bold w-50",
                children: "Total Batch"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "flex  p-4",
              children: [/* @__PURE__ */ jsxs("div", {
                style: {
                  width: "60px",
                  height: "60px"
                },
                className: " bg-color-gold rounded-full ml-2 flex flex-column-center items-center",
                children: [/* @__PURE__ */ jsx("h5", {
                  className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                  children: subscribe.length
                }), "  "]
              }), /* @__PURE__ */ jsx("h6", {
                className: "text-color-dark-blue mt-2  ml-5 fw-bold w-50",
                children: "Total Students"
              })]
            })]
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "bg-white mt-4 sm:rounded-lg p-3",
          children: [/* @__PURE__ */ jsx("h5", {
            className: "fw-bold text-color-dark-blue p-4",
            children: "Student Enrollment"
          }), /* @__PURE__ */ jsx(HorizontalChart, {
            datas: datainfo
          })]
        })]
      }), /* @__PURE__ */ jsx(Col, {
        lg: "4",
        className: "pr-4  dashboard-right",
        children: /* @__PURE__ */ jsxs("div", {
          className: "bg-white right-side-nav p-3 w-100 sm:rounded-lg",
          children: [/* @__PURE__ */ jsx(Col, {
            lg: "9",
            className: "mb-5",
            children: /* @__PURE__ */ jsx("h5", {
              className: "fw-bold mt-3 text-color-dark-blue",
              children: "Recent Tuitor"
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "",
            children: course.length > 0 ? /* @__PURE__ */ jsxs(Fragment, {
              children: [course.map((data, index) => {
                return /* @__PURE__ */ jsx(Link, {
                  href: `/student/en/study/${data.topic}`,
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "flex",
                    children: [/* @__PURE__ */ jsx(Col, {
                      lg: "3",
                      children: /* @__PURE__ */ jsxs("div", {
                        style: {
                          width: "50px",
                          height: "50px"
                        },
                        className: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center",
                        children: [/* @__PURE__ */ jsx("h5", {
                          className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                          children: data.tuitorName
                        }), " "]
                      })
                    }), /* @__PURE__ */ jsxs(Col, {
                      className: "pt-2",
                      children: [/* @__PURE__ */ jsx("h6", {
                        className: "fw-bold ml-3",
                        children: data.name
                      }), /* @__PURE__ */ jsx("p", {
                        children: new Date(`${data.created_at}`).toLocaleDateString()
                      })]
                    }), /* @__PURE__ */ jsx(Col, {
                      lg: "3",
                      children: /* @__PURE__ */ jsxs("div", {
                        style: {
                          width: "50px",
                          height: "50px",
                          border: "solid 1px blue"
                        },
                        className: " rounded-full ml-2 flex flex-column-center items-center",
                        children: [/* @__PURE__ */ jsx(Bell, {
                          className: "fs-5 text-color-dark-blue ml-auto mr-auto"
                        }), "  "]
                      })
                    })]
                  })
                }, index);
              }), course.length == 5 && /* @__PURE__ */ jsx(Fragment, {
                children: /* @__PURE__ */ jsx(Link, {
                  href: route("DailyPlanView"),
                  children: /* @__PURE__ */ jsx("div", {
                    className: "w-full bg-primary pt-3 pb-3 rounded-full absolute-bottom text-white text-center",
                    children: " see more"
                  })
                })
              })]
            }) : /* @__PURE__ */ jsx(Fragment, {
              children: /* @__PURE__ */ jsx("div", {
                className: "flex flex-col sm:justify-center items-center",
                children: /* @__PURE__ */ jsx("h3", {
                  className: "text-color-gray",
                  children: "first class coming soon"
                })
              })
            })
          })]
        })
      })]
    }), /* @__PURE__ */ jsx("div", {
      className: "py-2",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-10xl   sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 border-b border-gray-200",
            children: /* @__PURE__ */ jsxs("div", {
              className: "header-block flex mt-4",
              children: [/* @__PURE__ */ jsxs(Col, {
                md: "4",
                className: "bg-white p-2 overflow-hidden shadow-sm sm:rounded-lg",
                children: [/* @__PURE__ */ jsx("h5", {
                  className: "fw-bold text-color-dark-blue p-4",
                  children: "Users Chart"
                }), /* @__PURE__ */ jsx(PieChart, {})]
              }), /* @__PURE__ */ jsx(Col, {
                md: "4",
                className: "bg-white m-2 p-1 overflow-hidden shadow-sm sm:rounded-lg",
                children: /* @__PURE__ */ jsxs("div", {
                  className: "bg-white  p-3 w-100 sm:rounded-lg",
                  children: [/* @__PURE__ */ jsx(Col, {
                    lg: "9",
                    className: "mb-5",
                    children: /* @__PURE__ */ jsx("h5", {
                      className: "fw-bold text-color-dark-blue",
                      children: "Requested Calls"
                    })
                  }), /* @__PURE__ */ jsx("div", {
                    className: "",
                    children: calls.length > 0 ? /* @__PURE__ */ jsxs(Fragment, {
                      children: [calls.map((data, index) => {
                        return /* @__PURE__ */ jsx("a", {
                          href: `tel:${data.phone}`,
                          children: /* @__PURE__ */ jsxs("div", {
                            className: "flex",
                            children: [/* @__PURE__ */ jsx(Col, {
                              lg: "3",
                              children: /* @__PURE__ */ jsxs("div", {
                                style: {
                                  width: "50px",
                                  height: "50px"
                                },
                                className: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center",
                                children: [/* @__PURE__ */ jsx("h5", {
                                  className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                                  children: data.name.charAt(0).toUpperCase()
                                }), " "]
                              })
                            }), /* @__PURE__ */ jsxs(Col, {
                              className: "pt-0",
                              children: [/* @__PURE__ */ jsx("h6", {
                                className: "fw-bold ml-3",
                                children: data.phone
                              }), /* @__PURE__ */ jsx("p", {
                                children: data.name
                              }), /* @__PURE__ */ jsx("p", {
                                children: new Date(`${data.created_at}`).toLocaleDateString()
                              })]
                            }), /* @__PURE__ */ jsx(Col, {
                              lg: "3",
                              children: /* @__PURE__ */ jsxs("div", {
                                style: {
                                  width: "50px",
                                  height: "50px",
                                  border: "solid 1px blue"
                                },
                                className: " rounded-full ml-2 flex flex-column-center items-center",
                                children: [/* @__PURE__ */ jsx(Telephone, {
                                  className: "fs-5 text-color-dark-blue ml-auto mr-auto"
                                }), "  "]
                              })
                            })]
                          })
                        }, index);
                      }), course.length == 5 && /* @__PURE__ */ jsx(Fragment, {
                        children: /* @__PURE__ */ jsx(Link, {
                          href: route("DailyPlanView"),
                          children: /* @__PURE__ */ jsx("div", {
                            className: "w-full bg-primary pt-3 pb-3 rounded-full absolute-bottom text-white text-center",
                            children: " see more"
                          })
                        })
                      })]
                    }) : /* @__PURE__ */ jsx(Fragment, {
                      children: /* @__PURE__ */ jsx("div", {
                        className: "flex flex-col sm:justify-center items-center",
                        children: /* @__PURE__ */ jsx("h3", {
                          className: "text-color-gray",
                          children: "first class coming soon"
                        })
                      })
                    })
                  })]
                })
              }), /* @__PURE__ */ jsxs(Col, {
                md: "4",
                className: "bg-white m-2  p-3 overflow-hidden shadow-sm sm:rounded-lg",
                children: [/* @__PURE__ */ jsx(Col, {
                  lg: "9",
                  className: "mb-5",
                  children: /* @__PURE__ */ jsx("h5", {
                    className: "fw-bold text-color-dark-blue",
                    children: "Requested Calls"
                  })
                }), /* @__PURE__ */ jsx("div", {
                  className: "",
                  children: calls.length > 0 ? /* @__PURE__ */ jsxs(Fragment, {
                    children: [calls.map((data, index) => {
                      return /* @__PURE__ */ jsx("a", {
                        href: `tel:${data.phone}`,
                        children: /* @__PURE__ */ jsxs("div", {
                          className: "flex",
                          children: [/* @__PURE__ */ jsx(Col, {
                            lg: "3",
                            children: /* @__PURE__ */ jsxs("div", {
                              style: {
                                width: "50px",
                                height: "50px"
                              },
                              className: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center",
                              children: [/* @__PURE__ */ jsx("h5", {
                                className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                                children: data.name.charAt(0).toUpperCase()
                              }), " "]
                            })
                          }), /* @__PURE__ */ jsxs(Col, {
                            className: "pt-0",
                            children: [/* @__PURE__ */ jsx("h6", {
                              className: "fw-bold ml-3",
                              children: data.phone
                            }), /* @__PURE__ */ jsx("p", {
                              children: data.name
                            }), /* @__PURE__ */ jsx("p", {
                              children: new Date(`${data.created_at}`).toLocaleDateString()
                            })]
                          }), /* @__PURE__ */ jsx(Col, {
                            lg: "3",
                            children: /* @__PURE__ */ jsxs("div", {
                              style: {
                                width: "50px",
                                height: "50px",
                                border: "solid 1px blue"
                              },
                              className: " rounded-full ml-2 flex flex-column-center items-center",
                              children: [/* @__PURE__ */ jsx(Telephone, {
                                className: "fs-5 text-color-dark-blue ml-auto mr-auto"
                              }), "  "]
                            })
                          })]
                        })
                      }, index);
                    }), course.length == 5 && /* @__PURE__ */ jsx(Fragment, {
                      children: /* @__PURE__ */ jsx(Link, {
                        href: route("DailyPlanView"),
                        children: /* @__PURE__ */ jsx("div", {
                          className: "w-full bg-primary pt-3 pb-3 rounded-full absolute-bottom text-white text-center",
                          children: " see more"
                        })
                      })
                    })]
                  }) : /* @__PURE__ */ jsx(Fragment, {
                    children: /* @__PURE__ */ jsx("div", {
                      className: "flex flex-col sm:justify-center items-center",
                      children: /* @__PURE__ */ jsx("h3", {
                        className: "text-color-gray",
                        children: "first class coming soon"
                      })
                    })
                  })
                })]
              })]
            })
          })
        })
      })
    })]
  });
}
export {
  AdminDashboard as default
};
