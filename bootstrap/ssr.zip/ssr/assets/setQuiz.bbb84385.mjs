import "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, useForm, Head, Link } from "@inertiajs/inertia-react";
import { Row, Col, Form, Alert } from "react-bootstrap";
/* empty css                 */import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
/* empty css                               */import "bootstrap";
import { CheckCircle } from "react-bootstrap-icons";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function setQuiz(props) {
  const {
    program,
    code,
    all_batch,
    flash
  } = usePage().props;
  const {
    data,
    setData,
    post,
    progress
  } = useForm({
    "question": "",
    "option1": "",
    "option2": "",
    "option3": "",
    "option4": "",
    "answer": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setData((data2) => ({
      ...data2,
      [key]: value
    }));
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    const method = {
      _method: "post"
    };
    Inertia.post(`/moderator/set-questions/${program.topic.split(" ").join("-")}/${program.id}`, {
      "data": data,
      "batchInfo": {
        "id": program.batch,
        "trainer": all_batch[0].trainerid,
        "course": program.id
      },
      method
    });
  };
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Moderator Page"
      }), /* @__PURE__ */ jsxs("h3", {
        className: "fs-4 text-color-blue",
        children: [" Update ", program.topic, " for ", program.program]
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Create Course"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-12xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsxs("div", {
          className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
          children: [/* @__PURE__ */ jsxs("div", {
            className: "p-6 border-b border-gray-200",
            children: [/* @__PURE__ */ jsxs("form", {
              method: "POST",
              onSubmit: HandleSubmit,
              className: "mt-5  max-w-3xl mx-auto sm:px-6 lg:px-8",
              children: [/* @__PURE__ */ jsx("h1", {
                children: "Quiz Page"
              }), /* @__PURE__ */ jsx(Row, {
                children: /* @__PURE__ */ jsxs(Col, {
                  children: [/* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      htmlFor: "file",
                      children: "Question"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      as: "textarea",
                      name: "question",
                      value: data.question,
                      onChange: HandleChange,
                      required: true
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      htmlFor: "file",
                      children: "Option A"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      name: "option1",
                      value: data.option1,
                      onChange: HandleChange,
                      required: true
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      htmlFor: "file",
                      children: "Option B"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      name: "option2",
                      value: data.option2,
                      onChange: HandleChange,
                      required: true
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      htmlFor: "file",
                      children: "Option C"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      name: "option3",
                      value: data.option3,
                      onChange: HandleChange,
                      required: true
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      htmlFor: "file",
                      children: "Option D"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      name: "option4",
                      value: data.option4,
                      onChange: HandleChange,
                      required: true
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-4",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      htmlFor: "file",
                      children: "The Answer"
                    }), /* @__PURE__ */ jsxs(Form.Select, {
                      as: "textarea",
                      name: "answer",
                      value: data.answer,
                      onChange: HandleChange,
                      variant: "success",
                      required: true,
                      children: [/* @__PURE__ */ jsx("option", {
                        value: "",
                        children: "select "
                      }), /* @__PURE__ */ jsx("option", {
                        value: "option1",
                        children: "option A "
                      }), /* @__PURE__ */ jsx("option", {
                        value: "option2",
                        children: "option B "
                      }), /* @__PURE__ */ jsx("option", {
                        value: "option3",
                        children: "option C "
                      }), /* @__PURE__ */ jsx("option", {
                        value: "option4",
                        children: "option D "
                      })]
                    })]
                  }), /* @__PURE__ */ jsx(PrimaryButton, {
                    className: "mt-4",
                    children: "Submit"
                  })]
                })
              })]
            }), flash.message && /* @__PURE__ */ jsx(Alert, {
              variant: "success",
              children: flash.message
            }), "                            "]
          }), program.action == "pending" ? /* @__PURE__ */ jsx("div", {
            className: "p-2",
            children: /* @__PURE__ */ jsxs(Link, {
              className: "flex",
              style: {
                width: "100%"
              },
              href: `/moderator/ready-quesiton/${program.id}`,
              children: ["click if ready ", /* @__PURE__ */ jsx("span", {
                className: "mt-1 ml-2",
                children: /* @__PURE__ */ jsx(CheckCircle, {})
              })]
            })
          }) : /* @__PURE__ */ jsx("span", {
            className: "mt-1 pl-2 p-2 ml-2",
            children: /* @__PURE__ */ jsx(CheckCircle, {
              style: {
                color: "green"
              }
            })
          })]
        })
      })
    })]
  });
}
export {
  setQuiz as default
};
