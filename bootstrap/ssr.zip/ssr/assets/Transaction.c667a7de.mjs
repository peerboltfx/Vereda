import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { useForm, usePage, Link, Head } from "@inertiajs/inertia-react";
import { Row, Col, Alert, Spinner } from "react-bootstrap";
/* empty css                 */import { Book } from "react-bootstrap-icons";
import "@inertiajs/inertia";
import axios from "axios";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Users(props) {
  const {
    processing
  } = useForm();
  const {
    assignment,
    programs,
    transactions
  } = usePage().props;
  const [values, setValues] = useState({
    "search": ""
  });
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const [showPop, setShowpop] = useState(false);
  const [errorPop, setErrorPop] = useState(false);
  const [loading, setLoading] = useState(false);
  if (showPop == true || errorPop == true) {
    setInterval(() => {
      setShowpop(false);
      setErrorPop(false);
    }, 1e3 * 10);
  }
  const found = programs.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(values.search)));
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Student"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Transactions"
        })]
      }),
      Search: /* @__PURE__ */ jsxs("div", {
        className: "Search-container",
        children: [/* @__PURE__ */ jsx("input", {
          onClick: HandleShow,
          type: "text",
          name: "search",
          value: values.search,
          onChange: HandleChange
        }), /* @__PURE__ */ jsxs("div", {
          onBlur: () => setShow(false),
          tabIndex: "0",
          style: {
            height: "400px",
            overflowY: "scroll"
          },
          className: show ? "Searched bg-white active p-2" : "Searched",
          children: [/* @__PURE__ */ jsx("h6", {
            className: "fw-bold text-color-dark-blue text-center",
            children: "Search Course"
          }), found.map((data, index) => {
            return /* @__PURE__ */ jsx("div", {
              className: "bg-white pt-2 mt-1 pb-2 pl-4 shadow-sm sm:rounded-lg",
              children: /* @__PURE__ */ jsx(Row, {
                children: /* @__PURE__ */ jsx(Col, {
                  mx: "6",
                  children: /* @__PURE__ */ jsx(Link, {
                    href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                    className: "text-color-dark-blue",
                    children: /* @__PURE__ */ jsxs("div", {
                      className: "flex pb-3",
                      children: [/* @__PURE__ */ jsx(Col, {
                        md: "2",
                        className: "pt-0 ",
                        children: /* @__PURE__ */ jsx(Book, {
                          style: {
                            fontSize: "30px",
                            color: "#DC4731"
                          },
                          className: "pl-1"
                        })
                      }), /* @__PURE__ */ jsx(Col, {
                        md: "10",
                        className: "fs-5 fw-bold pl-0 ml-4 text-color-dark-blue",
                        children: data.program
                      })]
                    })
                  })
                })
              })
            }, index);
          })]
        })]
      }),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Transactions"
      }), /* @__PURE__ */ jsxs("div", {
        className: " p-3",
        children: [showPop ? /* @__PURE__ */ jsx(Alert, {
          variant: "success",
          className: "mt-2",
          children: "successfully deleted the content"
        }) : "", transactions ? /* @__PURE__ */ jsx(Fragment, {
          children: transactions.map((data, index) => {
            return /* @__PURE__ */ jsx("div", {
              className: "row header-block",
              children: /* @__PURE__ */ jsxs(Col, {
                md: "6",
                lg: "6",
                sm: "6",
                className: "overflow-hidden p-4 bg-white shadow-sm sm:rounded-lg",
                children: [/* @__PURE__ */ jsx("h4", {
                  className: "mt-2",
                  children: data.program
                }), /* @__PURE__ */ jsxs("div", {
                  className: "mt-2",
                  children: [/* @__PURE__ */ jsx("b", {
                    children: " order id"
                  }), " : ", data.orderId]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "mt-2",
                  children: [/* @__PURE__ */ jsx("b", {
                    children: "receipt "
                  }), ": ", data.receipt]
                }), /* @__PURE__ */ jsx("div", {
                  className: "text-sm text-danger",
                  children: "(Use receipt as referrence for payment)"
                }), /* @__PURE__ */ jsxs("div", {
                  className: "mt-2",
                  children: ["INR ", /* @__PURE__ */ jsx("b", {
                    children: data.amount
                  })]
                }), /* @__PURE__ */ jsx("div", {
                  className: "mt-2",
                  children: new Date(`${data.created_at}`).toLocaleDateString()
                }), /* @__PURE__ */ jsxs("div", {
                  className: "mt-2 pb-2 flex",
                  children: [data.action == "pending" ? /* @__PURE__ */ jsx("form", {
                    className: "fw-bold danger",
                    method: "POST",
                    onSubmit: (e) => {
                      e.preventDefault();
                      axios.post(`/checkout/cancel-order/${data.orderId}`).then((res) => {
                        if (res) {
                          res.data;
                          setShowpop(true);
                          setLoading(false);
                        }
                      }).catch((err) => {
                        if (err) {
                          setLoading(false);
                          setErrorPop(true);
                        }
                      });
                    },
                    children: /* @__PURE__ */ jsx("button", {
                      className: "fw-bold rounded-full p-2 bg-secondarys mr-2 ",
                      onClick: () => {
                        setLoading(true);
                      },
                      processing,
                      type: "submit",
                      children: loading ? /* @__PURE__ */ jsx("span", {
                        className: "mr-5 ml-5",
                        children: /* @__PURE__ */ jsx(Spinner, {
                          animation: "border",
                          size: "sm",
                          className: "ml-5 mr-5",
                          role: "status"
                        })
                      }) : "Cancel Loading"
                    })
                  }) : "", /* @__PURE__ */ jsxs(Link, {
                    className: "",
                    href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                    children: [" ", /* @__PURE__ */ jsx("button", {
                      style: {
                        width: "100px"
                      },
                      className: data.action == "pending" ? "bg-color-gold text-white p-2 rounded-full" : "bg-primaries text-white p-2 rounded-full",
                      children: data.action
                    })]
                  })]
                }), errorPop ? /* @__PURE__ */ jsx(Alert, {
                  variant: "danger",
                  className: "mt-2",
                  children: "Error trying to perform operation"
                }) : ""]
              })
            }, index);
          })
        }) : ""]
      })]
    })
  });
}
export {
  Users as default
};
