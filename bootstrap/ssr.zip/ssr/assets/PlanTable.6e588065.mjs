import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
import { Alert, Table } from "react-bootstrap";
/* empty css                 */import { PencilSquare, CheckCircleFill, Trash, Repeat } from "react-bootstrap-icons";
import Pagination from "@mui/material/Pagination";
import { u as usePagination } from "./pagination.eea5d8a8.mjs";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Plantable(props) {
  const {
    plans,
    flash
  } = usePage().props;
  let [page, setPage] = useState(1);
  const PER_PAGE = 10;
  const longEnUsFormatter = new Intl.DateTimeFormat("en-GB", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour12: true
  });
  const count = Math.ceil(plans.length / PER_PAGE);
  const _DATA = usePagination(plans, PER_PAGE);
  const handleChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Admin Page / Moderator"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Moderator Table"
        })]
      }),
      childs: /* @__PURE__ */ jsx(Fragment, {}),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Full Stack Developement"
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsxs("div", {
            className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
            children: [flash.message && /* @__PURE__ */ jsx("div", {
              className: "p-3",
              children: /* @__PURE__ */ jsx(Alert, {
                className: "mt-5 text-center p-3",
                variant: "success",
                children: flash.message
              })
            }), /* @__PURE__ */ jsxs("div", {
              className: "p-6 plan-table border-b border-gray-200",
              children: [/* @__PURE__ */ jsxs(Table, {
                striped: true,
                bordered: true,
                hover: true,
                children: [/* @__PURE__ */ jsx("thead", {
                  children: /* @__PURE__ */ jsxs("tr", {
                    children: [/* @__PURE__ */ jsx("th", {
                      children: "#"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "Topic"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "Batch"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "Date"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "time"
                    }), /* @__PURE__ */ jsx("td", {
                      children: "session type"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "program"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "action"
                    })]
                  })
                }), /* @__PURE__ */ jsx("tbody", {
                  children: _DATA.currentData().map((data, index) => {
                    return /* @__PURE__ */ jsxs("tr", {
                      children: [/* @__PURE__ */ jsx("td", {
                        children: index
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.topic.split(" ").splice(0, 3).join(" ") + "..."
                      }), /* @__PURE__ */ jsxs("td", {
                        children: ["batch ", data.batch]
                      }), /* @__PURE__ */ jsx("td", {
                        children: longEnUsFormatter.format(new Date(`${data.date}`))
                      }), /* @__PURE__ */ jsx("td", {}), /* @__PURE__ */ jsx("td", {
                        children: data.sessiontype
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.program
                      }), /* @__PURE__ */ jsxs("td", {
                        className: "flex",
                        children: [data.action == "pending" && /* @__PURE__ */ jsxs(Link, {
                          href: `/moderator/create-course/${data.program_code}/en/${data.id}`,
                          children: [/* @__PURE__ */ jsx(PencilSquare, {}), " "]
                        }) || data.action == "created" && /* @__PURE__ */ jsx(CheckCircleFill, {
                          style: {
                            color: "green"
                          }
                        }), /* @__PURE__ */ jsx(Link, {
                          className: "ml-4",
                          href: `/moderator/delete-course/${data.id}`,
                          children: /* @__PURE__ */ jsx(Trash, {})
                        }), /* @__PURE__ */ jsx(Link, {
                          className: "ml-4",
                          href: `/moderator/reupload-course/${data.id}`,
                          children: /* @__PURE__ */ jsx(Repeat, {})
                        })]
                      })]
                    }, index);
                  })
                })]
              }), /* @__PURE__ */ jsx("div", {
                className: "flex items-center flex-col sm:justify-center",
                children: /* @__PURE__ */ jsx(Pagination, {
                  count,
                  size: "large",
                  page,
                  variant: "outlined",
                  shape: "circular",
                  onChange: handleChange
                })
              })]
            })]
          })
        })
      })]
    })
  });
}
export {
  Plantable as default
};
