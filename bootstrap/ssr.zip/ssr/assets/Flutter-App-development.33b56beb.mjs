const Flutter = "/build/assets/Flutter-App-development.1a92db99.webp";
export {
  Flutter as F
};
