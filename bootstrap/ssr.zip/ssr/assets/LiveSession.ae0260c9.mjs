import { useState, useRef } from "react";
import "react-dom";
import "simple-peer";
import "pusher-js";
import { j as jsx } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
class MediaHandler {
  getPermission() {
    return new Promise((res, rej) => {
      navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      }).then((stream) => {
        res(stream);
      }).catch((err) => {
        throw new Error(`Unable to fetch stream ${err}`);
      });
    });
  }
}
function LiveSession() {
  const [session, setSession] = useState({
    hasMedia: false,
    otherUserId: null
  });
  const VideoRef = useRef(null);
  const mediaHandler = new MediaHandler();
  mediaHandler.getPermission().then((stream) => {
    setSession({
      hasMedia: true
    });
    let video = VideoRef.current;
    video.srcObject = stream;
    video.play();
  }).catch((err) => {
    alert(err);
  });
  return /* @__PURE__ */ jsx("div", {
    children: /* @__PURE__ */ jsx("video", {
      ref: VideoRef
    })
  });
}
export {
  LiveSession as default
};
