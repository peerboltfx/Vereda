import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
import { Table, Form } from "react-bootstrap";
/* empty css                 */import "@inertiajs/inertia";
import "react-bootstrap/Modal";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const ElementMaker = (props) => {
  return /* @__PURE__ */ jsx("span", {
    children: props.showInput ? /* @__PURE__ */ jsx(Form.Control, {
      style: {
        width: "100px"
      },
      type: "text",
      value: props.value,
      onChange: props.handleChange,
      onBlur: props.handleBlur,
      name: props.HandleName,
      autoFocus: true
    }) : /* @__PURE__ */ jsx("span", {
      onDoubleClick: props.HandleDoubleClick,
      children: props.Handlevalue
    })
  });
};
function Students(props) {
  const {
    students
  } = usePage().props;
  const [showInput, setShowInput] = useState(true);
  const [values, setValues] = useState({
    "batch": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Admin Page / Moderator"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Moderator Table"
        })]
      }),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Students Table"
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsx("div", {
            className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
            children: /* @__PURE__ */ jsx("div", {
              style: {
                overflowY: "scroll"
              },
              className: "p-6 border-b border-gray-200",
              children: /* @__PURE__ */ jsxs(Table, {
                striped: true,
                bordered: true,
                hover: true,
                children: [/* @__PURE__ */ jsx("thead", {
                  children: /* @__PURE__ */ jsxs("tr", {
                    children: [/* @__PURE__ */ jsx("th", {
                      children: "#"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "name"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "email"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "phone"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "role"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "Batch"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "Program"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "action"
                    })]
                  })
                }), /* @__PURE__ */ jsx("tbody", {
                  children: students.map((data, index) => {
                    return /* @__PURE__ */ jsxs("tr", {
                      children: [/* @__PURE__ */ jsx("td", {
                        children: data.id
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.name
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.email
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.phone
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.role
                      }), /* @__PURE__ */ jsx("td", {
                        children: /* @__PURE__ */ jsx(ElementMaker, {
                          Handlevalue: data.batch ? data.batch : "Null",
                          value: values.batch,
                          HandleDoubleClick: () => setShowInput(true),
                          handleBlur: () => setShowInput(false),
                          showInput,
                          handleChange: HandleChange,
                          HandleName: "batch"
                        })
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.program
                      }), /* @__PURE__ */ jsx("td", {
                        children: /* @__PURE__ */ jsx(Link, {
                          href: `/edit-moderator/${data.id}`,
                          children: "edit"
                        })
                      })]
                    }, index);
                  })
                })]
              })
            })
          })
        })
      })]
    })
  });
}
export {
  Students as default
};
