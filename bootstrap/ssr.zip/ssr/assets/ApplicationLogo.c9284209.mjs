import "react";
import { L as Logo } from "./logo.d6c74f57.mjs";
import { j as jsx } from "../ssr.mjs";
function ApplicationLogo({
  className,
  width
}) {
  return /* @__PURE__ */ jsx("img", {
    src: Logo,
    width,
    alt: Logo
  });
}
export {
  ApplicationLogo as A
};
