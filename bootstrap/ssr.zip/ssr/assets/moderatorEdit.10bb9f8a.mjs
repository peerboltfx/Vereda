import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
import { Card, Row, Col, Form } from "react-bootstrap";
/* empty css                 */import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function moderatorEdit(props) {
  const {
    moderator
  } = usePage().props;
  const [values, setValue] = useState({
    "roles": "",
    "amount": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const HamdleSubmit = (e) => {
    e.preventDefault();
    Inertia.post(`/admin/edit/moderator/${moderator[0].id}`, values);
  };
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Admin Page"
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-4 text-color-blue",
        children: " Edit User Role"
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Edit - " + moderator[0].name
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-2xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 border-b border-gray-200",
            children: /* @__PURE__ */ jsxs(Card, {
              children: [/* @__PURE__ */ jsxs(Card.Header, {
                children: [" ", /* @__PURE__ */ jsx("h1", {
                  className: "ts-3 text-center tw-bold",
                  children: moderator[0].name
                })]
              }), /* @__PURE__ */ jsx(Card.Body, {
                children: /* @__PURE__ */ jsxs("ul", {
                  style: {
                    listStyle: "none"
                  },
                  children: [/* @__PURE__ */ jsxs("li", {
                    className: "mt-3 ",
                    children: [/* @__PURE__ */ jsx("b", {
                      className: "mr-5 ",
                      children: "Email - : - "
                    }), moderator[0].email]
                  }), /* @__PURE__ */ jsxs("li", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx("b", {
                      className: "mr-5 ",
                      children: "Phone - : - "
                    }), moderator[0].phone]
                  }), /* @__PURE__ */ jsxs("form", {
                    method: "POST",
                    className: "mt-5",
                    onSubmit: HamdleSubmit,
                    children: [/* @__PURE__ */ jsxs(Row, {
                      className: "mt-2 header-block",
                      children: [/* @__PURE__ */ jsx(Col, {
                        children: /* @__PURE__ */ jsx(Form.Label, {
                          htmlFor: "roles",
                          children: "Roles"
                        })
                      }), /* @__PURE__ */ jsx(Col, {
                        children: /* @__PURE__ */ jsxs(Form.Select, {
                          value: values.roles,
                          onChange: HandleChange,
                          name: "roles",
                          children: [/* @__PURE__ */ jsx("option", {
                            value: moderator[0].role,
                            children: moderator[0].role
                          }), /* @__PURE__ */ jsx("option", {
                            value: "admin",
                            children: "admin"
                          }), /* @__PURE__ */ jsx("option", {
                            value: "moderator",
                            children: "moderator"
                          }), /* @__PURE__ */ jsx("option", {
                            value: "student",
                            children: "student"
                          })]
                        })
                      })]
                    }), /* @__PURE__ */ jsxs(Row, {
                      className: "mt-4 header-block",
                      children: [/* @__PURE__ */ jsx(Col, {
                        children: /* @__PURE__ */ jsx(Form.Label, {
                          htmlFor: "roles",
                          children: "Send Discount"
                        })
                      }), /* @__PURE__ */ jsx(Col, {
                        children: /* @__PURE__ */ jsx(Form.Control, {
                          type: "number",
                          value: values.amount,
                          onChange: HandleChange,
                          name: "amount"
                        })
                      })]
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "3",
                      children: /* @__PURE__ */ jsx(PrimaryButton, {
                        className: "mt-4",
                        children: "Submit"
                      })
                    })]
                  })]
                })
              })]
            })
          })
        })
      })
    })]
  });
}
export {
  moderatorEdit as default
};
