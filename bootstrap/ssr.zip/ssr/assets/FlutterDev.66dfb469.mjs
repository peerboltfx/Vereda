import { useState } from "react";
/* empty css                 */import { RouterDom } from "./RRouterDom.b83a7118.mjs";
import Container from "react-bootstrap/Container";
import { CheckCircleFill, Check } from "react-bootstrap-icons";
import { F as Faqs, u as ujjwal, H as Hermant, v as vishal } from "./Faq.41215779.mjs";
import { Col } from "react-bootstrap";
import { usePage, Head } from "@inertiajs/inertia-react";
import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeaderTwo, C as CourseSideDetail, A as Author } from "./course-detail.0fa1020d.mjs";
import { F as Flutter } from "./Flutter-App-development.33b56beb.mjs";
import { O as OffCanvasExample } from "./DropBottom.c156e3a4.mjs";
import Form from "react-bootstrap/Form";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { L as Logo } from "./logo.d6c74f57.mjs";
/* empty css                   *//* empty css                     */import { a as jsxs, j as jsx, F as Fragment } from "../ssr.mjs";
import "@inertiajs/inertia";
import "react-bootstrap/Button";
import "react-bootstrap/Offcanvas";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const flutter = "/build/assets/Picture1.238d9e44.png";
function FlutterDev(props) {
  const {
    pricing,
    programs,
    name,
    flash
  } = usePage().props;
  const [enrollFloat, setEnroll] = useState(false);
  useState(false);
  useState(false);
  useState(false);
  useState(false);
  usePage().props;
  const HandleEnroll = () => {
    if (window.scrollY > 500 && window.scrollY < 2300) {
      setEnroll(true);
    } else {
      setEnroll(false);
    }
  };
  window.addEventListener("scroll", HandleEnroll);
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const [values, setValue] = useState({
    "name": "",
    "email": "",
    "phone": "",
    "country": "",
    "state": "",
    "occupation": "",
    "studies": "",
    "language": ""
  });
  const HandleChange = (e) => {
    const key = e.target.id;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/request/call", values);
  };
  const handleClose = () => setShow(false);
  return /* @__PURE__ */ jsxs("div", {
    children: [/* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsxs(Head, {
      title: name.program,
      children: [/* @__PURE__ */ jsx("meta", {
        property: "og:Vereda.co.in",
        content: "https://vereda.co.in/Program/Flutter-Development-Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Flutter Development Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Become expert in developing web and mobile applications using Flutter Development."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        itemProp: "image",
        content: flutter
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/Program/Flutter-Development-Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/Program/Flutter-Development-Program"
      }), /* @__PURE__ */ jsx("meta", {
        property: "description",
        content: "Become expert in developing web and mobile applications using Flutter Development."
      })]
    }), /* @__PURE__ */ jsx(PageHeaderTwo, {
      programImage: Flutter,
      title: name.program,
      subject: "Learn Flutter Development and become a professional mobile developer with certificate"
    }), /* @__PURE__ */ jsx("div", {
      className: "course-single-section padding-tb section-bg",
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "row justify-content-center",
          children: [/* @__PURE__ */ jsx("div", {
            className: "col-lg-8",
            children: /* @__PURE__ */ jsxs("div", {
              className: "main-part",
              children: [/* @__PURE__ */ jsx("div", {
                className: "course-item",
                children: /* @__PURE__ */ jsx("div", {
                  className: "course-inner",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "ml-2",
                    children: [/* @__PURE__ */ jsx("h3", {
                      children: "Course Overview"
                    }), /* @__PURE__ */ jsx("p", {
                      children: "This program sets to keep you equiped with skills in developing Flutter applications. In this program You will be able to build a Hello world Fluuter application using Code Server development environment."
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "card p-5 pt-3 mb-5",
                      children: [/* @__PURE__ */ jsx("h3", {
                        className: "fs-6 fw-bold",
                        children: "6 Months "
                      }), /* @__PURE__ */ jsx("p", {}), /* @__PURE__ */ jsxs("p", {
                        className: "pb-4",
                        children: ["3 Days live session ", /* @__PURE__ */ jsx("br", {}), "3 Days Practical session"]
                      }), /* @__PURE__ */ jsx("h3", {
                        className: "fs-6 fw-bold",
                        children: "Language "
                      }), /* @__PURE__ */ jsx("p", {
                        className: "pb-4",
                        children: "English and Hindi"
                      }), /* @__PURE__ */ jsx("h3", {
                        className: "fs-6 fw-bold",
                        children: "Service cost "
                      }), /* @__PURE__ */ jsxs("p", {
                        className: "pb-4",
                        children: [/* @__PURE__ */ jsx("span", {
                          className: "fw-bold",
                          children: "INR"
                        }), " ", pricing.toString("fi-FI").replace(/\B(?=(\d{3})+(?!\d))/g, ","), " "]
                      })]
                    }), /* @__PURE__ */ jsx("h4", {
                      children: "What You'll Learn in This Course:"
                    }), /* @__PURE__ */ jsxs(Col, {
                      className: "block col pb-4",
                      children: [/* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: " Onboarding, Introduction to Flutter"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: /* @__PURE__ */ jsxs("div", {
                              children: [/* @__PURE__ */ jsxs("div", {
                                className: "flex pt-2",
                                children: [/* @__PURE__ */ jsx("span", {
                                  style: {
                                    position: "relative",
                                    top: 3,
                                    marginRight: 5
                                  },
                                  children: /* @__PURE__ */ jsx(Check, {})
                                }), " ", /* @__PURE__ */ jsx("p", {
                                  children: "In this section you will learn about the various data structures"
                                })]
                              }), /* @__PURE__ */ jsxs("div", {
                                className: "flex pt-2",
                                children: [/* @__PURE__ */ jsx("span", {
                                  style: {
                                    position: "relative",
                                    top: 3,
                                    marginRight: 5
                                  },
                                  children: /* @__PURE__ */ jsx(Check, {})
                                }), " ", /* @__PURE__ */ jsx("p", {
                                  children: "the core library in dart data structure ( List, Map, Set)"
                                })]
                              }), /* @__PURE__ */ jsxs("div", {
                                className: "flex pt-2",
                                children: [/* @__PURE__ */ jsx("span", {
                                  style: {
                                    position: "relative",
                                    top: 3,
                                    marginRight: 5
                                  },
                                  children: /* @__PURE__ */ jsx(Check, {})
                                }), " ", /* @__PURE__ */ jsx("p", {
                                  children: "Functionalities of Dart core library."
                                })]
                              })]
                            })
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: " Introduction to Dart programming language"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: /* @__PURE__ */ jsxs("div", {
                              className: "flex pt-2",
                              children: [/* @__PURE__ */ jsx("span", {
                                style: {
                                  position: "relative",
                                  top: 3,
                                  marginRight: 5
                                },
                                children: /* @__PURE__ */ jsx(Check, {})
                              }), " ", /* @__PURE__ */ jsx("p", {
                                children: "Learn about Dart and basic programming concepts"
                              })]
                            })
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: " Planning and architecture with demo project"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: /* @__PURE__ */ jsxs("div", {
                              className: "flex pt-2",
                              children: [/* @__PURE__ */ jsx("span", {
                                style: {
                                  position: "relative",
                                  top: 3,
                                  marginRight: 5
                                },
                                children: /* @__PURE__ */ jsx(Check, {})
                              }), " ", /* @__PURE__ */ jsx("p", {
                                children: "In this section, trainer will build a Flutter app for practical observation and understanding the end to end development and concept of using Flutter."
                              })]
                            })
                          })]
                        })]
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "col skills",
                        children: [/* @__PURE__ */ jsx("h2", {
                          children: /* @__PURE__ */ jsx(CheckCircleFill, {
                            className: "skill-mark"
                          })
                        }), /* @__PURE__ */ jsxs("ul", {
                          children: [/* @__PURE__ */ jsx("li", {
                            className: "fw-bold pt-3",
                            children: " Data Structure and Collections in Dart"
                          }), /* @__PURE__ */ jsx("li", {
                            className: "fs-4 pb-3",
                            children: /* @__PURE__ */ jsxs("div", {
                              children: [/* @__PURE__ */ jsxs("div", {
                                className: "flex pt-2",
                                children: [/* @__PURE__ */ jsx("span", {
                                  style: {
                                    position: "relative",
                                    top: 3,
                                    marginRight: 5
                                  },
                                  children: /* @__PURE__ */ jsx(Check, {})
                                }), " ", /* @__PURE__ */ jsx("p", {
                                  children: "In this section you will learn about the various data structures"
                                })]
                              }), /* @__PURE__ */ jsxs("div", {
                                className: "flex pt-2",
                                children: [/* @__PURE__ */ jsx("span", {
                                  style: {
                                    position: "relative",
                                    top: 3,
                                    marginRight: 5
                                  },
                                  children: /* @__PURE__ */ jsx(Check, {})
                                }), " ", /* @__PURE__ */ jsx("p", {
                                  children: "the core library in dart data structure ( List, Map, Set)"
                                })]
                              }), /* @__PURE__ */ jsxs("div", {
                                className: "flex pt-2",
                                children: [/* @__PURE__ */ jsx("span", {
                                  style: {
                                    position: "relative",
                                    top: 3,
                                    marginRight: 5
                                  },
                                  children: /* @__PURE__ */ jsx(Check, {})
                                }), " ", /* @__PURE__ */ jsx("p", {
                                  children: "Functionalities of Dart core library."
                                })]
                              })]
                            })
                          })]
                        })]
                      })]
                    }), /* @__PURE__ */ jsx("div", {
                      children: /* @__PURE__ */ jsx("div", {
                        className: "",
                        children: /* @__PURE__ */ jsx("div", {
                          className: "course-video-title mb-5",
                          children: /* @__PURE__ */ jsx("h4", {
                            children: "Course Content"
                          })
                        })
                      })
                    })]
                  })
                })
              }), /* @__PURE__ */ jsx("div", {
                className: "course-video",
                children: /* @__PURE__ */ jsx("div", {
                  className: "course-video-content"
                })
              })]
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "col-lg-4",
            children: /* @__PURE__ */ jsx("div", {
              className: "sidebar-part",
              children: /* @__PURE__ */ jsx(CourseSideDetail, {
                price: pricing.toString("fi-FI").replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                enroll: `/en/${name.program.split(" ").join("-")}/session/${name.random}`,
                tweet: `https://twitter.com/intent/tweet?text=Awesomee%20Blog!&url=vereda.co.in/Program/${name.program.split(" ").join("-")}`,
                linked: `https://www.linkedin.com/sharing/share-offsite/?url=vereda.co.in/Program/${name.program.split(" ").join("-")}`,
                ping: `https://www.facebook.com/sharer.php?u=vereda.co.in/Program/${name.program.split(" ").join("-")}&quote=Awesome%20Blog!`
              })
            })
          })]
        })
      })
    }), /* @__PURE__ */ jsx(RouterDom, {
      children: /* @__PURE__ */ jsxs(Container, {
        children: [/* @__PURE__ */ jsxs("div", {
          className: "flex header-block",
          children: [/* @__PURE__ */ jsx(Col, {
            lg: "6",
            md: "6",
            sm: "12",
            children: /* @__PURE__ */ jsxs("div", {
              className: " p-2 ",
              children: [/* @__PURE__ */ jsx("h4", {
                className: "fw-bold pl-1 pt-2 pb-4",
                children: "Learn to Build  Hybrid Application from Scratch Using FLutter"
              }), /* @__PURE__ */ jsxs("div", {
                className: "flex header-block",
                children: [/* @__PURE__ */ jsxs(Col, {
                  lg: "6",
                  md: "6",
                  sm: "12",
                  children: [/* @__PURE__ */ jsx("p", {
                    children: "Learn a new tool or skill in an interactive, hands on environment "
                  }), /* @__PURE__ */ jsx("p", {
                    children: "You'll gain access to software and tools iin cloud workspace - no download required"
                  })]
                }), /* @__PURE__ */ jsx(Col, {
                  lg: "6",
                  md: "6",
                  sm: "12",
                  className: "col item-center w-100 flex items-center",
                  children: /* @__PURE__ */ jsx("img", {
                    src: flutter,
                    width: "200px"
                  })
                })]
              }), /* @__PURE__ */ jsxs("p", {
                className: "pl-1 pt-2 mt-4 fw-bold pb-4",
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Common Job titles:"
                }), "Flutter Application Developer, Junior Flutter Developer, Full-stack Developer, Front-end Developer, etc."]
              })]
            })
          }), /* @__PURE__ */ jsx(Col, {
            lg: "6",
            md: "6",
            sm: "12",
            children: /* @__PURE__ */ jsx(Faqs, {})
          })]
        }), /* @__PURE__ */ jsxs("div", {
          id: "trainers",
          className: "",
          children: [/* @__PURE__ */ jsx("h3", {
            className: "pt-4 pb-3",
            children: "Instructors"
          }), /* @__PURE__ */ jsxs("div", {
            className: "row header-block trainer",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx(Author, {
                teacherSrc: ujjwal,
                name: "Ujjwal Verma",
                task: "Lead Software Developer IIT",
                linkedin: "https://www.linkedin.com/in/ujjwalverma007"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx(Author, {
                teacherSrc: Hermant,
                name: "Hermant Kumar",
                task: "Co-Founder B. Tech",
                linkedin: "https://www.linkedin.com/in/hermant-kumar-sedhanshu-42142390"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx(Author, {
                teacherSrc: vishal,
                name: "Vishal Pankaj",
                task: "Technical domain Expert",
                linkedin: "https://www.linkedin.com/in/vishal-pankaj-30503a103"
              })
            })]
          }), /* @__PURE__ */ jsxs("div", {
            className: "call mt-4 mb-4",
            children: [" ", /* @__PURE__ */ jsx("button", {
              onClick: handleShow,
              className: "full-size-btn capitalize full-width-btn",
              children: "request call back"
            })]
          })]
        })]
      })
    }), /* @__PURE__ */ jsx(OffCanvasExample, {
      show,
      onHide: handleClose,
      title: /* @__PURE__ */ jsx(Fragment, {
        children: /* @__PURE__ */ jsxs("div", {
          className: "block",
          children: [/* @__PURE__ */ jsx("h4", {
            children: /* @__PURE__ */ jsx("a", {
              href: "/",
              className: "logo-anchor item-center",
              children: /* @__PURE__ */ jsx("img", {
                src: Logo,
                width: "100px",
                alt: Logo,
                srcSet: ""
              })
            })
          }), /* @__PURE__ */ jsx("h3", {
            className: "fw-bold",
            children: "Talk to Our Expert"
          })]
        })
      }),
      children: /* @__PURE__ */ jsx(Fragment, {
        children: /* @__PURE__ */ jsx(Container, {
          children: /* @__PURE__ */ jsxs("form", {
            onSubmit: handleSubmit,
            children: [/* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              onChange: HandleChange,
              value: values.name,
              id: "name",
              required: true,
              placeholder: "Name",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "email",
              onChange: HandleChange,
              value: values.email,
              id: "email",
              required: true,
              placeholder: "abcd@example.com ",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "number",
              id: "phone",
              value: values.phone,
              onChange: HandleChange,
              required: true,
              placeholder: "+9 9123 567 98",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              value: values.country,
              id: "country",
              onChange: HandleChange,
              required: true,
              placeholder: "Country",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "occupation",
              value: values.occupation,
              onChange: HandleChange,
              required: true,
              placeholder: "Occupation",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "state",
              value: values.state,
              onChange: HandleChange,
              required: true,
              placeholder: "State",
              className: "mt-2"
            }), /* @__PURE__ */ jsxs(Form.Select, {
              onChange: HandleChange,
              vlaue: values.language,
              id: "language",
              required: true,
              className: "mt-2",
              children: [/* @__PURE__ */ jsx("option", {
                children: "select Language"
              }), /* @__PURE__ */ jsx("option", {
                value: "English",
                children: "English"
              }), /* @__PURE__ */ jsx("option", {
                value: "Hindi",
                children: "Hindi"
              })]
            }), /* @__PURE__ */ jsx(PrimaryButton, {
              className: "mt-5",
              children: "submit"
            }), flash.message && /* @__PURE__ */ jsx("div", {
              className: "alert alert-success",
              children: "Request sent successfully"
            })]
          })
        })
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
}
export {
  FlutterDev as default
};
