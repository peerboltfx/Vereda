import "react";
import Container from "react-bootstrap/Container";
import { usePage, Head } from "@inertiajs/inertia-react";
/* empty css                 */import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeader } from "./pageheader.c3637c95.mjs";
/* empty css                   */import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "react-bootstrap";
import "@inertiajs/inertia";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function PrivacyPolicy(props) {
  usePage().props;
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeader, {
      title: "Privacy Policy",
      curPage: "Privacy"
    }), /* @__PURE__ */ jsxs(Head, {
      title: "Privacy Policy",
      children: [/* @__PURE__ */ jsx("meta", {
        name: "description",
        content: "welcome to Vereda.co.in, one of the leading digital learning in India."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:Vereda.co.in",
        content: "https://vereda.co.in"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Vereda Privacy Policy"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Here is everything you need to know about how we use your personal data."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        content: "../Images/banner.jpg"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/pages/privacy-policy"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in"
      })]
    }), /* @__PURE__ */ jsx("section", {
      children: /* @__PURE__ */ jsxs(Container, {
        className: "mb-5 pb-5",
        children: [/* @__PURE__ */ jsx("h4", {
          className: "fw-bold p-4 mb-5 pb-4",
          children: "Here is everything you need to know about how we use your personal data."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4",
            children: "1. What Information do we collect and what do we do with it?"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5",
          children: "When you enrol as a student or subscriber (\u201Clearner\u201D) on our site or related courses, as part of the enrolling process, we collect the personal information you give us such as your name and email address."
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5",
          children: "Email marketing: we may send you emails about our site and related course(s), registration, course content, your course progress or other updates. We may also use your email to inform you about changes to the course, survey you about your usage, or collect your opinion."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4",
            children: "2. How do you get my consent?"
          })
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-5",
          children: ["When you provide us with personal information to become a learner on our site, make a purchase, or participate in the course, you imply that you consent to our collecting it and using it for that specific reason only. ", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "If we ask for your personal information for a secondary reason, like marketing, we will either ask you directly for your expressed consent or provide you with an opportunity to say no."]
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-2",
          children: [/* @__PURE__ */ jsx("b", {
            children: "How do I withdraw my consent?"
          }), "If after you opt-in, you change your mind, you may withdraw your consent for us to contact you, for the continued collection, use or disclosure of your information, at any time, by contacting us at", " ", " ", /* @__PURE__ */ jsx("a", {
            href: "mailto:>support@vereda.co.in",
            children: "support@vereda.co.in"
          })]
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4",
            children: "3. Disclosure"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-4",
          children: "We may disclose your personal information if we are required by law to do so or if you violate our Terms of Service."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4",
            children: "4. Payment"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5",
          children: "If you make a purchase on our site, we use a third-party payment processor such as RAZORPAY or PayU. Payments are encrypted through the Payment Card Industry Data Security Standard (PCI-DSS). Your purchase transaction data is stored only as long as is necessary to complete your purchase transaction."
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-2 mb-5",
          children: "All direct payment gateways adhere to the standards set by PCI-DSS as managed by the PCI Security Standards Council, which is a joint effort of brands like Visa, MasterCard, American Express and Discover. PCI-DSS requirements help ensure the secure handling of credit card information by our site and related courses and its service providers."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-4 mb-4",
            children: " 5. Third-Party Services"
          })
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-5",
          children: ["In general, the third-party providers used by us will only collect, use and disclose your information to the extent necessary to allow them to perform the services they provide to us.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "However, certain third-party service providers, such as payment gateways and other payment transaction processors, have their own privacy policies with respect to the information we are required to provide to them for your purchase-related transactions. For these providers, we recommend that you read their privacy policies so you can understand the manner in which your personal information will be handled by these providers.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "Certain providers may be located in or have facilities that are located in a different jurisdiction than either you or us. If you elect to proceed with a transaction that involves the services of a third-party service provider, then your information may become subject to the laws of the jurisdiction(s) in which that service provider or its facilities are locate"]
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-2 mb-5",
          children: [" As an example, if you are located in Canada and your transaction is processed by a payment gateway located in India, then your personal information used in completing that transaction may be subject to disclosure under INDIA legislation, including the Patriot Act.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "Once you leave our course website or are redirected to a third-party website or application, you are no longer governed by this Privacy Policy or our website\u2019s Terms of Service.", /* @__PURE__ */ jsx("br", {}), " ", /* @__PURE__ */ jsx("br", {}), " ", /* @__PURE__ */ jsx("b", {
            children: " Links : "
          }), "When you click on links on our course site, they may direct you away from our site. We are not responsible for the privacy practices of other sites and encourage you to read their privacy statements."]
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5",
            children: "6. Security"
          })
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-5 mb-5",
          children: ["To protect your personal information, we take reasonable precautions and follow industry best practices to make sure it is not inappropriately lost, misused, accessed, disclosed, altered or destroyed.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "If you provide us with your credit card information, the information is encrypted using secure socket layer technology (SSL) and stored with a AES-256 encryption. Although no method of transmission over the Internet or electronic storage is 100% secure, we follow all PCI-DSS requirements and implement additional generally accepted industry standards.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("b", {
            children: "Cookies"
          }), /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "We collect cookies or similar tracking technologies. This means information that our website\u2019s server transfers to your computer. This information can be used to track your session on our website. Cookies may also be used to customize our website content for you as an individual. If you are using one of the common Internet web browsers, you can set up your browser to either let you know when you receive a cookie or to deny cookie access to your computer. We use cookies to recognize your device and provide you with a personalized experience.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "We also use cookies to attribute visits to our websites to third-party sources and to serve targeted ads from Google, Facebook, Instagram and other third-party vendors. Our third-party advertisers use cookies to track your prior visits to our websites and elsewhere on the Internet in order to serve you targeted ads. For more information about targeted or behavioural advertising, please ", " ", /* @__PURE__ */ jsx("a", {
            href: "https://www.networkadvertising.org/understanding-online-advertising",
            children: "click here"
          }), ".", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("b", {
            children: "Opting out:"
          }), " You can opt-out of targeted ads served via specific third-party vendors by visiting the Digital Advertising Alliance\u2019s Opt-Out page. We may also use automated tracking methods on our websites, in communications with you, and in our products and services, to measure performance and engagement. Please note that because there is no consistent industry understanding of how to respond to \u201CDo Not Track\u201D signals, we do not alter our data collection and usage practices when we detect such a signal from your browser. Web Analysis Tools We may use web analysis tools that are built into the Vereda.co.in website to measure and collect anonymous session information."]
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5 mb-2",
            children: " 7. Age of Consent"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "By using this site, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence."
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5 mb-2",
            children: " 8. Changes to this Privacy Policy"
          })
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-5 mb-5",
          children: ["We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes and clarifications will take effect immediately upon their posting on the website. If we make material changes to this policy, we will notify you here that it has been updated, so that you are aware of what information we collect, how we use it, and under what circumstances, if any, we use and/or disclose it.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "If our site or course is acquired or merged with another company, your information may be transferred to the new owners so that we may continue to sell products to you"]
        }), /* @__PURE__ */ jsx("h4", {
          className: " text-center",
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fw-bold mt-5 mb-2",
            children: "QUESTIONS AND CONTACT INFORMATION"
          })
        }), /* @__PURE__ */ jsxs("p", {
          className: "mt-5 mb-5",
          children: ["If you would like to: access, correct, amend or delete any personal information we have about you, register a complaint, or simply want more information contact our Privacy Compliance Officer at ", /* @__PURE__ */ jsx("a", {
            href: "mailto: support@vereda.co.in",
            children: " support@vereda.co.in"
          })]
        })]
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
}
export {
  PrivacyPolicy as default
};
