import { j as jsx, a as jsxs } from "../ssr.mjs";
import { Link } from "@inertiajs/inertia-react";
/* empty css                   *//* empty css                     */const categoryList = [{
  link: "#",
  text: "Web Development",
  className: "course-cate"
}, {
  link: "#",
  text: "30% Off",
  className: "course-offer"
}];
const PageHeaderTwo = ({
  programImage,
  title: title2,
  subject
}) => {
  return /* @__PURE__ */ jsx("div", {
    className: "pageheader-section style-2",
    children: /* @__PURE__ */ jsx("div", {
      className: "container",
      children: /* @__PURE__ */ jsxs("div", {
        className: "row justify-content-center justify-content-lg-between align-items-center flex-row-reverse",
        children: [/* @__PURE__ */ jsx("div", {
          className: "col-lg-7 col-12",
          children: /* @__PURE__ */ jsx("div", {
            className: "pageheader-thumb",
            children: /* @__PURE__ */ jsx("img", {
              src: programImage,
              alt: "vereda",
              className: "w-100"
            })
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "col-lg-5 col-12",
          children: /* @__PURE__ */ jsxs("div", {
            className: "pageheader-content",
            children: [/* @__PURE__ */ jsx("div", {
              className: "course-category",
              children: categoryList.map((val, i) => /* @__PURE__ */ jsx("a", {
                href: val.link,
                className: val.className,
                children: val.text
              }, i))
            }), /* @__PURE__ */ jsx("h2", {
              className: "phs-title",
              children: title2
            }), /* @__PURE__ */ jsx("p", {
              className: "phs-desc",
              children: subject
            })]
          })
        })]
      })
    })
  });
};
const PageHeaderTwo$1 = PageHeaderTwo;
const Author = ({
  teacherSrc,
  name,
  task,
  facebook,
  twitter,
  linkedin
}) => {
  const socialList = [
    {
      link: linkedin,
      iconName: "icofont-linkedin",
      className: "linkedin text-white bg-none"
    }
  ];
  return /* @__PURE__ */ jsxs("div", {
    className: "authors",
    children: [/* @__PURE__ */ jsx("div", {
      className: "author-thumb",
      children: /* @__PURE__ */ jsx("img", {
        src: teacherSrc,
        style: {
          width: "100px",
          height: "100px"
        },
        alt: "speaktosameer"
      })
    }), /* @__PURE__ */ jsxs("div", {
      className: "author-content",
      children: [/* @__PURE__ */ jsx("h5", {
        children: name
      }), /* @__PURE__ */ jsx("span", {
        children: task
      }), /* @__PURE__ */ jsx("ul", {
        className: "lab-ul",
        children: socialList.map((val, i) => /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsx("a", {
            href: val.link,
            className: "linkedin ",
            children: /* @__PURE__ */ jsx("i", {
              className: val.iconName
            })
          })
        }, i))
      })]
    })]
  });
};
const Author$1 = Author;
const payment = "/build/assets/01.946461c5.jpg";
const excenge = "Limited time offer";
const paymentTitle = "Secure Payment:";
const shareTitle = "Share This Course:";
const btnText = "Enroll Now";
const csdcList = [{
  iconName: "icofont-book-alt",
  leftText: "Course Duration",
  rightText: "23 week"
}, {
  iconName: "icofont-signal",
  leftText: "Online Class",
  rightText: "100%"
}, {
  iconName: "icofont-video-alt",
  leftText: "Live Session",
  rightText: "20+"
}, {
  iconName: "icofont-abacus-alt",
  leftText: "Quizzes",
  rightText: "26"
}, {
  iconName: "icofont-hour-glass",
  leftText: "Pass parcentages",
  rightText: "80"
}, {
  iconName: "icofont-certificate",
  leftText: "Certificate",
  rightText: "Yes"
}, {
  iconName: "icofont-globe",
  leftText: "Language",
  rightText: "English / Hindi"
}];
const CourseSideDetail = ({
  price,
  enroll,
  tweet,
  ping,
  linked,
  instagram
}) => {
  const socialList = [{
    siteLink: linked,
    iconName: "icofont-linkedin",
    className: " text-white"
  }, {
    siteLink: ping,
    iconName: "icofont-facebook",
    className: " text-white"
  }, {
    siteLink: tweet,
    iconName: "icofont-twitter",
    className: " text-color-baby-blue"
  }];
  return /* @__PURE__ */ jsxs("div", {
    className: "course-side-detail",
    children: [/* @__PURE__ */ jsxs("div", {
      className: "csd-title",
      children: [/* @__PURE__ */ jsx("div", {
        className: "csdt-left",
        children: /* @__PURE__ */ jsxs("h4", {
          className: "mb-0",
          children: [/* @__PURE__ */ jsx("sup", {
            children: "INR "
          }), price]
        })
      }), /* @__PURE__ */ jsx("div", {
        className: "csdt-right",
        children: /* @__PURE__ */ jsxs("p", {
          className: "mb-0",
          children: [/* @__PURE__ */ jsx("i", {
            className: "icofont-clock-time"
          }), excenge]
        })
      })]
    }), /* @__PURE__ */ jsxs("div", {
      className: "csd-content",
      children: [/* @__PURE__ */ jsx("div", {
        className: "csdc-lists",
        children: /* @__PURE__ */ jsx("ul", {
          className: "lab-ul",
          children: csdcList.map((val, i) => /* @__PURE__ */ jsxs("li", {
            children: [/* @__PURE__ */ jsxs("div", {
              className: "csdc-left",
              children: [/* @__PURE__ */ jsx("i", {
                className: val.iconName
              }), val.leftText]
            }), /* @__PURE__ */ jsx("div", {
              className: "csdc-right",
              children: val.rightText
            })]
          }, i))
        })
      }), /* @__PURE__ */ jsxs("div", {
        className: "sidebar-payment",
        children: [/* @__PURE__ */ jsx("div", {
          className: "sp-title",
          children: /* @__PURE__ */ jsx("h6", {
            children: paymentTitle
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "sp-thumb",
          children: /* @__PURE__ */ jsx("img", {
            src: payment,
            alt: "Vereda"
          })
        })]
      }), /* @__PURE__ */ jsxs("div", {
        className: "sidebar-social",
        children: [/* @__PURE__ */ jsx("div", {
          className: "ss-title",
          children: /* @__PURE__ */ jsx("h6", {
            children: shareTitle
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "ss-content",
          children: /* @__PURE__ */ jsx("ul", {
            className: "lab-ul",
            children: socialList.map((val, i) => /* @__PURE__ */ jsx("li", {
              children: /* @__PURE__ */ jsx("a", {
                href: val.siteLink,
                className: val.className,
                children: /* @__PURE__ */ jsx("i", {
                  className: val.iconName
                })
              })
            }, i))
          })
        })]
      }), /* @__PURE__ */ jsx("div", {
        className: "course-enroll",
        children: /* @__PURE__ */ jsx(Link, {
          href: enroll,
          className: "lab-btn",
          children: /* @__PURE__ */ jsx("span", {
            children: btnText
          })
        })
      })]
    })]
  });
};
const CourseSideDetail$1 = CourseSideDetail;
export {
  Author$1 as A,
  CourseSideDetail$1 as C,
  PageHeaderTwo$1 as P
};
