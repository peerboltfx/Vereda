import "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
import { Alert, Table } from "react-bootstrap";
/* empty css                 */import { Trash } from "react-bootstrap-icons";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Plantable(props) {
  const {
    questions,
    origin,
    flash
  } = usePage().props;
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Moderator / questions"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Questions Table"
        })]
      }),
      childs: /* @__PURE__ */ jsx(Fragment, {}),
      children: [/* @__PURE__ */ jsx(Head, {
        title: origin.topic
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsxs("div", {
            className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
            children: [flash.message && /* @__PURE__ */ jsx("div", {
              className: "p-3",
              children: /* @__PURE__ */ jsx(Alert, {
                className: "mt-5 text-center p-3",
                variant: "success",
                children: flash.message
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "p-6 plan-table border-b border-gray-200",
              children: /* @__PURE__ */ jsxs(Table, {
                striped: true,
                bordered: true,
                hover: true,
                children: [/* @__PURE__ */ jsx("thead", {
                  children: /* @__PURE__ */ jsxs("tr", {
                    children: [/* @__PURE__ */ jsx("th", {
                      children: "#"
                    }), /* @__PURE__ */ jsx("th", {
                      width: "90%",
                      children: "Topic"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "delete"
                    })]
                  })
                }), /* @__PURE__ */ jsx("tbody", {
                  children: questions.map((data, index) => {
                    return /* @__PURE__ */ jsxs("tr", {
                      children: [/* @__PURE__ */ jsx("td", {
                        children: index
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.question
                      }), /* @__PURE__ */ jsx("td", {
                        className: "flex",
                        children: /* @__PURE__ */ jsx(Link, {
                          className: "ml-4",
                          href: route("deleteQuestion", data.id),
                          method: "POST",
                          children: /* @__PURE__ */ jsx(Trash, {})
                        })
                      })]
                    }, index);
                  })
                })]
              })
            })]
          })
        })
      })]
    })
  });
}
export {
  Plantable as default
};
