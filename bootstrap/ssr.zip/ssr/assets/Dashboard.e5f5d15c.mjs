import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { Row, Col } from "react-bootstrap";
/* empty css                 */import { Book, Bell } from "react-bootstrap-icons";
import "dompurify";
import { L as LineChart } from "./LineChart.02c06b2c.mjs";
import { F as Fullstack } from "./fullstack-2.a4f71d98.mjs";
import { j as jsx, a as jsxs, F as Fragment } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "chart.js";
import "react-chartjs-2";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const Flutter = "/build/assets/Flutter-App-development.1f703f2f.jpg";
function Progress({
  courseHead,
  courseProgress,
  studyHead,
  studyProgress,
  assignmentHead,
  assginmentProgress
}) {
  const entity = [{
    header: courseHead,
    progress: courseProgress,
    classing: "bg-primaries rounded-full ml-2 flex flex-column-center items-center"
  }, {
    header: studyHead,
    progress: studyProgress,
    classing: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center"
  }, {
    header: assignmentHead,
    progress: assginmentProgress,
    classing: "bg-color-gold rounded-full ml-2 flex flex-column-center items-center"
  }];
  return /* @__PURE__ */ jsx("div", {
    className: "bg-white progress-container flex flex-col sm:justify-center w-100 sm:rounded-lg",
    children: /* @__PURE__ */ jsx("div", {
      className: "flex header-block",
      children: entity.map((data, index) => {
        return /* @__PURE__ */ jsxs("div", {
          className: "flex p-4",
          children: [/* @__PURE__ */ jsx("div", {
            className: data.classing,
            style: {
              width: "60px",
              height: "60px"
            },
            children: /* @__PURE__ */ jsxs("h5", {
              className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
              children: [data.progress, "%"]
            })
          }), /* @__PURE__ */ jsx("h6", {
            className: "text-color-dark-blue mt-2  ml-5 fw-bold w-50",
            children: data.header
          })]
        }, index);
      })
    })
  });
}
function Dashboard(props) {
  window.sessionStorage.clear();
  const {
    programs,
    progress,
    fullstack,
    flutter,
    flutterLink,
    fullstackLink,
    verified,
    course,
    assignment
  } = usePage().props;
  const [values, setValues] = useState({
    "search": ""
  });
  const labels = fullstack.map((data, index) => {
    return `week ${index + 1}`;
  });
  const dataMain = {
    labels,
    datasets: [{
      label: "Dataset 1",
      data: fullstack.map((data, index) => {
        return data.result;
      }),
      borderColor: "rgb(53, 162, 235)",
      backgroundColor: "rgba(53, 162, 235, 222)"
    }, {
      label: "Dataset 2",
      data: fullstack.map((data, index) => {
        return data.result;
      }),
      borderColor: "rgb(53, 162, 235)",
      backgroundColor: "rgba(53, 162, 235, 0.5)"
    }]
  };
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const found = programs.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(values.search)));
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsx(Fragment, {
      children: /* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Dashboard"
      })
    }),
    Search: /* @__PURE__ */ jsxs("div", {
      className: "Search-container",
      children: [/* @__PURE__ */ jsx("div", {
        className: "",
        children: /* @__PURE__ */ jsx("input", {
          onClick: HandleShow,
          type: "text",
          name: "search",
          value: values.search,
          onChange: HandleChange
        })
      }), /* @__PURE__ */ jsx("div", {
        tabIndex: "0",
        onBlur: () => setShow(false),
        className: show ? "Searched sm:rounded-lg h-full pl-3 pb-4 relative-left active" : "Searched",
        children: found.map((data, index) => {
          return /* @__PURE__ */ jsx("div", {
            className: "bg-white pt-2 mt-1 pb-2 pl-4 shadow-sm sm:rounded-lg",
            children: /* @__PURE__ */ jsx(Row, {
              children: /* @__PURE__ */ jsx(Col, {
                mx: "6",
                children: /* @__PURE__ */ jsx(Link, {
                  href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                  className: "text-color-dark-blue",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "flex pb-3",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "2",
                      className: "pt-0 ",
                      children: /* @__PURE__ */ jsx(Book, {
                        style: {
                          fontSize: "30px",
                          color: "#DC4731"
                        },
                        className: "pl-1"
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "10",
                      className: "fs-5 fw-bold pl-0 ml-4 text-color-dark-blue",
                      children: data.program
                    })]
                  })
                })
              })
            })
          }, index);
        })
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Dashboard"
    }), /* @__PURE__ */ jsx("div", {
      className: "block header-block",
      children: /* @__PURE__ */ jsx("div", {
        className: "dashboard-container header-block items-center",
        children: verified && /* @__PURE__ */ jsxs(Fragment, {
          children: [/* @__PURE__ */ jsxs(Col, {
            lg: "8",
            md: "12",
            sm: "12",
            className: "p-2 dashboard-content col-lg-8 col-md-12 col-sm-12",
            children: [/* @__PURE__ */ jsx(Progress, {
              First: true,
              Listing: true,
              The: true,
              Header: true,
              of: true,
              Progress: true,
              courseHead: "Course Progress",
              studyHead: "Available Studies",
              assignmentHead: "Assignment Progress",
              Secondly: true,
              listing: true,
              the: true,
              Progess: true,
              our: true,
              content: true,
              courseProgress: fullstack.length * 4,
              studyProgress: course.length * 0.8,
              assginmentProgress: assignment.length * 0.8
            }), /* @__PURE__ */ jsxs("div", {
              className: "bg-white mt-4 sm:rounded-lg p-3",
              children: [/* @__PURE__ */ jsx("h5", {
                className: "fw-bold text-color-dark-blue",
                children: "Weekly Progress"
              }), /* @__PURE__ */ jsx(LineChart, {
                datas: dataMain,
                textName: "student progress"
              })]
            })]
          }), verified[0] && /* @__PURE__ */ jsx(Col, {
            lg: "4",
            className: "pr-4 dashboard-right",
            children: /* @__PURE__ */ jsxs("div", {
              className: "bg-white  p-3 w-100 sm:rounded-lg",
              children: [/* @__PURE__ */ jsx(Col, {
                lg: "9",
                className: "mb-5",
                children: /* @__PURE__ */ jsx("h5", {
                  className: "fw-bold mt-3 text-color-dark-blue",
                  children: "Recent Class"
                })
              }), /* @__PURE__ */ jsx("div", {
                className: "",
                children: course.length > 0 ? /* @__PURE__ */ jsx(Fragment, {
                  children: course.map((data, index) => {
                    return /* @__PURE__ */ jsx(Link, {
                      className: "block",
                      href: `/study/${data.program_code}-${data.topic.split(" ").join("-")}-${data.id}`,
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "flex",
                        children: [/* @__PURE__ */ jsx(Col, {
                          lg: "3",
                          children: /* @__PURE__ */ jsxs("div", {
                            style: {
                              width: "50px",
                              height: "50px"
                            },
                            className: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center",
                            children: [/* @__PURE__ */ jsx("h5", {
                              className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                              children: "M"
                            }), " "]
                          })
                        }), /* @__PURE__ */ jsxs(Col, {
                          className: "pt-2",
                          children: [/* @__PURE__ */ jsx("h6", {
                            className: "fw-bold ml-3",
                            children: data.topic
                          }), /* @__PURE__ */ jsx("p", {
                            children: new Date(`${data.date}`).toLocaleDateString()
                          })]
                        }), /* @__PURE__ */ jsx(Col, {
                          lg: "3",
                          children: /* @__PURE__ */ jsxs("div", {
                            style: {
                              width: "50px",
                              height: "50px",
                              border: "solid 1px blue"
                            },
                            className: " rounded-full ml-2 flex flex-column-center items-center",
                            children: [/* @__PURE__ */ jsx(Bell, {
                              className: "fs-5 text-color-dark-blue ml-auto mr-auto"
                            }), "  "]
                          })
                        })]
                      })
                    }, index);
                  })
                }) : /* @__PURE__ */ jsx(Fragment, {
                  children: /* @__PURE__ */ jsx("div", {
                    className: "flex flex-col sm:justify-center items-center",
                    children: /* @__PURE__ */ jsx("h3", {
                      className: "ft-6 text-color-gray",
                      children: "No Course Yet"
                    })
                  })
                })
              })]
            })
          })]
        })
      })
    }), /* @__PURE__ */ jsx("div", {
      className: "w-100",
      children: /* @__PURE__ */ jsx("div", {
        className: " sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden w-100 sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6  border-b border-gray-200",
            children: /* @__PURE__ */ jsx(Row, {
              className: "header-block",
              children: programs.length < 1 ? /* @__PURE__ */ jsx("p", {
                className: "text-center mt-5",
                children: "program not Created yet"
              }) : programs.map((data, index) => {
                return /* @__PURE__ */ jsx(Col, {
                  xs: "",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "bg-white p-3 shadow-sm  mb-2 sm:rounded-lg",
                    children: [/* @__PURE__ */ jsxs("div", {
                      style: {
                        overflow: "hidden"
                      },
                      children: [data.random == fullstackLink && /* @__PURE__ */ jsx("img", {
                        className: "w-100",
                        src: Fullstack
                      }), data.random == flutterLink && /* @__PURE__ */ jsx("img", {
                        className: "w-100",
                        src: Flutter
                      })]
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "",
                      children: [/* @__PURE__ */ jsx("h6", {
                        className: "fw-bold text-color-dark-blue mt-3 ",
                        style: {
                          fontSize: 14
                        },
                        children: "Design"
                      }), /* @__PURE__ */ jsxs("div", {
                        className: "flex",
                        children: [/* @__PURE__ */ jsx(Col, {
                          sm: "10",
                          children: /* @__PURE__ */ jsxs("h1", {
                            className: "fs-5 p-3 w-100 fw-bold",
                            children: [data.program, " "]
                          })
                        }), /* @__PURE__ */ jsx(Col, {
                          lg: "2",
                          children: /* @__PURE__ */ jsx("div", {
                            className: "course-btn ",
                            children: /* @__PURE__ */ jsx(Link, {
                              href: data.random == fullstackLink && `/Program/Full-Stack-Development-Program` || data.random == flutterLink && "/Program/Flutter-Development-Program",
                              className: "lab-btn-text mt-3",
                              children: /* @__PURE__ */ jsx("i", {
                                className: "icofont-external-link"
                              })
                            })
                          })
                        })]
                      }), /* @__PURE__ */ jsx("p", {
                        className: "pl-3 text-color-gray",
                        children: data.random == fullstackLink && "Design Websites and Mobile Apps that Your Users Love and  Return to Again." || data.random == flutterLink && "Learn how to Design Mobile Application Using Flutter Development"
                      }), /* @__PURE__ */ jsx("div", {
                        className: "flex pl-3 pt-2"
                      })]
                    }), /* @__PURE__ */ jsxs("div", {
                      className: " pb-4 text-color-dark-blue flex",
                      children: [!verified[0] && /* @__PURE__ */ jsx("div", {
                        className: "bg-primary rounded-full shadow-sm text-color-white pl-3 pr-3 pt-1 pb-1 mr-4",
                        children: /* @__PURE__ */ jsx(Link, {
                          className: "text-white",
                          href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                          children: "Enroll now"
                        })
                      }), verified[0] && /* @__PURE__ */ jsxs(Link, {
                        href: `/en/${data.program.split(" ").join("-")}/session/${data.random}`,
                        className: "bg-primary rounded-full shadow-sm text-white pl-3 pr-3 pt-2 mr-4",
                        children: ["  ", /* @__PURE__ */ jsxs("h3", {
                          className: "flex float-right text-white fw-bold fs-6",
                          children: [/* @__PURE__ */ jsx(Fragment, {
                            children: verified[0].program == data.program ? /* @__PURE__ */ jsx(Fragment, {
                              children: "Continue "
                            }) : /* @__PURE__ */ jsx(Fragment, {
                              children: "enroll now"
                            })
                          }), " "]
                        })]
                      }), /* @__PURE__ */ jsx("h6", {
                        children: data.tuitorid
                      })]
                    })]
                  })
                }, index);
              })
            })
          })
        })
      })
    })]
  });
}
export {
  Dashboard as default
};
