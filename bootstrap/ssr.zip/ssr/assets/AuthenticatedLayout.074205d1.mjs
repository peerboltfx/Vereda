import React, { useState, useContext } from "react";
import { A as ApplicationLogo } from "./ApplicationLogo.c9284209.mjs";
import { Link, usePage } from "@inertiajs/inertia-react";
import { Person, Grid, Tools, PersonBadge, PersonCheck, People, Paypal, PlusCircle, PenFill, PencilSquare, Power, PeopleFill, Calendar2Event, Table, Speedometer, QuestionCircleFill, Pencil, JournalAlbum, FileEarmarkMedical, Recycle, List, Search, Bell, Gear } from "react-bootstrap-icons";
import { CloseButton, Col } from "react-bootstrap";
import "react-bootstrap/Nav";
import { j as jsx, a as jsxs, F as Fragment } from "../ssr.mjs";
import { Divider } from "@mui/material";
/* empty css                 */import { L as Logo } from "./logo.d6c74f57.mjs";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import Badge from "@material-ui/core/Badge";
import Tooltip from "@material-ui/core/Tooltip";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
function NavLink({
  href,
  active,
  children
}) {
  return /* @__PURE__ */ jsx(Link, {
    href,
    className: active ? "InertiaLink active" : "InertiaLink",
    children
  });
}
const DropDownContext = React.createContext();
const Dropdown = ({
  children
}) => {
  const [open, setOpen] = useState(false);
  const toggleOpen = () => {
    setOpen((previousState) => !previousState);
  };
  return /* @__PURE__ */ jsx(DropDownContext.Provider, {
    value: {
      open,
      setOpen,
      toggleOpen
    },
    children: /* @__PURE__ */ jsx("div", {
      className: "relative",
      children
    })
  });
};
const Trigger = ({
  children
}) => {
  const {
    open,
    setOpen,
    toggleOpen
  } = useContext(DropDownContext);
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx("div", {
      onClick: toggleOpen,
      children
    }), open && /* @__PURE__ */ jsx("div", {
      className: "fixed inset-0 z-40",
      onClick: () => setOpen(false)
    })]
  });
};
const Content = ({
  align = "right",
  width = "48",
  contentClasses = "py-1 bg-white",
  children
}) => {
  useContext(DropDownContext);
};
const DropdownLink = ({
  href,
  method = "post",
  as = "a",
  children
}) => {
  return /* @__PURE__ */ jsx(Link, {
    href,
    method,
    as,
    className: "InertiaLink w-80",
    children
  });
};
Dropdown.Trigger = Trigger;
Dropdown.Content = Content;
Dropdown.Link = DropdownLink;
function AdminLinks() {
  const [navbar, setNavbar] = useState(false);
  const {
    programs
  } = usePage().props;
  const HandleClose = () => {
    setNavbar(false);
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      children: /* @__PURE__ */ jsxs("ul", {
        className: "ml-0 pt-4 pl-0",
        children: [/* @__PURE__ */ jsx("li", {
          className: "ml-0 left-navbar",
          children: /* @__PURE__ */ jsxs(NavLink, {
            href: "/profile",
            active: route().current("Profile"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(Person, {
                className: "InertiaLink-icon"
              })
            }), " Profile"]
          })
        }), /* @__PURE__ */ jsxs("li", {
          className: "ml-0 left-navbar",
          children: [" ", /* @__PURE__ */ jsxs(NavLink, {
            className: "InertiaLink",
            active: route().current("dashboard"),
            href: "/dashboard",
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(Grid, {
                className: "InertiaLink-icon"
              })
            }), "Dashboard"]
          })]
        }), /* @__PURE__ */ jsxs("li", {
          className: "ml-0 left-navbar",
          children: [" ", /* @__PURE__ */ jsxs(NavLink, {
            className: "InertiaLink",
            href: "/profile/profile-edit",
            active: route().current("EditProfile"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(Tools, {
                className: "InertiaLink-icon"
              })
            }), "Edit Profile"]
          })]
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            className: "text-color-gray InertiaLink",
            active: route().current("ReferralPage"),
            href: route("AdminStudents"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(PersonBadge, {})
            }), "Students"]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            className: "text-color-gray InertiaLink",
            active: route().current("Moderators"),
            href: route("Moderators"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(PersonCheck, {})
            }), "Moderators"]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            className: "text-color-gray InertiaLink",
            active: route().current("Users"),
            href: route("Users"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(People, {})
            }), "Users"]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            className: "text-color-gray InertiaLink",
            active: route().current("OrderItems"),
            href: route("OrderItems"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(Paypal, {})
            }), "Payment Order"]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            className: "text-color-gray InertiaLink",
            active: route().current("PaidUser"),
            href: route("PaidUser"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(People, {})
            }), "Subscirbers"]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            className: "text-color-gray InertiaLink",
            active: route().current("createProgram"),
            href: route("createProgram"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(PlusCircle, {})
            }), "  Create Batch"]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            className: "text-color-gray InertiaLink",
            href: "/admin/create-course",
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(PenFill, {})
            }), "Create Courses"]
          })
        }), /* @__PURE__ */ jsxs("li", {
          onClick: () => setNavbar(true),
          className: "text-color-gray InertiaLink",
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(PencilSquare, {})
          }), " Edit Program"]
        }), /* @__PURE__ */ jsxs("ul", {
          tabIndex: 0,
          onBlur: () => setNavbar(false),
          className: navbar ? "Unordered active" : "Unordered",
          children: [/* @__PURE__ */ jsx("h6", {
            className: "text-right mb-1 mr-1 p-1",
            children: /* @__PURE__ */ jsx(CloseButton, {
              onClick: HandleClose
            })
          }), programs.map((data, index) => {
            return /* @__PURE__ */ jsx("li", {
              children: /* @__PURE__ */ jsx(Link, {
                href: `/admin/edit-program/${data.random}`,
                className: "InertiaLink",
                children: data.program
              })
            }, index);
          })]
        }), /* @__PURE__ */ jsx("li", {
          className: "ml-0 left-navbar",
          children: /* @__PURE__ */ jsxs(Dropdown.Link, {
            href: route("logout"),
            method: "post",
            as: "button",
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(Power, {
                className: "InertiaLink-icon"
              })
            }), " Log Out"]
          })
        })]
      })
    })
  });
}
function ModeratorLinks({
  Programs
}) {
  useState(false);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs("ul", {
      className: "ml-0 pt-4 pl-0",
      style: {},
      children: [/* @__PURE__ */ jsxs("li", {
        className: "ml-0 left-navbar",
        children: [" ", /* @__PURE__ */ jsxs(NavLink, {
          className: "InertiaLink",
          active: route().current("dashboard"),
          href: "/dashboard",
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Grid, {
              className: "InertiaLink-icon"
            })
          }), "Dashboard"]
        })]
      }), /* @__PURE__ */ jsx("li", {
        className: "ml-0 left-navbar",
        children: /* @__PURE__ */ jsxs(NavLink, {
          href: "/profile",
          active: route().current("Profile"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(PersonBadge, {
              className: "InertiaLink-icon"
            })
          }), "Profile"]
        })
      }), /* @__PURE__ */ jsxs("li", {
        className: "ml-0 left-navbar",
        children: [" ", /* @__PURE__ */ jsxs(NavLink, {
          className: "InertiaLink",
          href: "/profile/profile-edit",
          active: route().current("EditProfile"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Tools, {
              className: "InertiaLink-icon"
            })
          }), "Edit Profile"]
        })]
      }), /* @__PURE__ */ jsx(Divider, {}), /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsxs(Link, {
          className: "text-color-gray InertiaLink",
          href: route("ModeratorsStudents"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(PeopleFill, {})
          }), " Students"]
        })
      }), /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsxs(Link, {
          className: "text-color-gray InertiaLink",
          href: route("dailyScheduler"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Calendar2Event, {})
          }), " Schedule Plan"]
        })
      }), /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsxs(Link, {
          className: "text-color-gray InertiaLink",
          href: route("DailyPlanView"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Table, {})
          }), "Plan Table"]
        })
      }), /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsxs(Link, {
          className: "text-color-gray InertiaLink",
          href: route("createdQuiz"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Speedometer, {})
          }), "quiz created"]
        })
      }), /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsxs(Link, {
          className: "text-color-gray InertiaLink",
          href: "/moderator/view-assignments",
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(QuestionCircleFill, {})
          }), "Assignments"]
        })
      }), /* @__PURE__ */ jsx("li", {
        className: "ml-0 left-navbar",
        children: /* @__PURE__ */ jsxs(Dropdown.Link, {
          href: route("logout"),
          method: "post",
          as: "button",
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Power, {
              className: "InertiaLink-icon"
            })
          }), " Log Out"]
        })
      })]
    })
  });
}
function StudentsLinks({
  Programs
}) {
  useState(false);
  const {
    auth,
    verified
  } = usePage().props;
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs("ul", {
      className: "ml-0 pt-4 pl-0",
      children: [/* @__PURE__ */ jsxs("li", {
        className: "ml-0 left-navbar",
        children: [" ", /* @__PURE__ */ jsxs(NavLink, {
          className: "InertiaLink",
          active: route().current("dashboard"),
          href: "/dashboard",
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Grid, {})
          }), "Dashboard"]
        })]
      }), /* @__PURE__ */ jsx("li", {
        className: "ml-0 left-navbar",
        children: /* @__PURE__ */ jsxs(NavLink, {
          href: "/profile",
          active: route().current("Profile"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Person, {})
          }), " User Profile"]
        })
      }), /* @__PURE__ */ jsxs("li", {
        className: "ml-0 left-navbar",
        children: [" ", /* @__PURE__ */ jsxs(NavLink, {
          className: "InertiaLink",
          href: "/profile/profile-edit",
          active: route().current("EditProfile"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Pencil, {
              className: "InertiaLink-icon"
            })
          }), "Edit Profile"]
        })]
      }), verified.length >= 1 && /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("li", {
          className: "ml-0 left-navbar",
          children: /* @__PURE__ */ jsxs(NavLink, {
            className: "InertiaLink",
            href: "/student/my-assignments",
            active: route().current("Assignment"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(JournalAlbum, {
                className: "InertiaLink-icon"
              })
            }), " Assignment report"]
          })
        }), /* @__PURE__ */ jsx("li", {
          className: "ml-0 left-navbar",
          children: /* @__PURE__ */ jsxs(NavLink, {
            className: "InertiaLink",
            href: route("StudentReportTable"),
            active: route().current("StudentReportTable"),
            children: [/* @__PURE__ */ jsx("span", {
              children: /* @__PURE__ */ jsx(FileEarmarkMedical, {
                className: "InertiaLink-icon"
              })
            }), "Student Result"]
          })
        })]
      }), /* @__PURE__ */ jsx("li", {
        className: "ml-0 left-navbar",
        children: /* @__PURE__ */ jsxs(NavLink, {
          className: "InertiaLink",
          href: "/account/referral",
          active: route().current("ReferralPage"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Recycle, {
              className: "InertiaLink-icon"
            })
          }), " Referral Program"]
        })
      }), /* @__PURE__ */ jsx("li", {
        className: "ml-0 left-navbar",
        children: /* @__PURE__ */ jsxs(NavLink, {
          className: "InertiaLink",
          href: "/account/transactions",
          active: route().current("Transaction"),
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Paypal, {
              className: "InertiaLink-icon"
            })
          }), " Transactions"]
        })
      }), /* @__PURE__ */ jsx("li", {
        className: "ml-0 left-navbar",
        children: /* @__PURE__ */ jsxs(Dropdown.Link, {
          href: route("logout"),
          method: "post",
          as: "button",
          children: [/* @__PURE__ */ jsx("span", {
            children: /* @__PURE__ */ jsx(Power, {
              className: "InertiaLink-icon"
            })
          }), " Log Out"]
        })
      })]
    })
  });
}
const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.background.paper
  }
}));
function Authenticated({
  auth,
  header,
  children,
  childs,
  Search: Search$1,
  Programs,
  ChartWeeklyProgress
}) {
  usePage().props;
  const [notify, setNotify] = useState(false);
  const [navbar, setNavbar] = useState(false);
  const [dropNav, setDropbar] = useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  useStyles();
  const [anchorEl1, setAnchorEl1] = React.useState(null);
  const [selectedIndex, setSelectedIndex] = React.useState(1);
  const handleClickListItem = (event) => {
    setAnchorEl1(event.currentTarget);
  };
  const handleMenuItemClick = (event, index) => {
    setSelectedIndex(index);
    setAnchorEl1(null);
  };
  const handleClose1 = () => {
    setAnchorEl1(null);
  };
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const HandleHide = () => {
    if (window.scrollY >= 200) {
      setDropbar(true);
    } else {
      setNavbar(false);
    }
  };
  window.addEventListener("scroll", HandleHide);
  const HandleNavbar = () => {
    setNavbar(true);
  };
  const HandleCloseNav = () => {
    setNavbar(false);
  };
  if (!notify) {
    window.Echo.channel("update_channel").listen("update", (update) => {
      console.log("update");
      if (update) {
        setNotify(true);
      }
    });
  }
  return /* @__PURE__ */ jsxs("div", {
    className: "min-h-screen flex bg-gray-100",
    children: [/* @__PURE__ */ jsx(Col, {
      md: "0",
      sm: "0",
      lg: "2",
      className: "bg-white mobile-hide tab-hide overflow-hidden",
      children: /* @__PURE__ */ jsx("nav", {
        className: "bg-white border-b border-gray-100",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-2xl mx-auto",
          children: /* @__PURE__ */ jsx("div", {
            className: " justify-between h-16",
            children: /* @__PURE__ */ jsxs("div", {
              className: "block",
              children: [/* @__PURE__ */ jsx("div", {
                className: "shrink-0 w-100 mt-6 w-auto flex flex-column-center items-center",
                children: /* @__PURE__ */ jsx(Link, {
                  className: "text-center  mr-auto ml-auto",
                  href: "/",
                  children: /* @__PURE__ */ jsx(ApplicationLogo, {
                    className: " h-9 w-auto text-gray-500"
                  })
                })
              }), /* @__PURE__ */ jsxs("div", {
                className: "dashboardList ml-0 pl-0 block",
                children: [childs, /* @__PURE__ */ jsxs("div", {
                  className: "dashnavbar ",
                  children: [auth.user.role == "admin" && /* @__PURE__ */ jsx(Fragment, {
                    children: /* @__PURE__ */ jsx(AdminLinks, {})
                  }), auth.user.role == "moderator" && /* @__PURE__ */ jsx(Fragment, {
                    children: /* @__PURE__ */ jsx(ModeratorLinks, {})
                  }), auth.user.role == "student" && /* @__PURE__ */ jsx(StudentsLinks, {})]
                })]
              })]
            })
          })
        })
      })
    }), /* @__PURE__ */ jsxs(Col, {
      className: "main-page",
      style: {
        height: "100vh",
        overflowY: "scroll"
      },
      children: [/* @__PURE__ */ jsxs("div", {
        style: {
          zIndex: "99"
        },
        className: dropNav ? "w-100 h-20 bg-white p-3  pt-4 fixed shadow closebutton-hide" : "w-100 h-20  p-3  pt-4 fixed  closebutton-hide",
        children: [navbar ? /* @__PURE__ */ jsx(CloseButton, {
          className: "float-right fs-6",
          onClick: HandleCloseNav
        }) : /* @__PURE__ */ jsx(List, {
          className: "float-right ",
          onClick: HandleNavbar
        }), /* @__PURE__ */ jsx("img", {
          src: Logo,
          onClick: () => {
            location.href = "/";
          },
          width: "90px",
          className: "pb-3"
        }), /* @__PURE__ */ jsxs("nav", {
          className: navbar ? "menuNavbar active bg-primaries w-100 left-0" : "menuNavbar bg-color-dark-blue w-0 left-0",
          children: [/* @__PURE__ */ jsx("div", {
            className: "p-3",
            children: /* @__PURE__ */ jsxs("div", {
              className: "search-display  rounded-full w-90 flex flex-column-center items-center bg-white",
              children: [/* @__PURE__ */ jsx("div", {
                className: "search-icon ml-2 text-color-gray",
                children: /* @__PURE__ */ jsx(Search, {})
              }), " ", Search$1]
            })
          }), /* @__PURE__ */ jsxs("div", {
            className: "dashboardList ml-0 pl-0 block",
            children: [childs, /* @__PURE__ */ jsxs("div", {
              className: "dashnavbar ",
              children: [auth.user.role == "admin" && /* @__PURE__ */ jsx(Fragment, {
                children: /* @__PURE__ */ jsx(AdminLinks, {})
              }), auth.user.role == "moderator" && /* @__PURE__ */ jsx(Fragment, {
                children: /* @__PURE__ */ jsx(ModeratorLinks, {})
              }), auth.user.role == "student" && /* @__PURE__ */ jsx(StudentsLinks, {})]
            })]
          })]
        })]
      }), /* @__PURE__ */ jsxs("div", {
        className: "",
        children: [header && /* @__PURE__ */ jsx("header", {
          className: "pt-3  w-100 block",
          children: /* @__PURE__ */ jsxs("div", {
            className: "flex",
            children: [/* @__PURE__ */ jsx(Col, {
              md: "5",
              className: "mx-auto py-6 dashboard-header text-color-dark-black px-4 sm:px-6 lg:px-8",
              children: header
            }), /* @__PURE__ */ jsx(Col, {
              md: "4",
              className: "p-2 tab-hide mobile-hide mt-3",
              children: /* @__PURE__ */ jsxs("div", {
                className: "search-display rounded-full flex flex-column-center items-center bg-white",
                children: [/* @__PURE__ */ jsx(Search, {
                  className: "ml-2 text-color-gray"
                }), Search$1]
              })
            }), /* @__PURE__ */ jsxs(Col, {
              md: "3",
              className: "p-2 tab-hide mobile-hide mt-3 flex col-md-3",
              children: [/* @__PURE__ */ jsx(Badge, {
                badgeContent: auth.user.notifications.length,
                overlap: "rectangular",
                color: "error",
                children: /* @__PURE__ */ jsx(Tooltip, {
                  title: "Read notifications",
                  "aria-label": "Read notifications",
                  children: /* @__PURE__ */ jsx("div", {
                    onClick: handleClickListItem,
                    className: "bg-white rounded-full ml-2 w-10 h-10 flex flex-column-center items-center",
                    children: /* @__PURE__ */ jsx(Bell, {
                      className: "fs-5 text-gray-500 ml-auto mr-auto"
                    })
                  })
                })
              }), /* @__PURE__ */ jsx(Tooltip, {
                title: "Profile Settings",
                "aria-label": "Read notifications",
                children: /* @__PURE__ */ jsxs("div", {
                  className: "bg-white rounded-full ml-2 w-10 h-10 flex flex-column-center items-center",
                  children: [/* @__PURE__ */ jsx(Link, {
                    className: "text-center fs-5 fw-bold text-white ml-auto mt-auto mb-auto mr-auto",
                    href: "/profile/profile-edit",
                    children: /* @__PURE__ */ jsx(Gear, {
                      className: "fs-5 text-gray-500 ml-auto mr-auto"
                    })
                  }), " "]
                })
              }), /* @__PURE__ */ jsx("div", {
                style: {
                  width: "40%"
                },
                className: " ml-2 h-10 flex flex-column-center mt-1 items-center",
                children: /* @__PURE__ */ jsx("h6", {
                  style: {
                    fontSize: "18px",
                    textTransform: "capitalize"
                  },
                  className: "fw-bold",
                  children: auth.user.name
                })
              }), /* @__PURE__ */ jsx(Tooltip, {
                title: "shortcut",
                "aria-label": "Read notifications",
                children: /* @__PURE__ */ jsx("div", {
                  onClick: handleClick,
                  className: " w-10 ml-2 h-10 bg-color-blue rounded-full flex flex-column-center items-center",
                  children: /* @__PURE__ */ jsx("div", {
                    className: "text-center fs-5 fw-bold text-white ml-auto mt-auto mb-auto mr-auto",
                    children: auth.avatar ? /* @__PURE__ */ jsx("img", {
                      src: `../../../../storage/jpg/${auth.avatar}`,
                      className: "rounded-full"
                    }) : auth.user.name.charAt(0).toUpperCase()
                  })
                })
              })]
            })]
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "",
          children: /* @__PURE__ */ jsx(Col, {
            md: "12",
            sm: "12",
            children: /* @__PURE__ */ jsx("main", {
              className: "",
              style: {
                width: "100%"
              },
              children
            })
          })
        })]
      }), /* @__PURE__ */ jsx("div", {
        className: "bg-white pt-5 pb-4 flex items-center",
        children: /* @__PURE__ */ jsx("div", {
          className: "container",
          children: /* @__PURE__ */ jsx("div", {
            className: "section-wrapper w-full",
            children: /* @__PURE__ */ jsxs("p", {
              width: "10%",
              className: "ml-auto mr-auto text-center",
              children: [/* @__PURE__ */ jsx(Link, {
                className: "",
                href: "/",
                children: "Vereda Digital Learning"
              }), "\xA9 2023 "]
            })
          })
        })
      })]
    }), /* @__PURE__ */ jsxs(Menu, {
      id: "simple-menu",
      anchorEl,
      keepMounted: true,
      open: Boolean(anchorEl),
      onClose: handleClose,
      children: [/* @__PURE__ */ jsxs(MenuItem, {
        onClick: handleClose,
        children: [/* @__PURE__ */ jsxs(ListItemIcon, {
          children: [/* @__PURE__ */ jsx(Person, {}), " "]
        }), " ", /* @__PURE__ */ jsx(Typography, {
          ant: "inherit",
          children: /* @__PURE__ */ jsx(Link, {
            href: "/profile",
            children: "Profile"
          })
        })]
      }), /* @__PURE__ */ jsxs(MenuItem, {
        onClick: handleClose,
        children: [/* @__PURE__ */ jsxs(ListItemIcon, {
          children: [/* @__PURE__ */ jsx(Pencil, {}), " "]
        }), /* @__PURE__ */ jsx(Link, {
          href: "/profile/edit-profile",
          children: " My account"
        })]
      }), /* @__PURE__ */ jsxs(MenuItem, {
        onClick: handleClose,
        children: [/* @__PURE__ */ jsxs(ListItemIcon, {
          children: [/* @__PURE__ */ jsx(Power, {}), " "]
        }), /* @__PURE__ */ jsx(Link, {
          href: route("logout"),
          method: "post",
          children: "Logout"
        }), " "]
      })]
    }), /* @__PURE__ */ jsxs(Menu, {
      id: "lock-menu",
      anchorEl: anchorEl1,
      keepMounted: true,
      open: Boolean(anchorEl1),
      onClose: handleClose1,
      children: [auth.user.notifications.map((option, index) => /* @__PURE__ */ jsx(MenuItem, {
        onClick: (event) => handleMenuItemClick(event, index),
        children: option.data.notifiable_id
      }, index)), /* @__PURE__ */ jsx("div", {
        className: "pt-2 pb-2 m-2 text-white bg-primaries text-center rounded-full",
        children: "mark all as read"
      })]
    })]
  });
}
export {
  Authenticated as A
};
