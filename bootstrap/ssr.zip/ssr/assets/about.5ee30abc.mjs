import { Fragment } from "react";
import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeader } from "./pageheader.c3637c95.mjs";
import "react-countup";
import { j as jsx, a as jsxs } from "../ssr.mjs";
import { Link, Head } from "@inertiajs/inertia-react";
import { I as Instructor, M as Mentor, i as img1$1, a as img2$1, b as img3 } from "./mentor.989b08a1.mjs";
import { Container, Row, Col } from "react-bootstrap";
/* empty css                   *//* empty css                     */import "@inertiajs/inertia";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
import "./Hermant-kumar.bd7eb8f5.mjs";
import "react-bootstrap/Carousel";
import "./logo.d6c74f57.mjs";
import "./DropBottom.c156e3a4.mjs";
import "react-bootstrap/Button";
import "react-bootstrap/Offcanvas";
import "react-bootstrap/Form";
import "./PrimaryButton.4bb116fc.mjs";
/* empty css                 */const imaging = "/build/assets/blog-details.008a812e.jpg";
const img1 = "/build/assets/01.b9a74391.jpg";
const img2 = "/build/assets/02.535f4e85.jpg";
const img4 = "/build/assets/03.4793bd8d.jpg";
const title$1 = "Build Your Project Management Skills Online Anytime";
const btnText = "Sign Up Now";
const skillList = [{
  imgUrl: img1,
  imgAlt: "skill vereda vereda",
  title: "Skilled Instructors",
  desc: "You pick the schedule."
}, {
  imgUrl: img2,
  imgAlt: "skill vereda vereda",
  title: "Get Certificate",
  desc: "Study at your comfort."
}, {
  imgUrl: img4,
  imgAlt: "skill vereda vereda",
  title: "Online Classes",
  desc: "Study at your comfort ."
}, {
  imgUrl: img4,
  imgAlt: "skill vereda vereda",
  title: "Educator Helps",
  desc: "Understand easy."
}];
const Skill = () => {
  return /* @__PURE__ */ jsx("div", {
    className: "skill-section padding-tb",
    children: /* @__PURE__ */ jsx("div", {
      className: "container",
      children: /* @__PURE__ */ jsxs("div", {
        className: "row justify-content-center",
        children: [/* @__PURE__ */ jsx("div", {
          className: "col-lg-5 col-12",
          children: /* @__PURE__ */ jsxs("div", {
            className: "section-header",
            children: [/* @__PURE__ */ jsx("h2", {
              className: "title",
              children: title$1
            }), /* @__PURE__ */ jsx(Link, {
              href: "/register",
              className: "lab-btn",
              children: /* @__PURE__ */ jsx("span", {
                children: btnText
              })
            })]
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "col-lg-7 col-12",
          children: /* @__PURE__ */ jsx("div", {
            className: "section-wrpper",
            children: /* @__PURE__ */ jsx("div", {
              className: "row g-4 justify-content-center row-cols-sm-2 row-cols-1",
              children: skillList.map((val, i) => /* @__PURE__ */ jsx("div", {
                className: "col",
                children: /* @__PURE__ */ jsx("div", {
                  className: "skill-item",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "skill-inner",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "skill-thumb",
                      children: /* @__PURE__ */ jsx("img", {
                        src: `${val.imgUrl}`,
                        alt: `${val.imgAlt}`
                      })
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "skill-content",
                      children: [/* @__PURE__ */ jsx("h5", {
                        children: val.title
                      }), /* @__PURE__ */ jsx("p", {
                        children: val.desc
                      })]
                    })]
                  })
                })
              }, i))
            })
          })
        })]
      })
    })
  });
};
const about1 = "/build/assets/01.4333133b.jpg";
const about2 = "/build/assets/02.f920a9a9.jpg";
const subTitle = "About Vereda Digital Learning";
const title = "Good Qualification Services And Better Skills";
const desc = "We Provide digital academic studies and live class that enables learners through rigorous and highly specialized training. Our aim is to revolutionise tech education in India. We believe in outcomes and skills over degrees and Certificates.";
const year = "30+";
const expareance = "Years Of Experiences";
const aboutList = [{
  imgUrl: img1$1,
  imgAlt: "about icon vereda vereda",
  title: "Skilled Instructors",
  desc: "Our instructor are provided with tools and skills to teach what you love."
}, {
  imgUrl: img2$1,
  imgAlt: "about icon vereda vereda",
  title: "Get Certificate",
  desc: "When you complete all of the courses in the program, you`ll earn a certificate to share with your professional network as well as unlock access to career support resources to help you kickstart your new career"
}, {
  imgUrl: img3,
  imgAlt: "about icon vereda vereda",
  title: "Online Classes",
  desc: "Our classes are all online base studies, students can study at their own comfort zone."
}];
const AboutPage = () => {
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: "About us",
      children: [/* @__PURE__ */ jsx("meta", {
        name: "description",
        content: "Focus on providing high-quality training and education to help individuals to develope the skill they need to succeed in the workforce."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:vereda.co.in",
        content: "https://vereda.co.in/pages about"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "About Vereda DIgital Technologies"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Focus on providing high-quality training and education to help individuals to develope the skill they need to succeed in the workforce. "
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        itemProp: "image",
        content: "../Images/logo.png"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/pages/about"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/pages/about"
      })]
    }), /* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeader, {
      title: "About Vereda",
      curPage: "About"
    }), /* @__PURE__ */ jsx("div", {
      className: "about-section style-3 padding-tb section-bg",
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "row justify-content-center row-cols-xl-2 row-cols-1 align-items-center",
          children: [/* @__PURE__ */ jsx("div", {
            className: "col",
            children: /* @__PURE__ */ jsxs("div", {
              className: "about-left",
              children: [/* @__PURE__ */ jsx("div", {
                className: "about-thumb",
                children: /* @__PURE__ */ jsx("img", {
                  src: about1,
                  alt: "about"
                })
              }), /* @__PURE__ */ jsx("div", {
                className: "abs-thumb",
                children: /* @__PURE__ */ jsx("img", {
                  src: about2,
                  alt: "about"
                })
              }), /* @__PURE__ */ jsxs("div", {
                className: "about-left-content",
                children: [/* @__PURE__ */ jsx("h3", {
                  children: year
                }), /* @__PURE__ */ jsx("p", {
                  children: expareance
                })]
              })]
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "col",
            children: /* @__PURE__ */ jsxs("div", {
              className: "about-right",
              children: [/* @__PURE__ */ jsxs("div", {
                className: "section-header",
                children: [/* @__PURE__ */ jsx("span", {
                  className: "subtitle",
                  children: subTitle
                }), /* @__PURE__ */ jsx("h2", {
                  className: "title",
                  children: title
                }), /* @__PURE__ */ jsx("p", {
                  children: desc
                })]
              }), /* @__PURE__ */ jsx("div", {
                className: "section-wrapper",
                children: /* @__PURE__ */ jsx("ul", {
                  className: "lab-ul",
                  children: aboutList.map((val, i) => /* @__PURE__ */ jsxs("li", {
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "sr-left",
                      children: /* @__PURE__ */ jsx("img", {
                        src: `${val.imgUrl}`,
                        alt: `${val.imgAlt}`
                      })
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "sr-right",
                      children: [/* @__PURE__ */ jsx("h5", {
                        children: val.title
                      }), /* @__PURE__ */ jsx("p", {
                        children: val.desc
                      })]
                    })]
                  }, i))
                })
              })]
            })
          })]
        })
      })
    }), /* @__PURE__ */ jsx("section", {
      className: "bg-secondarys",
      children: /* @__PURE__ */ jsxs(Container, {
        children: [/* @__PURE__ */ jsxs("div", {
          className: "section-header pt-3",
          children: [/* @__PURE__ */ jsx("h2", {
            className: "title mt-5 mb-3",
            children: "About us at Vereda"
          }), /* @__PURE__ */ jsx("span", {
            className: "subtitle",
            children: "Company mission"
          }), /* @__PURE__ */ jsxs("p", {
            children: ["Focus on providing high-quality training and education to help individuals to develope the skill they need to succeed in the workforce. Connecting graduate with employment opportunities and helping to bridge the gap between education and employment.", /* @__PURE__ */ jsx("br", {}), "Connecting graduates with employment opportunities and helping to bridge the gap between education and employement."]
          })]
        }), /* @__PURE__ */ jsxs(Row, {
          className: "header-block",
          children: [/* @__PURE__ */ jsx(Col, {
            lg: "7",
            sm: "12",
            md: "12",
            children: /* @__PURE__ */ jsxs("div", {
              className: "section-header pt-3 pb-5",
              children: [/* @__PURE__ */ jsx("h4", {
                className: "title mt-5 mb-3",
                children: "About Vereda"
              }), /* @__PURE__ */ jsx("span", {
                className: "subtitle",
                children: "Our Value"
              }), /* @__PURE__ */ jsxs("p", {
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Quality : "
                }), " Providing high-quality training and education that prepares individuals for the workforce and help them succeed in their careers."]
              }), /* @__PURE__ */ jsxs("p", {
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Accessibility : "
                }), " Making education the training accessible to all individuals, regargdless of their background or finiancial situation."]
              }), /* @__PURE__ */ jsxs("p", {
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Impact:"
                }), " Making a positibe impact on the communities and industries it serves by connecting graduates with employment opportunities."]
              }), /* @__PURE__ */ jsxs("p", {
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Innovation : "
                }), "Using cutting-edge technology and pedagogy for training and education."]
              }), /* @__PURE__ */ jsxs("p", {
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Student-centricity : "
                }), "Putting the needs and goals of the students first and providing them with personalised support and guidance."]
              }), /* @__PURE__ */ jsxs("p", {
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Sustainability :"
                }), "Creating a sustainable business model that benefits students, employers, and the company itself."]
              }), /* @__PURE__ */ jsxs("p", {
                children: [/* @__PURE__ */ jsx("b", {
                  children: "Collaboration : "
                }), " Building partnerships with employers, educational institutions, and other organisations to provide studens with a comprehensive education and a smooth transition to the workforce."]
              })]
            })
          }), /* @__PURE__ */ jsx(Col, {
            children: /* @__PURE__ */ jsx("div", {
              className: "about-thumb",
              children: /* @__PURE__ */ jsx("img", {
                src: imaging,
                width: "90%",
                alt: "about"
              })
            })
          })]
        })]
      })
    }), /* @__PURE__ */ jsx(Instructor, {}), /* @__PURE__ */ jsx(Mentor, {}), /* @__PURE__ */ jsx(Skill, {}), /* @__PURE__ */ jsx(Footer, {})]
  });
};
export {
  AboutPage as default
};
