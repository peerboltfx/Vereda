import { useState, useEffect } from "react";
import { G as Guest } from "./GuestLayout.05f8bf09.mjs";
import { I as InputError } from "./InputError.2782cac0.mjs";
import { I as InputLabel } from "./InputLabel.4e3bf89c.mjs";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { a as jsxs, j as jsx, F as Fragment } from "../ssr.mjs";
import { usePage, useForm, Head, Link } from "@inertiajs/inertia-react";
import { Col, Alert, Form, Button, Spinner, InputGroup } from "react-bootstrap";
import { A as ApplicationLogo } from "./ApplicationLogo.c9284209.mjs";
import { V as Vector } from "./sign-up-vector.6ca78592.mjs";
import { PersonCircle } from "react-bootstrap-icons";
import axios from "axios";
import "react-countdown";
import { C as Checkbox } from "./Checkbox.8dcffd6f.mjs";
import { s as signup } from "./sign-up-vector.e1bc22e5.mjs";
/* empty css                 */import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
import "./logo.d6c74f57.mjs";
function Register() {
  let referral;
  const {
    flash
  } = usePage().props;
  if (window.sessionStorage.getItem("referral")) {
    referral = window.sessionStorage.getItem("name");
    window.sessionStorage.getItem("referral");
  }
  let session_phone;
  const {
    data,
    setData,
    post,
    processing,
    errors,
    reset
  } = useForm({
    phone: session_phone || "",
    otp: "",
    remember: ""
  });
  const [verify, setVerify] = useState(false);
  useEffect(() => {
    return () => {
      reset("password", "password_confirmation");
    };
  }, []);
  const onHandleChange = (event) => {
    setData(event.target.name, event.target.type === "checkbox" ? event.target.checked : event.target.value);
  };
  const submit = (e) => {
    e.preventDefault();
    post(route("OTPVerify"));
  };
  const [showAlert, setAlert] = useState(false);
  const [handleLoad, setHandleLoad] = useState(false);
  const [messaging, setMessaging] = useState(null);
  const [counter, setCounter] = useState(null);
  const [popper, setPopper] = useState(null);
  useEffect(() => {
    const timer = counter > 0 && setInterval(() => setCounter(counter - 1), 1e3);
    return () => {
      clearInterval(timer);
    };
  }, [counter]);
  useEffect(() => {
    const timing = popper > 0 && setInterval(() => setPopper(popper - 1), 1e3);
    return () => {
      clearInterval(timing);
    };
  }, [popper]);
  const NewOTP = (e) => {
    e.preventDefault();
    setHandleLoad(true);
    axios.post("/sign-up", {
      "phone": data.phone
    }).then((res) => {
      if (res.data == "We have sent otp to your number, valid for 2 minutes") {
        setAlert("success");
        setVerify(true);
        setCounter(40);
        setMessaging(res.data);
        setHandleLoad(false);
        window.sessionStorage.setItem("phone", data.phone);
      } else {
        setAlert("success");
        setMessaging(res.data);
        setHandleLoad(false);
      }
    }).catch((err) => {
      console.log(err);
      setHandleLoad(false);
      setAlert("failed");
      setMessaging("Error processing file, try Again");
    });
  };
  session_phone = window.sessionStorage.getItem("phone");
  if (showAlert == "failed") {
    setInterval(() => {
      setAlert(null);
    }, 1e3 * 10);
  }
  return /* @__PURE__ */ jsxs(Guest, {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: "Register",
      children: [/* @__PURE__ */ jsx("meta", {
        property: "og:vereda.co.in",
        content: "https://vereda.co.in/register"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Register a free account in vereda digital and start studying at your own comfort. "
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Register"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Register a free account in vereda digital and start studying at your own comfort."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        itemProp: "image",
        content: signup
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/register"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/register"
      })]
    }), status && /* @__PURE__ */ jsx("div", {
      className: "mb-4 font-medium text-sm text-green-600",
      children: status
    }), /* @__PURE__ */ jsxs(Col, {
      md: "6",
      children: [referral && /* @__PURE__ */ jsxs("button", {
        style: {
          position: "relative",
          top: "10px",
          left: "10px"
        },
        className: "text-color-white  mobile-hide shadow rounded-full pl-5 pb-1 pt-1 pr-5 bg-primary flex",
        children: [/* @__PURE__ */ jsx("span", {
          className: "mr-3 mt-1",
          children: /* @__PURE__ */ jsx(PersonCircle, {
            className: "text-color-white  fw-bold"
          })
        }), " ", referral]
      }), /* @__PURE__ */ jsxs("div", {
        className: "min-h-screen mobile-hide flex flex-col sm:justify-center item-center pt-6 sm:pt-0",
        children: [/* @__PURE__ */ jsx("div", {
          className: "mt-10 ml-auto mr-auto",
          children: /* @__PURE__ */ jsx(Link, {
            href: "/",
            children: /* @__PURE__ */ jsx(ApplicationLogo, {
              width: "250px",
              className: "w-20 h-20 fill-current text-gray-500"
            })
          })
        }), /* @__PURE__ */ jsx("div", {
          style: {
            width: "70%"
          },
          className: "ml-auto mr-auto",
          children: /* @__PURE__ */ jsx("img", {
            src: Vector
          })
        })]
      })]
    }), /* @__PURE__ */ jsx(Col, {
      md: "6",
      children: /* @__PURE__ */ jsxs("div", {
        className: "min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100",
        children: [/* @__PURE__ */ jsx("div", {
          className: "desktop-hide mt-10 ml-auto mr-auto",
          children: /* @__PURE__ */ jsx(Link, {
            href: "/",
            children: /* @__PURE__ */ jsx(ApplicationLogo, {
              width: "190px",
              className: "w-20 h-20 fill-current text-gray-500"
            })
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "",
          children: [/* @__PURE__ */ jsx("div", {
            className: "ml-auto desktop-hide w-80 mr-auto",
            children: /* @__PURE__ */ jsx("img", {
              src: Vector
            })
          }), /* @__PURE__ */ jsx("h4", {
            className: "fw-bold ml-auto capitalize  mt-4",
            children: "Get started"
          }), /* @__PURE__ */ jsxs("p", {
            className: "fs-6 fw-bold Capitalize",
            children: ["Already Have an account? ", /* @__PURE__ */ jsx(Link, {
              href: route("login"),
              className: "",
              children: /* @__PURE__ */ jsx("span", {
                className: "text-blue-sm capitalize",
                children: "sign in"
              })
            })]
          })]
        }), /* @__PURE__ */ jsxs("div", {
          className: "w-full sm:max-w-md mt-3 overflow-hidden bg-white p-3 sm:rounded-lg",
          children: [showAlert == "success" && /* @__PURE__ */ jsxs(Alert, {
            variant: "",
            children: [messaging + " ", /* @__PURE__ */ jsxs("span", {
              className: "fw-bold",
              children: ["+91 ", session_phone ? session_phone : data.phone]
            }), " "]
          }), showAlert == "failed" && /* @__PURE__ */ jsx(Alert, {
            variant: "danger",
            children: messaging
          }), /* @__PURE__ */ jsx(InputError, {
            message: flash.error,
            className: "mt-2"
          }), /* @__PURE__ */ jsx("form", {
            onSubmit: submit,
            children: verify ? /* @__PURE__ */ jsxs(Fragment, {
              children: [/* @__PURE__ */ jsxs("div", {
                className: "mt-2",
                children: [/* @__PURE__ */ jsx(InputLabel, {
                  forInput: "phone",
                  value: "One Time Password"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "number",
                  name: "otp",
                  value: data.otp,
                  onChange: onHandleChange,
                  maxLength: "4",
                  className: "text-center p-2"
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "flex mt-3",
                children: [/* @__PURE__ */ jsx(Checkbox, {
                  name: "remember",
                  value: data.remember,
                  handleChange: onHandleChange
                }), /* @__PURE__ */ jsxs("div", {
                  className: "",
                  children: ["By registering here, I agree to Vereda's ", /* @__PURE__ */ jsx(Link, {
                    className: "fw-bold",
                    href: "/pages/terms-and-conditions",
                    children: "Terms & conditions"
                  }), " and ", /* @__PURE__ */ jsx(Link, {
                    className: "fw-bold",
                    href: "/pages/privacy-policy",
                    children: "Privacy Policy"
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-1 w-100",
                children: [/* @__PURE__ */ jsx("span", {
                  className: counter > 1 ? "text-color-gray fw-bold" : "text-color-dark-blue hidden",
                  children: "Resend OTP"
                }), /* @__PURE__ */ jsx(Button, {
                  onClick: NewOTP,
                  variant: "white",
                  className: counter == 0 ? "fw-bold float-right text-color-dark-blue" : "disabled float-right fw-bold text-color-gray",
                  children: counter == 0 ? /* @__PURE__ */ jsx(Fragment, {
                    children: handleLoad ? /* @__PURE__ */ jsx("span", {
                      className: "mr-5 ml-5",
                      children: /* @__PURE__ */ jsx(Spinner, {
                        animation: "border",
                        size: "sm",
                        className: "ml-5 mr-5",
                        role: "status"
                      })
                    }) : "get otp"
                  }) : counter
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "block items-center justify-end mt-3",
                children: [data.remember ? /* @__PURE__ */ jsx(PrimaryButton, {
                  processing,
                  children: "Verify"
                }) : /* @__PURE__ */ jsx(Button, {
                  variant: "primary",
                  className: "disabled mb-5 px-4 py-2  w-100",
                  children: "Register"
                }), referral && /* @__PURE__ */ jsxs("button", {
                  style: {
                    position: "relative",
                    top: "10px",
                    left: "10px"
                  },
                  className: "text-color-white  desktop-hide shadow rounded-full pl-5 pb-1 pt-1 pr-5 bg-color-baby-blue flex",
                  children: [/* @__PURE__ */ jsx("span", {
                    className: "mr-3 mt-1",
                    children: /* @__PURE__ */ jsx(PersonCircle, {
                      className: "text-color-white  fw-bold"
                    })
                  }), " ", referral]
                })]
              })]
            }) : /* @__PURE__ */ jsxs(Fragment, {
              children: ["  ", /* @__PURE__ */ jsxs("div", {
                children: [/* @__PURE__ */ jsx(InputLabel, {
                  forInput: "phone",
                  value: "Phone"
                }), /* @__PURE__ */ jsxs(InputGroup, {
                  className: "mb-3",
                  children: [/* @__PURE__ */ jsx(InputGroup.Text, {
                    children: "+91"
                  }), /* @__PURE__ */ jsx(Form.Control, {
                    type: "text",
                    name: "phone",
                    value: data.phone,
                    onChange: onHandleChange
                  }), /* @__PURE__ */ jsx(InputError, {
                    message: errors.phone,
                    className: "mt-2"
                  })]
                })]
              }), /* @__PURE__ */ jsx("div", {
                className: "block ml-auto mr-auto items-center justify-end mt-3",
                children: /* @__PURE__ */ jsxs(Button, {
                  variant: "primary",
                  onClick: NewOTP,
                  className: data.phone.length < 10 ? "disabled w-100" : "w-100",
                  children: [handleLoad ? /* @__PURE__ */ jsx("span", {
                    className: "mr-5 ml-5",
                    children: /* @__PURE__ */ jsx(Spinner, {
                      animation: "border",
                      size: "sm",
                      className: "ml-5 mr-5",
                      role: "status"
                    })
                  }) : "get otp", " "]
                })
              })]
            })
          })]
        })]
      })
    })]
  });
}
export {
  Register as default
};
