import { Accordion } from "react-bootstrap";
import { useState } from "react";
import { usePage } from "@inertiajs/inertia-react";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
const ujjwal = "/build/assets/Ujjwal-Verma.1f448e23.png";
const Hermant = "/build/assets/Hermant-kumar.f92fdbcd.png";
const vishal = "/build/assets/vishal.88017007.png";
function Faqs() {
  const [accord1, setAccord1] = useState(false);
  const [accord2, setAccord2] = useState(false);
  const [accord3, setAccord3] = useState(false);
  const [accord4, setAccord4] = useState(false);
  usePage().props;
  const HandleAccord1 = () => {
    setAccord1(!accord1);
  };
  const HandleAccord2 = () => {
    setAccord2(!accord2);
  };
  const HandleAccord3 = () => {
    setAccord3(!accord3);
  };
  const HandleAccord4 = () => {
    setAccord4(!accord4);
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs("div", {
      children: [/* @__PURE__ */ jsx("h4", {
        className: "pt-4 pb-3",
        children: "Frequently Asked Questions"
      }), /* @__PURE__ */ jsxs(Accordion, {
        defaultActiveKey: "0",
        activeKey: "0",
        flush: true,
        children: [/* @__PURE__ */ jsxs(Accordion.Item, {
          children: [/* @__PURE__ */ jsx(Accordion.Header, {
            onClick: HandleAccord1,
            children: "What is the learning experience like with Projects?"
          }), /* @__PURE__ */ jsx("div", {
            className: accord1 ? "dropAccordion" : "dropAccordion show pt-3 pl-2",
            children: "In Projects, you'll complete an activity or scenario by following a set of instructions in an interactive hands-on environment. Project are completed in a local host or real cloud environment and within real intances of various products as opposed to a simulation or demo environment."
          })]
        }), /* @__PURE__ */ jsxs(Accordion.Item, {
          children: [/* @__PURE__ */ jsx(Accordion.Header, {
            onClick: HandleAccord2,
            children: "Benefits of purchasing a Project?"
          }), /* @__PURE__ */ jsx("div", {
            className: accord2 ? "dropAccordion show pt-3 pl-2" : "dropAccordion",
            children: "By purchasing a project, you'll get everything you need to complete the project including temporary access to any product required to complete the Project."
          })]
        }), /* @__PURE__ */ jsxs(Accordion.Item, {
          onClick: HandleAccord3,
          children: [/* @__PURE__ */ jsx(Accordion.Header, {
            children: "Are Projects available on desktop and mobile?"
          }), /* @__PURE__ */ jsx("div", {
            className: accord3 ? "dropAccordion show pt-3 pl-2" : "dropAccordion",
            children: "We highly recommend that you complete Projects on a laptop or desktop only."
          })]
        }), /* @__PURE__ */ jsxs(Accordion.Item, {
          children: [/* @__PURE__ */ jsx(Accordion.Header, {
            onClick: HandleAccord4,
            children: "What is the refund policy?"
          }), /* @__PURE__ */ jsx("div", {
            className: accord4 ? "dropAccordion show pt-3 pl-2" : "dropAccordion",
            children: "Project are not eligible for refunds."
          })]
        })]
      })]
    })
  });
}
export {
  Faqs as F,
  Hermant as H,
  ujjwal as u,
  vishal as v
};
