import { useRef, useEffect } from "react";
import { j as jsx } from "../ssr.mjs";
function TextInput({
  type = "text",
  name,
  value,
  className,
  autoComplete,
  required,
  isFocused,
  handleChange
}) {
  const input = useRef();
  useEffect(() => {
    if (isFocused) {
      input.current.focus();
    }
  }, []);
  return /* @__PURE__ */ jsx("div", {
    className: "flex flex-col items-start",
    children: /* @__PURE__ */ jsx("input", {
      type,
      name,
      value,
      className: `border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm ` + className,
      ref: input,
      autoComplete,
      required,
      onChange: (e) => handleChange(e)
    })
  });
}
export {
  TextInput as T
};
