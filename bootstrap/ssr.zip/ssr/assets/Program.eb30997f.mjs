import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head, Link } from "@inertiajs/inertia-react";
import { Alert, CloseButton, Card, Container, Row, Col, Form } from "react-bootstrap";
/* empty css                 */import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
import { Editor } from "react-draft-wysiwyg";
import { EditorState } from "draft-js";
import { convertToHTML } from "draft-convert";
/* empty css                               */import DOMPurify from "dompurify";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Program(props) {
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const handleClose1 = () => setShow1(false);
  const handleClose = () => setShow(false);
  const {
    programs,
    flash,
    batch,
    moderator
  } = usePage().props;
  const [values, setValue] = useState({
    "price": "",
    "decription": "",
    "program": "",
    "period": "",
    "inrprice": "",
    "name": "",
    "starts": "",
    "ends": "",
    "trainer": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const [editorState, setEditorState] = useState(() => EditorState.createEmpty());
  const [convertedContent, setConvertedContent] = useState(null);
  const HandleEditorChange = (state) => {
    setEditorState(state);
    convertContentToHTML();
  };
  const convertContentToHTML = () => {
    let currentContentAsHTML = convertToHTML(editorState.getCurrentContent());
    setConvertedContent(currentContentAsHTML);
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/admin/create-new-program", {
      "first": values,
      "second": convertedContent
    });
  };
  const createMarkup = (html) => {
    return {
      __html: DOMPurify.sanitize(html)
    };
  };
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Admin Page"
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-4 text-color-blue",
        children: " Programs / Create New Program"
      })]
    }),
    childs: /* @__PURE__ */ jsx(Fragment, {
      children: /* @__PURE__ */ jsxs("div", {
        className: "dashnavbar p-2",
        children: [/* @__PURE__ */ jsx("h3", {
          className: "text-center fs-6 fw-bold",
          children: "Programs"
        }), /* @__PURE__ */ jsxs("ul", {
          children: [/* @__PURE__ */ jsx("li", {
            onClick: () => setShow(true),
            children: "Create Program"
          }), /* @__PURE__ */ jsx("li", {
            onClick: () => setShow1(true),
            children: "Create Batch"
          })]
        }), /* @__PURE__ */ jsx("hr", {})]
      })
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Program Page"
    }), /* @__PURE__ */ jsxs("div", {
      className: "py-12  row header-block",
      children: [/* @__PURE__ */ jsx("div", {
        className: "col",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsxs("div", {
            className: "p-6 border-b border-gray-200",
            children: [flash.message && /* @__PURE__ */ jsxs(Fragment, {
              children: ["  ", /* @__PURE__ */ jsxs(Alert, {
                show,
                variant: "success",
                children: [/* @__PURE__ */ jsxs(Alert.Heading, {
                  children: ["Successful ", /* @__PURE__ */ jsx("span", {
                    style: {
                      float: "right",
                      fontSize: "15px"
                    },
                    children: /* @__PURE__ */ jsx(CloseButton, {})
                  })]
                }), /* @__PURE__ */ jsx("p", {
                  children: flash.message
                })]
              })]
            }), /* @__PURE__ */ jsxs(Card, {
              children: [/* @__PURE__ */ jsxs(Card.Header, {
                children: [" ", /* @__PURE__ */ jsx("h1", {
                  className: "ts-5 text-center tw-bold",
                  children: "Batch"
                })]
              }), /* @__PURE__ */ jsx(Card.Body, {
                children: batch.map((data, index) => {
                  return /* @__PURE__ */ jsxs("div", {
                    className: "overflow-hidden mt-3 shadow-sm sm:rounded-lg",
                    children: [/* @__PURE__ */ jsxs("p", {
                      className: " pl-5 pt-4 text-color-blue",
                      children: ["Batch ", data.id]
                    }), /* @__PURE__ */ jsx("h5", {
                      className: "fs-5 text-color-dark-blue  pl-5",
                      children: data.name
                    }), /* @__PURE__ */ jsx("hr", {
                      className: "mt-4  text-color-white"
                    }), /* @__PURE__ */ jsx(Container, {
                      className: " ",
                      children: /* @__PURE__ */ jsxs(Row, {
                        children: [/* @__PURE__ */ jsxs("div", {
                          className: "p-1 col",
                          children: [" ", /* @__PURE__ */ jsx(PrimaryButton, {
                            className: " success-size-btn p-3",
                            children: /* @__PURE__ */ jsx(Link, {
                              className: "text-color-white",
                              onSubmit: (e) => {
                                e.preventDefault();
                              },
                              href: `/admin/update/batch/${data.id}`,
                              method: "post",
                              children: data.options == "open" ? "close ?" : "open ?"
                            })
                          })]
                        }), /* @__PURE__ */ jsxs("div", {
                          className: "p-1 col",
                          children: ["  ", /* @__PURE__ */ jsx(PrimaryButton, {
                            className: "col p-2",
                            children: /* @__PURE__ */ jsx(Link, {
                              className: "text-color-white",
                              onSubmit: (e) => {
                                e.preventDefault();
                              },
                              href: `/admin/delete/batch/${data.id}`,
                              method: "post",
                              children: "delete"
                            })
                          }), " "]
                        })]
                      })
                    })]
                  }, data.id);
                })
              })]
            })]
          })
        })
      }), /* @__PURE__ */ jsx("div", {
        className: "col ",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 border-b border-gray-200",
            children: /* @__PURE__ */ jsxs(Card, {
              children: [/* @__PURE__ */ jsxs(Card.Header, {
                children: [" ", /* @__PURE__ */ jsx("h1", {
                  className: "ts-3 text-center tw-bold",
                  children: "Programs"
                })]
              }), /* @__PURE__ */ jsx(Card.Body, {
                children: programs.map((data, index) => {
                  return /* @__PURE__ */ jsxs("div", {
                    className: "overflow-hidden mt-3 shadow-sm sm:rounded-lg",
                    children: [/* @__PURE__ */ jsx("p", {
                      className: " pl-5 pt-4 text-color-blue",
                      children: "program name"
                    }), /* @__PURE__ */ jsx("h1", {
                      className: "fs-4 fw-bold text-color-dark-blue pl-5",
                      children: data.program
                    }), /* @__PURE__ */ jsx("hr", {
                      className: " text-color-dark-blue"
                    }), /* @__PURE__ */ jsx("p", {
                      className: " pl-5 pt-4 text-color-blue",
                      children: "program Price"
                    }), /* @__PURE__ */ jsx("h5", {
                      className: "fs-6 text-color-dark-blue  pl-5",
                      children: data.price.toString("fi-FI").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    }), /* @__PURE__ */ jsx("hr", {
                      className: " text-color-white"
                    }), /* @__PURE__ */ jsx("p", {
                      className: " pl-5 pt-4 text-color-dark-blue ",
                      children: "program Period"
                    }), /* @__PURE__ */ jsxs("h5", {
                      className: "fs-6 text-color-dark-blue pl-5",
                      children: [data.period, " Months"]
                    }), /* @__PURE__ */ jsx("p", {
                      className: " pl-5 pt-4 text-color-dark-blue ",
                      children: "program Period"
                    }), /* @__PURE__ */ jsx("div", {
                      className: "fs-6 text-color-dark-blue  pl-5",
                      dangerouslySetInnerHTML: createMarkup(data.description)
                    }), /* @__PURE__ */ jsxs(Row, {
                      children: [/* @__PURE__ */ jsx(Col, {
                        className: " m-3",
                        children: /* @__PURE__ */ jsx(Link, {
                          href: `/admin/edit-program/${data.random}`,
                          children: /* @__PURE__ */ jsx(PrimaryButton, {
                            className: " success-size-btn p-3",
                            children: "Edit"
                          })
                        })
                      }), /* @__PURE__ */ jsx(Col, {
                        className: " m-3",
                        children: /* @__PURE__ */ jsx(Link, {
                          href: `/admin/delete-program/${data.random}`,
                          children: /* @__PURE__ */ jsx(PrimaryButton, {
                            children: "delete"
                          })
                        })
                      })]
                    })]
                  }, index);
                })
              })]
            })
          })
        })
      }), /* @__PURE__ */ jsxs(Modal, {
        show: show1,
        onHide: handleClose1,
        backdrop: "static",
        keyboard: false,
        size: "lg",
        centered: true,
        children: [/* @__PURE__ */ jsx(Modal.Header, {
          closeButton: true,
          children: /* @__PURE__ */ jsx(Modal.Title, {
            children: "Create Batch"
          })
        }), /* @__PURE__ */ jsx(Modal.Body, {
          children: /* @__PURE__ */ jsxs("form", {
            method: "POST",
            onSubmit: (e) => {
              e.preventDefault();
              Inertia.post("/admin/create-batch", {
                "name": values["name"],
                "ends": values["ends"],
                "starts": values["starts"],
                "trainer": values["trainer"]
              });
            },
            className: "mt-5",
            children: [/* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                children: "Start-Date"
              }), /* @__PURE__ */ jsx(Form.Control, {
                type: "Date",
                value: values.starts,
                onChange: HandleChange,
                name: "starts"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                children: "End-Date"
              }), /* @__PURE__ */ jsx(Form.Control, {
                type: "Date",
                value: values.ends,
                onChange: HandleChange,
                name: "ends"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                children: "Batch"
              }), /* @__PURE__ */ jsxs(Form.Select, {
                value: values.name,
                onChange: HandleChange,
                name: "name",
                children: [/* @__PURE__ */ jsx("option", {
                  children: "Select"
                }), programs.map(($data) => {
                  return /* @__PURE__ */ jsx("option", {
                    value: $data.program,
                    children: $data.program
                  }, $data.id);
                })]
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                children: "Assign Moderator to Batch"
              }), /* @__PURE__ */ jsxs(Form.Select, {
                name: "trainer",
                onChange: HandleChange,
                value: values.trainer,
                children: [/* @__PURE__ */ jsx("option", {
                  children: "select Moderator / Trainer"
                }), moderator.map((data, index) => {
                  return /* @__PURE__ */ jsx("option", {
                    value: data.id,
                    children: data.name
                  }, index);
                })]
              })]
            }), /* @__PURE__ */ jsx("div", {
              className: "mt-3 col-3",
              children: /* @__PURE__ */ jsx(PrimaryButton, {
                className: "success-size-btn ",
                children: " Create Batch"
              })
            })]
          })
        }), /* @__PURE__ */ jsx(Modal.Footer, {
          children: /* @__PURE__ */ jsx("div", {
            children: /* @__PURE__ */ jsx(Button, {
              variant: "secondary",
              onClick: handleClose1,
              children: "Close"
            })
          })
        })]
      }), /* @__PURE__ */ jsxs(Modal, {
        show,
        onHide: handleClose,
        backdrop: "static",
        keyboard: false,
        size: "lg",
        centered: true,
        children: [/* @__PURE__ */ jsx(Modal.Header, {
          closeButton: true,
          children: /* @__PURE__ */ jsx(Modal.Title, {
            children: "Create Program"
          })
        }), /* @__PURE__ */ jsxs(Modal.Body, {
          children: [/* @__PURE__ */ jsxs("form", {
            method: "POST",
            onSubmit: HandleSubmit,
            className: "mt-5",
            children: [/* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                children: "Program/Service Name"
              }), /* @__PURE__ */ jsx(Form.Control, {
                type: "text",
                value: values.program,
                onChange: HandleChange,
                name: "program",
                required: true
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                htmlFor: "price",
                children: "Full Price "
              }), /* @__PURE__ */ jsx(Form.Control, {
                type: "number",
                value: values.price,
                onChange: HandleChange,
                name: "price",
                required: true
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                htmlFor: "price",
                children: "INR Price "
              }), /* @__PURE__ */ jsx(Form.Control, {
                type: "number",
                value: values.inrprice,
                onChange: HandleChange,
                name: "inrprice",
                required: true
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "mt-3",
              children: [/* @__PURE__ */ jsx(Form.Label, {
                htmlFor: "period",
                children: "Period "
              }), /* @__PURE__ */ jsx(Form.Control, {
                type: "number",
                value: values.period,
                onChange: HandleChange,
                name: "period",
                required: true
              })]
            }), /* @__PURE__ */ jsxs("div", {
              children: [/* @__PURE__ */ jsx(Form.Label, {
                children: "Description Content."
              }), /* @__PURE__ */ jsx(Editor, {
                editorState,
                onEditorStateChange: HandleEditorChange,
                toolbarClassName: "toolbar-class",
                wrapperClassName: "wrapper-class",
                editorClassName: "editor-class",
                value: values.content,
                name: "description"
              })]
            }), /* @__PURE__ */ jsx(Col, {
              children: /* @__PURE__ */ jsx(PrimaryButton, {
                className: "mt-4",
                children: "Submit"
              })
            })]
          }), flash.message && /* @__PURE__ */ jsxs(Fragment, {
            children: ["  ", /* @__PURE__ */ jsxs(Alert, {
              show,
              variant: "success",
              children: [/* @__PURE__ */ jsxs(Alert.Heading, {
                children: ["Successful ", /* @__PURE__ */ jsx("span", {
                  style: {
                    float: "right",
                    fontSize: "15px"
                  },
                  children: /* @__PURE__ */ jsx(CloseButton, {
                    onClick: () => {
                      setShow(false);
                    }
                  })
                })]
              }), /* @__PURE__ */ jsx("p", {
                children: flash.message
              })]
            })]
          })]
        }), /* @__PURE__ */ jsxs(Modal.Footer, {
          children: [/* @__PURE__ */ jsx(Button, {
            variant: "secondary",
            onClick: handleClose,
            children: "Close"
          }), /* @__PURE__ */ jsx(Button, {
            variant: "primary",
            children: "Understood"
          })]
        })]
      })]
    })]
  });
}
export {
  Program as default
};
