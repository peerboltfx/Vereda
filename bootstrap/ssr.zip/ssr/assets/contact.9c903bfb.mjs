import { useState, Fragment } from "react";
import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeader } from "./pageheader.c3637c95.mjs";
import { j as jsx, a as jsxs, F as Fragment$1 } from "../ssr.mjs";
import { Inertia } from "@inertiajs/inertia";
import { usePage, Head } from "@inertiajs/inertia-react";
import { Alert } from "react-bootstrap";
/* empty css                   *//* empty css                     */import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const GoogleMap = () => {
  return /* @__PURE__ */ jsx("div", {
    className: "map-area",
    children: /* @__PURE__ */ jsx("div", {
      className: "maps",
      children: /* @__PURE__ */ jsx("iframe", {
        src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3597.7468856748997!2d85.13352141494235!3d25.6133257837043!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ed59e81e53b22d%3A0x4c9edee41e414d59!2svereda%20digital%20technologies!5e0!3m2!1sen!2snp!4v1672769734149!5m2!1sen!2snp"
      })
    })
  });
};
const img1 = "/build/assets/01.a653f754.png";
const img2 = "/build/assets/02.ca2c69c5.png";
const img3 = "/build/assets/03.6cb0de24.png";
const img4 = "/build/assets/04.bf396524.png";
const subTitle = "Get in touch with us";
const title = "We're Always Eager To Hear From You!";
const conSubTitle = "Get in touch with Contact us";
const conTitle = "Fill The Form Below So We Can Get To Know You And Your Needs Better.";
const btnText = "Send our Message";
const contactList = [{
  imgUrl: img1,
  imgAlt: "contact icon",
  title: "Office Address",
  desc: "Sinha Library road, Venture park Patna"
}, {
  imgUrl: img2,
  imgAlt: "contact icon",
  title: "Phone number",
  desc: "+919570994444"
}, {
  imgUrl: img3,
  imgAlt: "contact icon",
  title: "Send email",
  desc: "support@vereda.co.in"
}, {
  imgUrl: img4,
  imgAlt: "contact icon",
  title: "Our website",
  desc: "www.vereda.co.in"
}];
const ContactPage = () => {
  const {
    flash
  } = usePage().props;
  const [values, setValues] = useState({
    "name": "",
    "email": "",
    "phone": "",
    "message": "",
    "subject": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/request/send-message", values);
  };
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsxs(Head, {
      title: "Contact us",
      children: [/* @__PURE__ */ jsx("meta", {
        name: "description",
        content: "Contact us by filling the form found on this page."
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/pages/contact"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Contact"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "Contact us by filling the form found on this page. "
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        itemProp: "image",
        content: "../Images/banner.jpg"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/pages/contact"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in/pages/contact"
      })]
    }), /* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeader, {
      title: "Get In Touch With Us",
      curPage: "Contact Us"
    }), /* @__PURE__ */ jsx("div", {
      className: "map-address-section padding-tb section-bg",
      children: /* @__PURE__ */ jsxs("div", {
        className: "container",
        children: [/* @__PURE__ */ jsxs("div", {
          className: "section-header text-center",
          children: [/* @__PURE__ */ jsx("span", {
            className: "subtitle",
            children: subTitle
          }), /* @__PURE__ */ jsx("h2", {
            className: "title",
            children: title
          })]
        }), /* @__PURE__ */ jsx("div", {
          className: "section-wrapper",
          children: /* @__PURE__ */ jsxs("div", {
            className: "row flex-row-reverse",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col-xl-4 col-lg-5 col-12",
              children: /* @__PURE__ */ jsx("div", {
                className: "contact-wrapper",
                children: contactList.map((val, i) => /* @__PURE__ */ jsxs("div", {
                  className: "contact-item",
                  children: [/* @__PURE__ */ jsx("div", {
                    className: "contact-thumb",
                    children: /* @__PURE__ */ jsx("img", {
                      src: `${val.imgUrl}`,
                      alt: `${val.imgAlt}`
                    })
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "contact-content",
                    children: [/* @__PURE__ */ jsx("h6", {
                      className: "title",
                      children: val.title
                    }), /* @__PURE__ */ jsx("p", {
                      children: val.desc
                    })]
                  })]
                }, i))
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col-xl-8 col-lg-7 col-12",
              children: /* @__PURE__ */ jsx(GoogleMap, {})
            })]
          })
        })]
      })
    }), /* @__PURE__ */ jsx("div", {
      className: "contact-section padding-tb",
      children: /* @__PURE__ */ jsxs("div", {
        className: "container",
        children: [/* @__PURE__ */ jsxs("div", {
          className: "section-header text-center",
          children: [/* @__PURE__ */ jsx("span", {
            className: "subtitle",
            children: conSubTitle
          }), /* @__PURE__ */ jsx("h2", {
            className: "title",
            children: conTitle
          })]
        }), /* @__PURE__ */ jsx("div", {
          className: "section-wrapper",
          children: /* @__PURE__ */ jsxs("form", {
            onSubmit: HandleSubmit,
            className: "contact-form",
            children: [/* @__PURE__ */ jsx("div", {
              className: "form-group",
              children: /* @__PURE__ */ jsx("input", {
                type: "text",
                onChange: HandleChange,
                value: values.name,
                name: "name",
                placeholder: "Your Name *"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "form-group",
              children: /* @__PURE__ */ jsx("input", {
                type: "text",
                onChange: HandleChange,
                value: values.email,
                name: "email",
                placeholder: "Your Email *"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "form-group",
              children: /* @__PURE__ */ jsx("input", {
                type: "text",
                onChange: HandleChange,
                value: values.number,
                name: "number",
                placeholder: "Mobile Number *"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "form-group",
              children: /* @__PURE__ */ jsx("input", {
                type: "text",
                name: "subject",
                onChange: HandleChange,
                value: values.subject,
                placeholder: "Your Subject *"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "form-group w-100",
              children: /* @__PURE__ */ jsx("textarea", {
                rows: "8",
                type: "text",
                name: "message",
                onChange: HandleChange,
                value: values.message,
                placeholder: "Your Message"
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "form-group w-100 text-center",
              children: /* @__PURE__ */ jsx("button", {
                className: "lab-btn",
                children: /* @__PURE__ */ jsx("span", {
                  children: btnText
                })
              })
            }), flash.success && /* @__PURE__ */ jsx(Fragment$1, {
              children: /* @__PURE__ */ jsx(Alert, {
                className: "m-2",
                variant: "success",
                children: flash.success
              })
            })]
          })
        })]
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
};
export {
  ContactPage as default
};
