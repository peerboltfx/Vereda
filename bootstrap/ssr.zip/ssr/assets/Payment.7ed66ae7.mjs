import { useState } from "react";
/* empty css                 */import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
import { FormControl } from "react-bootstrap";
import { Inertia } from "@inertiajs/inertia";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import { F as Fullstack } from "./fullstack-2.a4f71d98.mjs";
import { F as Flutter } from "./Flutter-App-development.33b56beb.mjs";
import DOMPurify from "dompurify";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Payment(props) {
  const {
    orderId,
    amount,
    razorpayId,
    name,
    batch,
    receipt,
    verified,
    describe,
    flash
  } = usePage().props;
  const [values, setValue] = useState({
    "first_name": "",
    "last_name": "",
    "discount": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  if (props.dev == "Full Stack Development Program")
    ;
  else if (props.dev == "Flutter Development")
    ;
  const createMarkup = (html) => {
    return {
      __html: DOMPurify.sanitize(html)
    };
  };
  function loadScript(src) {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  }
  async function displayRazorpay() {
    const res = await loadScript("https://checkout.razorpay.com/v1/checkout.js");
    if (!res) {
      alert("Razorpay SDK failed to load. Are you online?");
      return;
    }
    if (orderId == void 0) {
      Inertia.post("/checkorder", {
        data_amount: props.price,
        data_describe: props.dev,
        data_price: props.price,
        data_discount: values.discount
      });
    }
    const options = {
      key: razorpayId,
      amount,
      currency: "INR",
      name: props.dev,
      image: "https://vereda.co.in/Images/logo.png",
      description: receipt,
      order_id: orderId,
      prefill: {
        name: `${props.auth.user.email}`,
        email: `${props.auth.user.email}`,
        contact: ""
      },
      theme: {
        color: "white"
      },
      handler: function(response) {
        var values2 = {
          razorpay_signature: response.razorpay_signature,
          razorpay_order_id: response.razorpay_order_id,
          transactionid: response.razorpay_payment_id,
          transactionamount: amount
        };
        Inertia.post("/razorpaypayment", {
          orderId,
          amount,
          razorpay_order_id: values2.razorpay_order_id,
          razorpay_payment_id: values2.transactionid,
          describe: props.dev,
          price: amount,
          batchid: batch.id
        });
      }
    };
    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
  }
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      plans: props.plans,
      errors: props.errors,
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Checkout - " + props.dev
      }), /* @__PURE__ */ jsx("div", {
        className: "checkout",
        children: /* @__PURE__ */ jsx("section", {
          className: "py-5",
          children: /* @__PURE__ */ jsx("div", {
            className: "container px-4 px-lg-5 my-5",
            children: /* @__PURE__ */ jsxs("div", {
              className: "row",
              children: [/* @__PURE__ */ jsxs("div", {
                className: "col-md-4 order-md-2 mb-4",
                children: [/* @__PURE__ */ jsxs("h4", {
                  className: "d-flex justify-content-between align-items-center mb-3",
                  children: [/* @__PURE__ */ jsxs("span", {
                    className: "text-muted",
                    children: ["Join", " " + props.dev + " ", " Batch"]
                  }), /* @__PURE__ */ jsx("span", {
                    className: "badge badge-pill bg-primaries",
                    children: batch.id
                  })]
                }), /* @__PURE__ */ jsx("ul", {
                  className: "list-group mb-3",
                  children: /* @__PURE__ */ jsxs("li", {
                    className: "list-group-item d-block justify-content-between lh-condensed",
                    children: [/* @__PURE__ */ jsxs("div", {
                      className: "mb-3",
                      children: [/* @__PURE__ */ jsx("h6", {
                        className: "my-0",
                        children: props.dev
                      }), /* @__PURE__ */ jsx("small", {
                        className: "text-muted",
                        children: "Brief description"
                      }), /* @__PURE__ */ jsx("p", {
                        className: "preview",
                        dangerouslySetInnerHTML: createMarkup(props.describe)
                      })]
                    }), /* @__PURE__ */ jsx("span", {
                      className: "text-muted w-100",
                      children: "Total Price"
                    }), /* @__PURE__ */ jsxs("span", {
                      className: "text-muted  float-right",
                      children: ["INR ", Math.floor(props.price).toLocaleString()]
                    })]
                  })
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "col-md-8 order-md-1",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "w-100",
                  children: [props.dev == "Full Stack Development Program" && /* @__PURE__ */ jsx("img", {
                    src: Fullstack
                  }), props.dev == "Flutter Development Program" && /* @__PURE__ */ jsx("img", {
                    src: Flutter
                  })]
                }), !orderId ? /* @__PURE__ */ jsxs(Fragment, {
                  children: [/* @__PURE__ */ jsx("h3", {
                    className: "mb-2 mt-4",
                    children: " Discount Code"
                  }), /* @__PURE__ */ jsxs("form", {
                    className: "needs-validation",
                    children: [/* @__PURE__ */ jsx("hr", {
                      className: "mb-4"
                    }), /* @__PURE__ */ jsx(FormControl, {
                      className: "w-full",
                      name: "discount",
                      value: values.discount,
                      placeholder: "DASU232",
                      onChange: HandleChange
                    }), /* @__PURE__ */ jsx("button", {
                      className: "bg-primaries text-white p-2 mt-5 px-4 rounded-pill",
                      onClick: displayRazorpay,
                      type: "button",
                      children: " Confirm Order"
                    })]
                  })]
                }) : /* @__PURE__ */ jsxs("button", {
                  className: "bg-primaries text-white mt-5 px-4 p-2 rounded-pill",
                  onClick: displayRazorpay,
                  type: "button",
                  children: [" Continue  INR ", " " + Math.floor(amount).toLocaleString(), "  "]
                })]
              }), flash.message && /* @__PURE__ */ jsx("p", {
                className: "mt-3 text-center",
                children: flash.message
              })]
            })
          })
        })
      })]
    })
  });
}
export {
  Payment as default
};
