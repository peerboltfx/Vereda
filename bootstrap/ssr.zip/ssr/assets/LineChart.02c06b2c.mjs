import "react";
import { Chart, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from "chart.js";
import { Line } from "react-chartjs-2";
import { j as jsx } from "../ssr.mjs";
Chart.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);
function LineChart({
  optioning,
  datas,
  textName
}) {
  const options = {
    responsive: true,
    bezierCurve: true,
    bezierCurveTension: 0.4,
    plugins: {
      legend: {
        position: "top"
      },
      title: {
        display: true,
        text: textName
      }
    }
  };
  return /* @__PURE__ */ jsx(Line, {
    options,
    data: datas
  });
}
export {
  LineChart as L
};
