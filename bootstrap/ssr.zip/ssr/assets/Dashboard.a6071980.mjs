import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { Col, Row } from "react-bootstrap";
/* empty css                 */import { Bell } from "react-bootstrap-icons";
import "dompurify";
import { L as LineChart } from "./LineChart.02c06b2c.mjs";
import { a as jsxs, j as jsx, F as Fragment } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "chart.js";
import "react-chartjs-2";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Dashboard(props) {
  const {
    programs,
    progress,
    fullstack,
    classModerator,
    students,
    auth,
    course
  } = usePage().props;
  const [values, setValues] = useState({
    "search": ""
  });
  const labels = fullstack.map((data, index) => {
    return `week ${index + 1}`;
  });
  const dataMain = {
    labels,
    datasets: [{
      label: "Dataset 1",
      data: fullstack.map((data, index) => {
        return data.result;
      }),
      borderColor: "rgb(53, 162, 235)",
      backgroundColor: "rgba(53, 162, 235, 222)"
    }]
  };
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const found = programs.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(values.search)));
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsx(Fragment, {
      children: /* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Dashboard"
      })
    }),
    Programs: programs.map((data, index) => {
      return /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsx(Link, {
          href: `/admin/edit-program/${data.program.split(" ").join("-")}/session/${data.random}`,
          className: "text-color-white",
          children: data.program
        })
      }, index);
    }),
    Search: /* @__PURE__ */ jsxs("div", {
      className: "Search-container",
      children: [/* @__PURE__ */ jsx("div", {
        className: "",
        children: /* @__PURE__ */ jsx("input", {
          onClick: HandleShow,
          type: "text",
          name: "search",
          value: values.search,
          onChange: HandleChange
        })
      }), /* @__PURE__ */ jsx("div", {
        tabIndex: "0",
        onBlur: () => setShow(false),
        className: show ? "Searched sm:rounded-lg pt-5 pl-3 pb-4 shadow relative-left active" : "Searched",
        children: found.map((val) => {
          return /* @__PURE__ */ jsx("div", {
            children: /* @__PURE__ */ jsxs(Link, {
              href: `/en/${val.program.split(" ").join("-")}/session/${val.random}`,
              className: "text-color-dark-blue",
              children: ["  ", val.program]
            })
          }, val.id);
        })
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Dashboard"
    }), /* @__PURE__ */ jsxs("div", {
      className: "flex header-block items-center",
      children: [/* @__PURE__ */ jsxs(Col, {
        lg: "8",
        className: "p-2",
        children: [/* @__PURE__ */ jsx("div", {
          className: "bg-white progress-container flex flex-col sm:justify-center w-100 sm:rounded-lg",
          children: /* @__PURE__ */ jsxs("div", {
            className: "flex header-block",
            children: [/* @__PURE__ */ jsxs("div", {
              className: "flex p-4",
              children: [/* @__PURE__ */ jsxs("div", {
                style: {
                  width: "60px",
                  height: "60px"
                },
                className: " bg-primary rounded-full ml-2 flex flex-column-center items-center",
                children: [/* @__PURE__ */ jsx("h5", {
                  className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                  children: classModerator.length
                }), " "]
              }), /* @__PURE__ */ jsx("h6", {
                className: "text-color-dark-blue mt-2  ml-5 fw-bold w-50",
                children: "Classes Lecturing"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "flex  p-4",
              children: [/* @__PURE__ */ jsxs("div", {
                style: {
                  width: "60px",
                  height: "60px"
                },
                className: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center",
                children: [/* @__PURE__ */ jsx("h5", {
                  className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                  children: students.length
                }), " "]
              }), /* @__PURE__ */ jsx("h6", {
                className: "text-color-dark-blue mt-2  ml-5 fw-bold w-50",
                children: "Active Students"
              })]
            }), /* @__PURE__ */ jsxs("div", {
              className: "flex  p-4",
              children: [/* @__PURE__ */ jsxs("div", {
                style: {
                  width: "60px",
                  height: "60px"
                },
                className: " bg-color-gold rounded-full ml-2 flex flex-column-center items-center",
                children: [/* @__PURE__ */ jsx(Bell, {
                  className: "fs-5 text-color-white ml-auto mr-auto"
                }), " "]
              }), /* @__PURE__ */ jsx("h6", {
                className: "text-color-dark-blue mt-2  ml-5 fw-bold w-50",
                children: "Assignment Progress"
              })]
            })]
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "bg-white mt-4 sm:rounded-lg p-3",
          children: [/* @__PURE__ */ jsx("h5", {
            className: "fw-bold text-color-dark-blue",
            children: "Live class Session"
          }), /* @__PURE__ */ jsx(LineChart, {
            datas: dataMain,
            textName: "student progress"
          })]
        })]
      }), /* @__PURE__ */ jsx(Col, {
        lg: "4",
        className: "pr-4 dashboard-right",
        children: /* @__PURE__ */ jsxs("div", {
          className: "bg-white  p-3 w-100 sm:rounded-lg",
          children: [/* @__PURE__ */ jsx(Col, {
            lg: "9",
            className: "mb-5",
            children: /* @__PURE__ */ jsx("h5", {
              className: "fw-bold mt-3 text-color-dark-blue",
              children: "update Class"
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "",
            children: course.length > 0 ? /* @__PURE__ */ jsxs(Fragment, {
              children: [course.map((data, index) => {
                return /* @__PURE__ */ jsx(Link, {
                  className: "block",
                  href: `/moderator/create-course/${data.program_code}/en/${data.id}`,
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "flex",
                    children: [/* @__PURE__ */ jsx(Col, {
                      lg: "3",
                      children: /* @__PURE__ */ jsxs("div", {
                        style: {
                          width: "50px",
                          height: "50px"
                        },
                        className: "bg-color-baby-blue rounded-full ml-2 flex flex-column-center items-center",
                        children: [/* @__PURE__ */ jsx("h5", {
                          className: "fs-5 fw-bold text-color-white ml-auto mt-auto mb-auto mr-auto",
                          children: "M"
                        }), " "]
                      })
                    }), /* @__PURE__ */ jsxs(Col, {
                      className: "pt-2",
                      children: [/* @__PURE__ */ jsx("h6", {
                        className: "fw-bold ml-3",
                        children: data.topic
                      }), /* @__PURE__ */ jsx("p", {
                        children: new Date(`${data.date}`).toLocaleDateString()
                      })]
                    }), /* @__PURE__ */ jsx(Col, {
                      lg: "3",
                      children: /* @__PURE__ */ jsxs("div", {
                        style: {
                          width: "50px",
                          height: "50px",
                          border: "solid 1px blue"
                        },
                        className: " rounded-full ml-2 flex flex-column-center items-center",
                        children: [/* @__PURE__ */ jsx(Bell, {
                          className: "fs-5 text-color-dark-blue ml-auto mr-auto"
                        }), "  "]
                      })
                    })]
                  })
                }, index);
              }), course.length == 5 && /* @__PURE__ */ jsx(Fragment, {
                children: /* @__PURE__ */ jsx(Link, {
                  href: route("DailyPlanView"),
                  children: /* @__PURE__ */ jsx("div", {
                    style: {
                      width: "100%"
                    },
                    className: " bg-primary pt-3 pb-3 rounded-full absolute-bottom text-white text-center",
                    children: " see more"
                  })
                })
              })]
            }) : /* @__PURE__ */ jsx(Fragment, {
              children: /* @__PURE__ */ jsx("div", {
                className: "flex flex-col sm:justify-center items-center",
                children: /* @__PURE__ */ jsx("h3", {
                  className: "ft-6 text-color-gray",
                  children: "No Course Yet"
                })
              })
            })
          })]
        })
      })]
    }), /* @__PURE__ */ jsx("div", {
      className: "",
      children: /* @__PURE__ */ jsx("div", {
        className: " sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6  border-b border-gray-200",
            children: /* @__PURE__ */ jsx(Row, {
              className: "header-block"
            })
          })
        })
      })
    })]
  });
}
export {
  Dashboard as default
};
