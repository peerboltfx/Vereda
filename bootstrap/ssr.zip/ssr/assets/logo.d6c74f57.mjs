const Logo = "/build/assets/logo.a170dc8a.png";
export {
  Logo as L
};
