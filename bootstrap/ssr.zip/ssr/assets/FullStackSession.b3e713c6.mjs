import React, { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { Pagination, CloseButton, Button, Container, Row as Row$1, Tabs, Tab as Tab$1 } from "react-bootstrap";
/* empty css                 */import Col from "react-bootstrap/Col";
import Nav from "react-bootstrap/Nav";
import Row from "react-bootstrap/Row";
import Tab from "react-bootstrap/Tab";
import "draft-convert";
import DOMPurify from "dompurify";
import { EyeFill, Book, PlayBtnFill, StopwatchFill } from "react-bootstrap-icons";
import "draft-js";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "reactjs-availability-calendar";
/* empty css                */import Pagination$1 from "@mui/material/Pagination";
import { u as usePagination } from "./pagination.eea5d8a8.mjs";
import Typography from "@material-ui/core/Typography";
import ListItemIcon from "@mui/material/ListItemIcon";
import { makeStyles } from "@material-ui/core/styles";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "@mui/material";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function DisplayPlan(props) {
  const {
    plans
  } = usePage().props;
  let items = [plans];
  for (let number = 1; number <= 3; number++) {
    items.push(/* @__PURE__ */ jsx(Pagination.Item, {
      children: number
    }, number));
  }
  const longEnUsFormatter = new Intl.DateTimeFormat("en-GB", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const createMarkup = (html) => {
    return {
      __html: DOMPurify.sanitize(html)
    };
  };
  const [lists, setList] = useState(false);
  const Handlelist = () => {
    setList(!lists);
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx(Tab.Container, {
      id: "left-tabs-example",
      defaultactivekey: "0",
      children: /* @__PURE__ */ jsxs(Row, {
        children: [/* @__PURE__ */ jsx("div", {
          className: "triggerList p-2 ml-1",
          onClick: Handlelist,
          children: lists ? /* @__PURE__ */ jsx(CloseButton, {}) : /* @__PURE__ */ jsx(EyeFill, {})
        }), /* @__PURE__ */ jsx(Col, {
          className: "DashboardScroll",
          sm: 4,
          children: /* @__PURE__ */ jsx("div", {
            className: lists ? "setTablist bg-white navigation-tab shadow-sm sm:rounded-lg" : "tabList",
            children: /* @__PURE__ */ jsx(Nav, {
              variant: "pills",
              className: "flex-column",
              children: plans ? plans.map((data, index) => {
                return /* @__PURE__ */ jsx(Nav.Item, {
                  children: /* @__PURE__ */ jsxs(Nav.Link, {
                    className: "ts-6",
                    eventKey: index,
                    children: [longEnUsFormatter.format(new Date(`${data.date}`)), " ", longEnUsFormatter.format(new Date(`${data.date}`)) == longEnUsFormatter.format(new Date()) && /* @__PURE__ */ jsx(Button, {
                      className: "ml-4",
                      variant: "danger",
                      children: "Today"
                    })]
                  })
                }, index);
              }) : ""
            })
          })
        }), /* @__PURE__ */ jsx(Col, {
          sm: 8,
          children: /* @__PURE__ */ jsx(Tab.Content, {
            children: plans ? plans.map((data, index) => {
              return /* @__PURE__ */ jsxs(Tab.Pane, {
                eventKey: index,
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "bg-white pt-5 pb-5 pl-4  sm:rounded-lg",
                  children: [/* @__PURE__ */ jsx(Link, {
                    href: `/study/${data.program_code}-${data.topic.split(" ").join("-")}-${data.id}`,
                    children: /* @__PURE__ */ jsxs("div", {
                      className: "flex pb-2",
                      children: [/* @__PURE__ */ jsx(Col, {
                        sm: 2,
                        lg: "1",
                        md: "3",
                        className: "pt-2",
                        children: data.sessiontype == "book" && /* @__PURE__ */ jsx(Book, {
                          style: {
                            fontSize: "30px",
                            color: "#DC4731"
                          }
                        }) || data.sessiontype == "video" && /* @__PURE__ */ jsx(PlayBtnFill, {
                          style: {
                            fontSize: "30px",
                            color: "#DC4731"
                          }
                        }) || data.sessiontype == "test" && /* @__PURE__ */ jsx(StopwatchFill, {
                          style: {
                            fontSize: "30px",
                            color: "#DC4731"
                          }
                        })
                      }), /* @__PURE__ */ jsx(Col, {
                        className: "fs-2 fw-bold pl-3 text-color-dark-blue",
                        children: data.topic
                      })]
                    })
                  }), /* @__PURE__ */ jsx("h6", {
                    className: "pt-2 text-color-baby-blue",
                    children: new Date(`${data.date}`).toLocaleTimeString()
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "pt-5 pb-5 mt-2 pl-4 bg-white sm:rounded-lg",
                  children: [/* @__PURE__ */ jsx("h4", {
                    className: "mt-2 mb-3 fw-bold",
                    children: "What you will learn"
                  }), /* @__PURE__ */ jsx("div", {
                    className: "preview",
                    dangerouslySetInnerHTML: createMarkup(data.decription)
                  })]
                }), data.assignment ? /* @__PURE__ */ jsx(Fragment, {
                  children: /* @__PURE__ */ jsx("div", {
                    className: "bg-white pt-5 pb-5 pl-4 shadow-sm sm:rounded-lg",
                    children: /* @__PURE__ */ jsxs("div", {
                      className: "preview",
                      children: [/* @__PURE__ */ jsx("h4", {
                        className: "mt-2 mb-3 fw-bold",
                        children: "Assignment"
                      }), data.assignment]
                    })
                  })
                }) : ""]
              }, index);
            }) : "Check"
          })
        })]
      })
    })
  });
}
function SubjectView(props) {
  const {
    plans
  } = usePage().props;
  let [page, setPage] = useState(1);
  const PER_PAGE = 5;
  const count = Math.ceil(plans.length / PER_PAGE);
  const _DATA = usePagination(plans, PER_PAGE);
  const handleChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  };
  let items = [plans];
  for (let number = 1; number <= 3; number++) {
    items.push(/* @__PURE__ */ jsx(Pagination$1.Item, {
      children: number
    }, number));
  }
  const longEnUsFormatter = new Intl.DateTimeFormat("en-GB", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const createMarkup = (html) => {
    return {
      __html: DOMPurify.sanitize(html)
    };
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx(Container, {
      id: "left-tabs-example",
      defaultactivekey: "first",
      children: /* @__PURE__ */ jsxs(Row, {
        children: [/* @__PURE__ */ jsx(Col, {
          max: 12,
          children: plans ? _DATA.currentData().map((data, index) => {
            return /* @__PURE__ */ jsx("div", {
              className: "bg-white pt-5 mt-2 pb-5 pl-4 shadow-sm sm:rounded-lg",
              children: /* @__PURE__ */ jsxs(Row, {
                className: "header-block",
                children: [/* @__PURE__ */ jsxs(Col, {
                  mx: "6",
                  children: [/* @__PURE__ */ jsx(Link, {
                    href: `/student/en/study/${data.program_code}/${data.topic.split(" ").join("-")}/${data.id}`,
                    children: /* @__PURE__ */ jsxs("div", {
                      className: "row pb-3",
                      children: [/* @__PURE__ */ jsx(Col, {
                        sm: 1,
                        className: "pt-2",
                        children: data.sessiontype == "book" && /* @__PURE__ */ jsx(Book, {
                          style: {
                            fontSize: "30px",
                            color: "#DC4731"
                          }
                        }) || data.sessiontype == "video" && /* @__PURE__ */ jsx(PlayBtnFill, {
                          style: {
                            fontSize: "30px",
                            color: "#DC4731"
                          }
                        })
                      }), /* @__PURE__ */ jsx(Col, {
                        className: "fs-2 fw-bold pl-0 text-color-dark-blue",
                        children: data.topic
                      })]
                    })
                  }), /* @__PURE__ */ jsx("h6", {
                    className: "pt-2 text-color-baby-blue",
                    children: longEnUsFormatter.format(new Date(`${data.date}`))
                  })]
                }), /* @__PURE__ */ jsx(Col, {
                  mx: "6",
                  children: /* @__PURE__ */ jsx("div", {
                    className: "preview",
                    dangerouslySetInnerHTML: createMarkup(data.decription)
                  })
                })]
              })
            }, data.id);
          }) : "Check"
        }), /* @__PURE__ */ jsx("div", {
          className: "flex items-center mt-4 flex-col sm:justify-center",
          children: /* @__PURE__ */ jsx(Pagination$1, {
            count,
            size: "large",
            page,
            variant: "outlined",
            shape: "circular",
            onChange: handleChange
          })
        })]
      })
    })
  });
}
const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.background.paper
  }
}));
function FullStackSession(props) {
  const [key, setKey] = useState("home");
  const {
    name,
    plans,
    program,
    progress
  } = usePage().props;
  useStyles();
  const [anchorEl1, setAnchorEl1] = React.useState(null);
  const [selectedIndex, setSelectedIndex] = React.useState(1);
  const handleClickListItem = (event) => {
    setAnchorEl1(event.currentTarget);
  };
  const handleMenuItemClick = (event, index) => {
    setSelectedIndex(index);
    setAnchorEl1(null);
  };
  const handleClose1 = () => {
    setAnchorEl1(null);
  };
  const [values, setValues] = useState({
    "search": ""
  });
  useState(false);
  const HandleChange = (e) => {
    const key2 = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key2]: value
    }));
  };
  const found = plans.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(values.search)));
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    plans: props.plans,
    errors: props.errors,
    Programs: program.map((data, index) => {
      return /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsx(Link, {
          href: `/admin/edit-program/${data.program.split(" ").join("-")}/session/${data.random}`,
          className: "text-color-white",
          children: data.program
        })
      }, index);
    }),
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 text-color-blue leading-tight",
        children: name
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-2 ",
        children: "(6 Months Program)"
      }), /* @__PURE__ */ jsxs("h6", {
        children: ["Progress ", /* @__PURE__ */ jsxs("b", {
          children: [progress, " / 26"]
        })]
      }), /* @__PURE__ */ jsx("div", {
        style: {
          width: "115px",
          borderRadius: "10px",
          border: "solid 1px gray",
          height: "6px",
          overflow: "hidden"
        },
        children: /* @__PURE__ */ jsx("div", {
          style: {
            height: "30px",
            position: "relative",
            bottom: "10px",
            width: progress * 5,
            background: "white"
          }
        })
      })]
    }),
    Search: /* @__PURE__ */ jsxs("div", {
      className: "Search-container",
      children: [/* @__PURE__ */ jsx("input", {
        onClick: handleClickListItem,
        type: "text",
        name: "search",
        value: values.search,
        onChange: HandleChange
      }), /* @__PURE__ */ jsx(Menu, {
        id: "lock-menu",
        anchorEl: anchorEl1,
        keepMounted: true,
        open: Boolean(anchorEl1),
        onClose: handleClose1,
        children: found.map((data, index) => /* @__PURE__ */ jsxs(MenuItem, {
          onClick: (event) => handleMenuItemClick(event, index),
          children: [/* @__PURE__ */ jsx(ListItemIcon, {
            children: data.sessiontype == "book" && /* @__PURE__ */ jsx(Book, {
              style: {
                fontSize: "30px",
                color: "#DC4731"
              }
            }) || data.sessiontype == "video" && /* @__PURE__ */ jsx(PlayBtnFill, {
              style: {
                fontSize: "30px",
                color: "#DC4731"
              },
              className: "pl-1"
            }) || data.sessiontype == "test" && /* @__PURE__ */ jsx(StopwatchFill, {
              style: {
                fontSize: "30px",
                color: "#DC4731"
              }
            })
          }), /* @__PURE__ */ jsx(Typography, {
            children: /* @__PURE__ */ jsx(Link, {
              href: `/student/en/study/${data.program_code}/${data.topic.split(" ").join("-")}/${data.id}`,
              children: data.topic
            })
          })]
        }, index))
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: `${name} - Courses and Sessions`
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "col",
        children: /* @__PURE__ */ jsx("div", {
          className: "overflow-hidden ",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 border-b border-gray-200",
            children: /* @__PURE__ */ jsx(Row$1, {
              children: /* @__PURE__ */ jsxs(Tabs, {
                id: "justify-tab-example",
                activeKey: key,
                onSelect: (k) => setKey(k),
                className: "mb-3 bg-white shadow-sm sm:rounded-lg pt-2 pb-2",
                justify: true,
                children: [/* @__PURE__ */ jsx(Tab$1, {
                  eventKey: "home",
                  title: "Daily Plan",
                  children: /* @__PURE__ */ jsx(DisplayPlan, {})
                }), /* @__PURE__ */ jsx(Tab$1, {
                  eventKey: "Subject",
                  title: "Subject View",
                  children: /* @__PURE__ */ jsx(SubjectView, {})
                })]
              })
            })
          })
        })
      })
    })]
  });
}
export {
  FullStackSession as default
};
