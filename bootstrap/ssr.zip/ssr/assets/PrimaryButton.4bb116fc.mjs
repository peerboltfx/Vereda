import "react";
/* empty css                 */import { j as jsx } from "../ssr.mjs";
function PrimaryButton({
  type = "submit",
  className = "",
  processing,
  children
}) {
  return /* @__PURE__ */ jsx("button", {
    type,
    className: `bg-primaries mb-5 full-width-btn sm:rounded-full pt-2 pb-2 text-color-white tracking-widest active:bg-gray-900 transition ease-in-out duration-150 ${processing && "opacity-25"} ` + className,
    disabled: processing,
    children
  });
}
export {
  PrimaryButton as P
};
