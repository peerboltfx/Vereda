import { useState } from "react";
/* empty css                 */import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, useForm, Link, Head } from "@inertiajs/inertia-react";
import { Form, Alert, Button, Modal } from "react-bootstrap";
import DOMPurify from "dompurify";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
/* empty css                               */import { Document, Page, pdfjs } from "react-pdf";
import { Inertia } from "@inertiajs/inertia";
import { a as jsxs, j as jsx, F as Fragment } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
const Coming = "/build/assets/comomg-soon.d44d3ca1.webp";
const Conference = "/build/assets/4814043.1e92c5c0.jpg";
const AnnotationLayer = "";
const TextLayer = "";
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
function Studies(props) {
  const {
    course,
    sessionLive,
    type,
    origin,
    programs,
    flash,
    links,
    compact,
    verified
  } = usePage().props;
  const [numPages, setNumPage] = useState(null);
  const {
    data,
    setData
  } = useForm({
    "answer": "",
    "question": origin.assignment || ""
  });
  const [show1, setShow1] = useState(false);
  const handleShow1 = () => setShow1(true);
  const handleClose1 = () => setShow1(false);
  const options = {
    cMapUrl: "cmpas/",
    cMapPacked: true,
    standardFontDataUrl: "standard_fonst/"
  };
  const HandleAttendance = (e) => {
    Inertia.post("/student/mark-attendance", {
      courseId: origin.id,
      courseName: origin.topic,
      batch: origin.batch
    }).then((res) => {
      alert(res);
    }).catch((err) => alert("failed to load resource"));
  };
  const longEnUsFormatter = new Intl.DateTimeFormat("en-GB", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  const createMarkup = (html) => {
    return {
      __html: DOMPurify.sanitize(html)
    };
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/assignment/submit", {
      topic_id: origin.id,
      questions: origin.assignment,
      answer: data.answer
    });
  };
  function onDocumentLoadSuccess({
    numPages: nextNumPages
  }) {
    setNumPage(nextNumPages);
  }
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    plans: props.plans,
    errors: props.errors,
    Programs: programs.map((data2, index) => {
      return /* @__PURE__ */ jsx("li", {
        children: /* @__PURE__ */ jsx(Link, {
          href: `/en/${data2.program.split(" ").join("-")}/session/${data2.random}`,
          className: "text-color-white",
          children: data2.program
        })
      }, index);
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: course
    }), links, /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "bg-white overflow-hidden shadow-sm sm:rounded-lg",
          children: origin.action == "created" ? /* @__PURE__ */ jsxs("div", {
            className: "p-6 bg-white border-b border-gray-200",
            children: [origin.sessiontype == "video" && /* @__PURE__ */ jsx(Fragment, {
              children: origin.liveSession != null ? /* @__PURE__ */ jsxs("div", {
                className: "flex items-center flex-col sm:justify-center",
                children: [/* @__PURE__ */ jsx("img", {
                  src: Conference,
                  width: "40%"
                }), sessionLive == null && /* @__PURE__ */ jsxs(Fragment, {
                  children: [/* @__PURE__ */ jsxs("h6", {
                    className: "mb-3 ",
                    children: ["Live class started at ", /* @__PURE__ */ jsxs("span", {
                      className: "fw-bold text-color-dark-blue",
                      children: [" ", new Date(`${origin.updated_at}`).toLocaleTimeString()]
                    })]
                  }), /* @__PURE__ */ jsx("div", {
                    onClick: HandleAttendance,
                    children: /* @__PURE__ */ jsx("a", {
                      className: "text-center bg-primaries pt-2 pb-2 pl-4 pr-4 text-color-white rounded-full",
                      target: "_blank",
                      href: `https://${origin.liveSession}`,
                      children: " Join class on google meet "
                    })
                  })]
                }), sessionLive != null && /* @__PURE__ */ jsxs(Fragment, {
                  children: [sessionLive.attendace == "attended" && /* @__PURE__ */ jsxs(Fragment, {
                    children: [/* @__PURE__ */ jsxs("h6", {
                      className: "mb-3 ",
                      children: ["Live class started at ", /* @__PURE__ */ jsxs("span", {
                        className: "fw-bold text-color-dark-blue",
                        children: [" ", new Date(`${origin.updated_at}`).toLocaleTimeString()]
                      })]
                    }), /* @__PURE__ */ jsx("h6", {
                      className: "fw-bold",
                      children: "Class has ended and your trainer has confirmed your attendance."
                    })]
                  }), sessionLive.attendace == "pending" && /* @__PURE__ */ jsxs("h6", {
                    className: "mb-3 text-center",
                    children: ["You joined the class @ ", /* @__PURE__ */ jsxs("span", {
                      className: "fw-bold text-color-dark-blue",
                      children: [" ", new Date(`${sessionLive.joined}`).toLocaleTimeString()]
                    }), ". ", /* @__PURE__ */ jsx("br", {}), " Once class ends, your trainer will confirm you attended the class."]
                  })]
                })]
              }) : /* @__PURE__ */ jsx("video", {
                type: "video/mp4",
                allowFullScreen: true,
                height: "100%",
                width: "100%",
                controls: true,
                autoPlay: true,
                children: /* @__PURE__ */ jsx("source", {
                  src: compact,
                  type: "video/mp4"
                })
              })
            }), origin.sessiontype == "book" && /* @__PURE__ */ jsx(Fragment, {
              children: /* @__PURE__ */ jsxs("div", {
                className: "w-100 flex flex-col p-2 items-center show_pdf",
                children: [/* @__PURE__ */ jsx("h3", {
                  className: "text-color-dark-blue fw-bold mb-4",
                  children: origin.topic
                }), /* @__PURE__ */ jsx(Document, {
                  file: compact,
                  onLoadSuccess: onDocumentLoadSuccess,
                  options,
                  children: Array.from(new Array(numPages), (el, index) => /* @__PURE__ */ jsx(Page, {
                    size: "A4",
                    pageNumber: index + 1,
                    wrap: true
                  }, `page_${index + 1}`))
                }), origin.assignment != null && /* @__PURE__ */ jsxs(Fragment, {
                  children: [/* @__PURE__ */ jsx("hr", {
                    className: "mt-5 mb-5"
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-4",
                    children: [/* @__PURE__ */ jsx("h4", {
                      children: "Solve Question"
                    }), /* @__PURE__ */ jsx("div", {
                      className: "preview mb-3",
                      dangerouslySetInnerHTML: createMarkup(origin.assignment && origin.assignment)
                    }), /* @__PURE__ */ jsxs("form", {
                      onSubmit: HandleSubmit,
                      method: "POST",
                      children: [/* @__PURE__ */ jsx(Form.Control, {
                        type: "file",
                        name: "answer",
                        onChange: (e) => setData("answer", e.target.files[0]),
                        accept: "application/pdf",
                        required: true
                      }), /* @__PURE__ */ jsx("div", {
                        className: "p-3 col-6",
                        children: /* @__PURE__ */ jsx(PrimaryButton, {
                          children: "submit answer"
                        })
                      })]
                    }), flash.message && /* @__PURE__ */ jsx("div", {
                      className: "p-3",
                      children: /* @__PURE__ */ jsxs(Alert, {
                        variant: "success",
                        children: [flash.message, /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsxs("p", {
                          children: [" Click ", /* @__PURE__ */ jsx(Link, {
                            href: "/student/my-assignments",
                            children: "here"
                          }), " to check your current and previous assignment status."]
                        })]
                      })
                    })]
                  }), " "]
                })]
              })
            }), origin.sessiontype == "test" && origin.action == "created" && /* @__PURE__ */ jsxs("div", {
              className: "bg-color-baby-blue",
              style: {
                width: "100%"
              },
              children: [/* @__PURE__ */ jsxs("div", {
                style: {
                  width: "10%",
                  marginLeft: "auto",
                  marginRight: "auto",
                  paddingTop: "10%",
                  paddingBottom: "10%"
                },
                children: [/* @__PURE__ */ jsx(Button, {
                  variant: "primary",
                  onClick: handleShow1,
                  children: "start quiz"
                }), /* @__PURE__ */ jsxs(Modal, {
                  show: show1,
                  onHide: handleClose1,
                  backdrop: "static",
                  keyboard: false,
                  size: "md",
                  centered: true,
                  children: [/* @__PURE__ */ jsx(Modal.Header, {
                    closeButton: true,
                    children: /* @__PURE__ */ jsx("b", {
                      children: "What you need to know about this quiz"
                    })
                  }), /* @__PURE__ */ jsx(Modal.Body, {
                    children: /* @__PURE__ */ jsxs("ul", {
                      children: [/* @__PURE__ */ jsx("li", {
                        children: "Each question of this quiz is automated to skip to the next question if not answered with one minute."
                      }), /* @__PURE__ */ jsx("li", {
                        children: "We do not expect you to cheat, therefore the system will automatically save your result if you close the quiz page, even if you have answered any question."
                      }), /* @__PURE__ */ jsx("li", {
                        children: "We expect your score to be average / 100 of or higher than the average inorder to pass the quiz"
                      }), /* @__PURE__ */ jsx("li", {
                        children: "Fortunately if you fail the quiz, we will reschedule the quiz in two weeks, for you to study thoroughly."
                      })]
                    })
                  }), /* @__PURE__ */ jsxs(Modal.Footer, {
                    children: [/* @__PURE__ */ jsx("a", {
                      target: "_blank",
                      href: `/en/quiz/student/${origin.id}/${origin.topic.split(" ").join("-")}`,
                      children: /* @__PURE__ */ jsx(Button, {
                        variant: "dark",
                        onClick: handleClose1,
                        children: "Continue"
                      })
                    }), " ", /* @__PURE__ */ jsx(Button, {
                      onClick: handleClose1,
                      variant: "danger",
                      children: "cancel"
                    })]
                  })]
                })]
              }), flash.error && /* @__PURE__ */ jsx(Alert, {
                variant: "primary",
                children: flash.error
              })]
            })]
          }) : /* @__PURE__ */ jsxs("div", {
            className: "p-6 bg-white border-b border-gray-200",
            children: [/* @__PURE__ */ jsx("div", {
              className: "coming",
              children: /* @__PURE__ */ jsx("img", {
                src: Coming
              })
            }), /* @__PURE__ */ jsxs("h6", {
              className: "fw-bold text-color-gray text-center",
              children: ["  Coming up on ", longEnUsFormatter.format(new Date(`${origin.date}`))]
            })]
          })
        })
      })
    })]
  });
}
export {
  Studies as default
};
