import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Link, Head } from "@inertiajs/inertia-react";
import { Row, Col, Table } from "react-bootstrap";
/* empty css                 */import "@inertiajs/inertia";
import { Person } from "react-bootstrap-icons";
import Pagination from "@mui/material/Pagination";
import { u as usePagination } from "./pagination.eea5d8a8.mjs";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Users(props) {
  let [page, setPage] = useState(1);
  const PER_PAGE = 10;
  const {
    Using
  } = usePage().props;
  const count = Math.ceil(Using.length / PER_PAGE);
  const _DATA = usePagination(Using, PER_PAGE);
  const handleChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  };
  const [values, setValues] = useState({
    "amount": "",
    "search": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const found = Using.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(values.search)));
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Admin Page / Users"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Users Table"
        })]
      }),
      childs: /* @__PURE__ */ jsx(Fragment, {}),
      Search: /* @__PURE__ */ jsxs("div", {
        className: "Search-container",
        children: [/* @__PURE__ */ jsx("input", {
          onClick: HandleShow,
          type: "text",
          name: "search",
          value: values.search,
          onChange: HandleChange
        }), /* @__PURE__ */ jsxs("div", {
          onBlur: () => setShow(false),
          tabIndex: "0",
          style: {
            height: "400px",
            overflowY: "scroll"
          },
          className: show ? "Searched bg-white active p-2" : "Searched",
          children: [/* @__PURE__ */ jsx("h6", {
            className: "fw-bold text-color-dark-blue text-center",
            children: "Search Course"
          }), found.map((data, index) => {
            return /* @__PURE__ */ jsx("div", {
              className: "bg-white pt-2 mt-1 pb-2 pl-4 shadow-sm sm:rounded-lg",
              children: /* @__PURE__ */ jsx(Row, {
                children: /* @__PURE__ */ jsx(Col, {
                  mx: "6",
                  children: /* @__PURE__ */ jsx(Link, {
                    href: `/edit-users/${data.id}`,
                    className: "text-color-dark-blue",
                    children: /* @__PURE__ */ jsxs("div", {
                      className: "flex pb-3",
                      children: [/* @__PURE__ */ jsx(Col, {
                        md: "2",
                        className: "pt-0 ",
                        children: /* @__PURE__ */ jsx(Person, {
                          style: {
                            fontSize: "30px",
                            color: "#DC4731"
                          },
                          className: "pl-1"
                        })
                      }), /* @__PURE__ */ jsx(Col, {
                        md: "10",
                        className: "fs-5 fw-bold pl-0 ml-4 text-color-dark-blue",
                        children: data.name
                      })]
                    })
                  })
                })
              })
            }, index);
          })]
        })]
      }),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Full Stack Developement"
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsx("div", {
            className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
            children: /* @__PURE__ */ jsxs("div", {
              style: {
                overflowY: "scroll"
              },
              className: "p-6 border-b border-gray-200",
              children: [/* @__PURE__ */ jsxs(Table, {
                striped: true,
                bordered: true,
                hover: true,
                children: [/* @__PURE__ */ jsx("thead", {
                  children: /* @__PURE__ */ jsxs("tr", {
                    children: [/* @__PURE__ */ jsx("th", {
                      children: "#"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "name"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "email"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "phone"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "role"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "discount"
                    }), /* @__PURE__ */ jsx("th", {
                      children: "action"
                    })]
                  })
                }), /* @__PURE__ */ jsx("tbody", {
                  children: _DATA.currentData().map((data, index) => {
                    return /* @__PURE__ */ jsxs("tr", {
                      children: [/* @__PURE__ */ jsx("td", {
                        children: index
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.name
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.email
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.phone
                      }), /* @__PURE__ */ jsx("td", {
                        children: data.role
                      }), /* @__PURE__ */ jsxs("td", {
                        children: [data.code, " for ", data.discount]
                      }), /* @__PURE__ */ jsx("td", {
                        children: /* @__PURE__ */ jsx(Link, {
                          href: `/edit-users/${data.id}`,
                          children: "edit"
                        })
                      })]
                    }, index);
                  })
                })]
              }), /* @__PURE__ */ jsx("div", {
                className: "flex items-center flex-col sm:justify-center",
                children: /* @__PURE__ */ jsx(Pagination, {
                  count,
                  size: "large",
                  page,
                  variant: "outlined",
                  shape: "circular",
                  onChange: handleChange
                })
              })]
            })
          })
        })
      })]
    })
  });
}
export {
  Users as default
};
