import { usePage } from "@inertiajs/inertia-react";
import { a as jsxs, j as jsx, F as Fragment } from "../ssr.mjs";
import { i as img4, a as img3$1 } from "./Hermant-kumar.bd7eb8f5.mjs";
import { useState } from "react";
import Carousel from "react-bootstrap/Carousel";
import { L as Logo } from "./logo.d6c74f57.mjs";
import { Container } from "react-bootstrap";
import { O as OffCanvasExample } from "./DropBottom.c156e3a4.mjs";
import Form from "react-bootstrap/Form";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
const img1 = "/build/assets/01.221ed94d.jpg";
const img2 = "/build/assets/02.ea197206.jpg";
const img3 = "/build/assets/03.8429bc01.jpg";
const Himanshu = "/build/assets/Pictures-2.da20ef07.png";
const kunal = "/build/assets/Kunal-Kishore.76ad1633.webp";
const Kingsley = "/build/assets/kingsley.9a9b51f8.webp";
const Vishal = "/build/assets/vishal.36eea9e5.webp";
const Sameer = "/build/assets/sameer.020ef944.png";
function ControlledCarousel(props) {
  const {
    Item1,
    item2,
    item3
  } = props;
  const [index, setIndex] = useState(0);
  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };
  return /* @__PURE__ */ jsxs(Carousel, {
    activeIndex: index,
    onSelect: handleSelect,
    children: [/* @__PURE__ */ jsx(Carousel.Item, {
      className: "flex",
      children: Item1
    }), /* @__PURE__ */ jsx(Carousel.Item, {
      className: "flex",
      children: item2
    })]
  });
}
const subTitle = "World-class Instructors";
const title = "Our top-notch team helps you learn Programming, not just Coding!";
const instructorList = [{
  imgUrl: img4,
  imgAlt: "instructor vereda vereda",
  name: "Hermant Kumar",
  degi: "Flutter Developer 6+ years experience",
  courseCount: "08 courses",
  studentAnroll: "30 students",
  iconName: "icofont-linkedin",
  className: "linkedin",
  linkedInAddress: "https://www.linkedin.com/in/hermant-kumar-sedhanshu-42142390"
}, {
  imgUrl: img3$1,
  imgAlt: "instructor vereda vereda",
  name: "Ujjwal Verma",
  degi: "Lead Software Developer IIT Kharagpur",
  courseCount: "08 courses",
  studentAnroll: "30 students",
  iconName: "icofont-linkedin",
  className: "linkedin",
  linkedInAddress: "https://www.linkedin.com/in/ujjwalverma007"
}, {
  imgUrl: kunal,
  imgAlt: "instructor vereda vereda",
  name: "Kunal Kishore",
  degi: "11+ years Experience in Human Resources",
  courseCount: "08 courses",
  studentAnroll: "30 students",
  iconName: "icofont-linkedin",
  className: "linkedin",
  linkedInAddress: "#"
}, {
  imgUrl: Vishal,
  imgAlt: "instructor vereda vereda",
  name: "Vishal Pankaj",
  degi: "Technical Domain Expert and Skilled Instructor",
  courseCount: "08 courses",
  studentAnroll: "30 students",
  iconName: "icofont-linkedin",
  className: "linkedin",
  linkedInAddress: "https://www.linkedin.com/in/vishal-pankaj-30503a103"
}];
const Headteam = [{
  imgUrl: Himanshu,
  imgAlt: "Founder Vereda.co.in",
  name: "Himanshu Kumar",
  degi: "Founder, Flutter Developer 7+ years experience ",
  courseCount: "08 courses",
  studentAnroll: "30 students",
  iconName: "icofont-linkedin",
  className: "linkedin",
  linkedInAddress: "#"
}, {
  imgUrl: Kingsley,
  imgAlt: "Developer",
  name: "Kingsley Orji",
  degi: "IT Staff & Full Stack Developer 5+ Years Experience",
  courseCount: "08 courses",
  studentAnroll: "30 students",
  iconName: "icofont-linkedin",
  className: "linkedin",
  linkedInAddress: "#"
}, {
  imgUrl: Sameer,
  imgAlt: "instructor vereda vereda",
  name: "Sameer Ansari",
  degi: "Front-end Developer & UI/UX Designer",
  courseCount: "08 courses",
  studentAnroll: "30 students",
  iconName: "icofont-linkedin",
  className: "linkedin",
  linkedInAddress: "https://www.linkedin.com/in/speaktosameer/"
}];
const Instructor = () => {
  return /* @__PURE__ */ jsx("div", {
    className: "instructor-section padding-tb section-bg",
    children: /* @__PURE__ */ jsxs("div", {
      className: "container",
      children: [/* @__PURE__ */ jsxs("div", {
        className: "section-header text-center",
        children: [/* @__PURE__ */ jsx("span", {
          className: "subtitle",
          children: subTitle
        }), /* @__PURE__ */ jsx("h2", {
          className: "title",
          children: title
        })]
      }), /* @__PURE__ */ jsx("div", {
        className: "section-wrapper",
        children: /* @__PURE__ */ jsx("div", {
          className: "",
          children: /* @__PURE__ */ jsx(ControlledCarousel, {
            item2: /* @__PURE__ */ jsx("div", {
              className: "row g-4 justify-content-center row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4",
              children: instructorList.map((val, i) => /* @__PURE__ */ jsx("div", {
                className: "col",
                children: /* @__PURE__ */ jsx("div", {
                  className: "instructor-item",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "instructor-inner",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "instructor-thumb  items-center",
                      children: /* @__PURE__ */ jsx("img", {
                        src: `${val.imgUrl}`,
                        style: {
                          marginLeft: "auto",
                          marginRight: "auto"
                        },
                        width: "150px",
                        alt: `${val.imgAlt}`
                      })
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "instructor-content",
                      children: [/* @__PURE__ */ jsx("h4", {
                        children: val.name
                      }), /* @__PURE__ */ jsx("p", {
                        children: val.degi
                      }), /* @__PURE__ */ jsxs("a", {
                        href: val.linkedInAddress,
                        target: "_blank",
                        className: val.className,
                        children: [" ", /* @__PURE__ */ jsx("i", {
                          className: val.iconName
                        })]
                      })]
                    })]
                  })
                })
              }, i))
            }),
            Item1: /* @__PURE__ */ jsx("div", {
              className: "row g-4 justify-content-center row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4",
              children: Headteam.map((val, i) => /* @__PURE__ */ jsx("div", {
                className: "col",
                children: /* @__PURE__ */ jsx("div", {
                  className: "instructor-item",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "instructor-inner",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "instructor-thumb  items-center",
                      children: /* @__PURE__ */ jsx("img", {
                        src: `${val.imgUrl}`,
                        style: {
                          marginLeft: "auto",
                          marginRight: "auto"
                        },
                        width: "150px",
                        alt: `${val.imgAlt}`
                      })
                    }), /* @__PURE__ */ jsxs("div", {
                      className: "instructor-content mt-2",
                      children: [/* @__PURE__ */ jsx("h4", {
                        children: val.name
                      }), /* @__PURE__ */ jsx("p", {
                        children: val.degi
                      }), /* @__PURE__ */ jsxs("a", {
                        href: val.linkedInAddress,
                        target: "_blank",
                        className: val.className,
                        children: [" ", /* @__PURE__ */ jsx("i", {
                          className: val.iconName
                        })]
                      })]
                    })]
                  })
                })
              }, i))
            })
          })
        })
      })]
    })
  });
};
const mentorweb = "/build/assets/mentor-community-companies.6113b666.png";
const mentorMobile = "/build/assets/mentor-community-mobile.81e7a44b.png";
function Mentor() {
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const {
    flash
  } = usePage().props;
  const [values, setValue] = useState({
    "name": "",
    "email": "",
    "phone": "",
    "country": "",
    "state": "",
    "occupation": "",
    "studies": "",
    "language": ""
  });
  const HandleChange = (e) => {
    const key = e.target.id;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/request/call", values);
  };
  const handleClose = () => setShow(false);
  return /* @__PURE__ */ jsxs("section", {
    className: "section-9",
    children: [/* @__PURE__ */ jsxs("div", {
      className: "container mt-5",
      children: [/* @__PURE__ */ jsxs("div", {
        className: "section-header text-center",
        children: [/* @__PURE__ */ jsx("span", {
          className: "subtitle",
          children: "Our mentor associates"
        }), /* @__PURE__ */ jsx("h2", {
          className: "title",
          children: "Mentor Community"
        })]
      }), /* @__PURE__ */ jsxs("div", {
        className: "recognition  bg-color-light-gray",
        children: [/* @__PURE__ */ jsx("img", {
          className: "alumni-web",
          src: mentorweb,
          alt: mentorweb
        }), /* @__PURE__ */ jsx("img", {
          className: "alumni-mobile",
          src: mentorMobile,
          alt: mentorMobile
        })]
      })]
    }), /* @__PURE__ */ jsxs("div", {
      className: "call mt-4 mb-4",
      children: [" ", /* @__PURE__ */ jsx("button", {
        onClick: handleShow,
        className: "full-size-btn capitalize full-width-btn",
        children: "request call back"
      })]
    }), /* @__PURE__ */ jsx(OffCanvasExample, {
      show,
      onHide: handleClose,
      title: /* @__PURE__ */ jsx(Fragment, {
        children: /* @__PURE__ */ jsxs("div", {
          className: "block",
          children: [/* @__PURE__ */ jsx("h4", {
            children: /* @__PURE__ */ jsx("a", {
              href: "/",
              className: "logo-anchor item-center",
              children: /* @__PURE__ */ jsx("img", {
                src: Logo,
                width: "100px",
                alt: Logo,
                srcSet: ""
              })
            })
          }), /* @__PURE__ */ jsx("h3", {
            className: "fw-bold",
            children: "Talk to Our Expert"
          })]
        })
      }),
      children: /* @__PURE__ */ jsx(Fragment, {
        children: /* @__PURE__ */ jsx(Container, {
          children: /* @__PURE__ */ jsxs("form", {
            onSubmit: handleSubmit,
            children: [/* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              onChange: HandleChange,
              value: values.name,
              id: "name",
              required: true,
              placeholder: "Name",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "email",
              onChange: HandleChange,
              value: values.email,
              id: "email",
              required: true,
              placeholder: "abcd@example.com ",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "number",
              id: "phone",
              value: values.phone,
              onChange: HandleChange,
              required: true,
              placeholder: "+9 9123 567 98",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              value: values.country,
              id: "country",
              onChange: HandleChange,
              required: true,
              placeholder: "Country",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "occupation",
              value: values.occupation,
              onChange: HandleChange,
              required: true,
              placeholder: "Occupation",
              className: "mt-2"
            }), /* @__PURE__ */ jsx(Form.Control, {
              type: "text",
              id: "state",
              value: values.state,
              onChange: HandleChange,
              required: true,
              placeholder: "State",
              className: "mt-2"
            }), /* @__PURE__ */ jsxs(Form.Select, {
              onChange: HandleChange,
              vlaue: values.language,
              id: "language",
              required: true,
              className: "mt-2",
              children: [/* @__PURE__ */ jsx("option", {
                children: "select Language"
              }), /* @__PURE__ */ jsx("option", {
                value: "English",
                children: "English"
              }), /* @__PURE__ */ jsx("option", {
                value: "Hindi",
                children: "Hindi"
              })]
            }), /* @__PURE__ */ jsx(PrimaryButton, {
              className: "mt-5",
              children: "submit"
            }), flash.message && /* @__PURE__ */ jsx("div", {
              className: "alert alert-success",
              children: "Request sent successfully"
            })]
          })
        })
      })
    })]
  });
}
export {
  Instructor as I,
  Mentor as M,
  img2 as a,
  img3 as b,
  img1 as i
};
