import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
import { Col, Card, Alert } from "react-bootstrap";
/* empty css                 */import { QuestionCircle, CheckCircleFill } from "react-bootstrap-icons";
import { Inertia } from "@inertiajs/inertia";
import "react-bootstrap/Pagination";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Plantable(props) {
  const {
    assignments,
    flash
  } = usePage().props;
  const [values, setValues] = useState({
    "score": "",
    "identity": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValues((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Admin Page / Moderator"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "Moderator Table"
        })]
      }),
      childs: /* @__PURE__ */ jsx(Fragment, {}),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Full Stack Developement"
      }), /* @__PURE__ */ jsx("div", {
        className: "py-12",
        children: /* @__PURE__ */ jsx("div", {
          className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsx("div", {
            className: "overflow-hidden p-2 shadow-sm ",
            children: assignments.map((data, index) => {
              return /* @__PURE__ */ jsx(Col, {
                md: "6",
                sm: "12",
                lg: "12",
                children: /* @__PURE__ */ jsxs(Card, {
                  className: "sm:rounded-lg bg-white",
                  children: [/* @__PURE__ */ jsxs(Card.Title, {
                    className: "p-2 capitalize",
                    children: [" ", data.topic]
                  }), /* @__PURE__ */ jsxs(Card.Header, {
                    className: "flex",
                    children: [/* @__PURE__ */ jsx("span", {
                      children: /* @__PURE__ */ jsx(QuestionCircle, {
                        className: "text-color-dark-blue mt-1 mr-2"
                      })
                    }), " ", data.question]
                  }), /* @__PURE__ */ jsxs(Card.Body, {
                    className: "flex",
                    children: [/* @__PURE__ */ jsx("span", {
                      children: /* @__PURE__ */ jsx(CheckCircleFill, {
                        className: "text-color-dark-blue mt-1 mr-2 fw-bold"
                      })
                    }), /* @__PURE__ */ jsx("iframe", {
                      style: {
                        width: "100%"
                      },
                      height: "600",
                      target: "_blank",
                      src: `../storage/pdf/${data.answer}`
                    })]
                  }), /* @__PURE__ */ jsx(Card.Footer, {
                    children: /* @__PURE__ */ jsxs("form", {
                      onSubmit: (e) => {
                        e.preventDefault();
                        Inertia.post(`/Moderator/assignment-update-${data.id}`, values);
                      },
                      className: "flex",
                      children: [/* @__PURE__ */ jsx("input", {
                        type: "number",
                        placeholder: "score / 10",
                        name: "score",
                        onChange: HandleChange,
                        className: "w-full m-2"
                      }), /* @__PURE__ */ jsx("input", {
                        type: "submit",
                        value: "submit",
                        name: "identity",
                        className: "bg-primaries w-full text-white m-2",
                        placeholder: "submit"
                      })]
                    })
                  }), flash.message && /* @__PURE__ */ jsx(Alert, {
                    variant: "success",
                    children: flash.message
                  })]
                })
              }, index);
            })
          })
        })
      })]
    })
  });
}
export {
  Plantable as default
};
