import "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
/* empty css                 */import Divider from "@mui/material/Divider";
import Avatar from "@mui/material/Avatar";
import { Col } from "react-bootstrap";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function MyStudent(props) {
  const {
    students
  } = usePage().props;
  console.log(students);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Authenticated, {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsxs(Fragment, {
        children: [/* @__PURE__ */ jsx("h2", {
          className: "font-semibold ts-1 leading-tight",
          children: "Moderator Page / Class"
        }), /* @__PURE__ */ jsx("h3", {
          className: "fs-4 text-color-blue",
          children: "My CLass"
        })]
      }),
      childs: /* @__PURE__ */ jsx(Fragment, {}),
      children: [/* @__PURE__ */ jsx(Head, {
        title: "Full Stack Developement"
      }), /* @__PURE__ */ jsx("div", {
        className: "",
        children: /* @__PURE__ */ jsx("div", {
          className: " mx-auto sm:px-6 lg:px-8",
          children: /* @__PURE__ */ jsx("div", {
            className: "overflow-hidden ",
            children: /* @__PURE__ */ jsx("div", {
              className: "row mb-4 ",
              children: students.map((student, index) => {
                return /* @__PURE__ */ jsxs(Col, {
                  className: "flex shadow-sm rounded-sm bg-white  items-center flex-col",
                  md: "3",
                  lg: "4",
                  sm: "12",
                  children: [/* @__PURE__ */ jsx("div", {
                    className: "pt-3 pb-3",
                    children: /* @__PURE__ */ jsx(Avatar, {
                      sx: {
                        width: 100,
                        height: 100
                      },
                      alt: student.user.name,
                      src: `../../../storage/jpg/${student.user.avatar}`
                    })
                  }), /* @__PURE__ */ jsx("h3", {
                    className: "fw-bold fs-4 text-color-dark-blue capitalize  mb-2",
                    children: student.user.name
                  }), /* @__PURE__ */ jsx(Divider, {}), /* @__PURE__ */ jsxs("div", {
                    children: [/* @__PURE__ */ jsx("h6", {
                      children: student.program
                    }), /* @__PURE__ */ jsxs("p", {
                      className: "text-center",
                      children: ["started on -- ", /* @__PURE__ */ jsx("b", {
                        className: "text-color-dark-blue",
                        children: " " + new Date(`${student.created_at}`).toLocaleDateString()
                      })]
                    })]
                  })]
                }, index);
              })
            })
          })
        })
      })]
    })
  });
}
export {
  MyStudent as default
};
