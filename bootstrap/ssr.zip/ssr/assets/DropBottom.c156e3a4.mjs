import { useState } from "react";
import "react-bootstrap/Button";
import Offcanvas from "react-bootstrap/Offcanvas";
import { j as jsx, F as Fragment, a as jsxs } from "../ssr.mjs";
function OffCanvasExample({
  name,
  ...props
}) {
  useState(false);
  const {
    title,
    children
  } = props;
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs(Offcanvas, {
      ...props,
      children: [/* @__PURE__ */ jsx(Offcanvas.Header, {
        closeButton: true,
        children: /* @__PURE__ */ jsx(Offcanvas.Title, {
          children: title
        })
      }), /* @__PURE__ */ jsx(Offcanvas.Body, {
        children
      })]
    })
  });
}
export {
  OffCanvasExample as O
};
