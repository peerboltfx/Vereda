import "react";
/* empty css                 */import "@inertiajs/inertia-react";
import { j as jsx } from "../ssr.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function RouterDom(props) {
  const {
    children
  } = props;
  return /* @__PURE__ */ jsx("div", {
    children: /* @__PURE__ */ jsx("div", {
      children
    })
  });
}
export {
  RouterDom
};
