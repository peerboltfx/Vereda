import { useState } from "react";
import { usePage } from "@inertiajs/inertia-react";
/* empty css                               */import { Inertia } from "@inertiajs/inertia";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { CheckCircleFill } from "react-bootstrap-icons";
import { Alert } from "react-bootstrap";
import { j as jsx, a as jsxs, F as Fragment } from "../ssr.mjs";
/* empty css                 */import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function CreateApplication(props) {
  const {
    questions,
    flash
  } = usePage().props;
  const [score, setScore] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [countdown, setCountDown] = useState(60);
  const [startQuiz, setStartQuiz] = useState(false);
  const [failed, setFailed] = useState([]);
  const result = 100 / questions.length * score;
  const HandleNext = () => {
    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setStartQuiz(true);
    }
  };
  const HandleClose = (e) => {
    e.preventDefault();
    Inertia.post("/quiz/save", {
      "data": result,
      "identity": questions[0].course
    });
    if (flash.message) {
      window.close();
    }
  };
  window.history.back = () => {
    Inertia.post("/quiz/save", {
      "data": result,
      "identity": questions[0].course
    });
  };
  window.onbeforeunload = (event) => {
    event.preventDefault;
    Inertia.post("/quiz/save", {
      "data": result,
      "identity": questions[0].course
    });
  };
  const x = setTimeout(() => {
    setCountDown(countdown - 1);
    if (countdown - 1 < 1) {
      HandleNext();
      setCountDown(60);
    }
  }, 1e3);
  if (currentQuestion == questions.length - 1 && countdown - 1 < 1) {
    clearTimeout(x);
  }
  return /* @__PURE__ */ jsx("div", {
    className: "py-12",
    children: /* @__PURE__ */ jsx("div", {
      className: "max-w-3xl mx-auto sm:px-6 lg:px-8",
      children: /* @__PURE__ */ jsx("div", {
        className: "bg-white overflow-hidden shadow-sm sm:rounded-lg",
        children: startQuiz ? /* @__PURE__ */ jsx("div", {
          children: /* @__PURE__ */ jsx("div", {
            className: "text-center ",
            children: 100 / questions.length * score < 50 ? /* @__PURE__ */ jsxs(Fragment, {
              children: [/* @__PURE__ */ jsx("h5", {
                className: "mb-5",
                children: "You didnt pass this Quiz, You failed the following"
              }), /* @__PURE__ */ jsxs("b", {
                children: [" ", failed.map((data) => {
                  return /* @__PURE__ */ jsxs(Fragment, {
                    children: [/* @__PURE__ */ jsx("h4", {
                      children: data.question
                    }), /* @__PURE__ */ jsx("ul", {
                      children: /* @__PURE__ */ jsxs("li", {
                        children: [data.answer, " (wrong Answer)"]
                      })
                    }), " "]
                  });
                })]
              }), /* @__PURE__ */ jsx("form", {
                onSubmit: HandleClose,
                method: "POST",
                children: /* @__PURE__ */ jsx(PrimaryButton, {
                  className: "ts-6",
                  children: "Next"
                })
              }), flash.message && /* @__PURE__ */ jsx(Alert, {
                variant: "success",
                children: flash.message
              }), " "]
            }) : /* @__PURE__ */ jsxs("div", {
              className: "p-3",
              children: [/* @__PURE__ */ jsx("h3", {
                className: "text-center  pt-3",
                children: "Quiz Passed"
              }), /* @__PURE__ */ jsx("h2", {
                className: "text-center item-center w-100 pt-2",
                children: /* @__PURE__ */ jsx(CheckCircleFill, {
                  className: "text-center",
                  style: {
                    color: "green",
                    marginLeft: "auto",
                    marginRight: "auto"
                  }
                })
              }), /* @__PURE__ */ jsxs("h3", {
                className: "fs-5 mt-4 mb-3",
                children: ["Score ", /* @__PURE__ */ jsx("b", {
                  children: 100 / questions.length * score
                })]
              }), /* @__PURE__ */ jsxs("div", {
                style: {
                  width: "50%",
                  marginLeft: "auto",
                  marginRight: "auto"
                },
                children: [/* @__PURE__ */ jsx("form", {
                  method: "POST",
                  onSubmit: HandleClose,
                  children: /* @__PURE__ */ jsx(PrimaryButton, {
                    className: "ts-6",
                    children: "Next"
                  })
                }), flash.message && /* @__PURE__ */ jsx(Alert, {
                  variant: "success",
                  children: flash.message
                })]
              })]
            })
          })
        }) : /* @__PURE__ */ jsxs("div", {
          className: "p-6 bg-white border-b border-gray-200",
          children: [/* @__PURE__ */ jsx("h3", {
            className: "mb-4 pb-5 text-center",
            children: questions[currentQuestion].question
          }), /* @__PURE__ */ jsxs("ul", {
            style: {
              display: "block"
            },
            children: [/* @__PURE__ */ jsxs("li", {
              style: {
                borderRadius: 20
              },
              className: "mb-3 bg-primaries text-color-white p-4 text-center",
              onClick: HandleNext,
              children: [/* @__PURE__ */ jsx("button", {
                style: {
                  width: "100%",
                  height: "100%"
                },
                onClick: () => questions[currentQuestion].answer == "option1" ? setScore(score + 1) : setFailed((current) => [...current, {
                  answer: `${questions[currentQuestion].option1}`,
                  question: questions[currentQuestion].question
                }]),
                children: questions[currentQuestion].option1
              }), " "]
            }), /* @__PURE__ */ jsx("li", {
              style: {
                borderRadius: 20
              },
              className: "mb-3 bg-primaries text-color-white p-4 text-center",
              onClick: HandleNext,
              children: /* @__PURE__ */ jsxs("button", {
                style: {
                  width: "100%",
                  height: "100%"
                },
                onClick: () => questions[currentQuestion].answer == "option2" ? setScore(score + 1) : setFailed((current) => [...current, {
                  answer: `${questions[currentQuestion].option2}`,
                  question: questions[currentQuestion].question
                }]),
                children: [questions[currentQuestion].option2, " "]
              })
            }), /* @__PURE__ */ jsx("li", {
              style: {
                borderRadius: 20
              },
              className: "mb-3  bg-primaries text-color-white p-4 text-center",
              onClick: HandleNext,
              children: /* @__PURE__ */ jsxs("button", {
                style: {
                  width: "100%",
                  height: "100%"
                },
                onClick: () => questions[currentQuestion].answer == "option3" ? setScore(score + 1) : setFailed((current) => [...current, {
                  answer: `${questions[currentQuestion].option3}`,
                  question: questions[currentQuestion].question
                }]),
                children: [questions[currentQuestion].option3, " "]
              })
            }), /* @__PURE__ */ jsx("li", {
              style: {
                borderRadius: 20
              },
              className: "mb-3  bg-primaries text-color-white p-4 text-center",
              onClick: HandleNext,
              children: /* @__PURE__ */ jsx("button", {
                style: {
                  width: "100%",
                  height: "100%"
                },
                onClick: () => questions[currentQuestion].answer == "option4" ? setScore(score + 1) : setFailed((current) => [...current, {
                  answer: `${questions[currentQuestion].option4}`,
                  question: questions[currentQuestion].question
                }]),
                children: questions[currentQuestion].option4
              })
            }), /* @__PURE__ */ jsx("button", {
              className: "mt-3",
              onClick: HandleNext,
              children: /* @__PURE__ */ jsxs("b", {
                children: ["Question : ", currentQuestion + 1]
              })
            }), /* @__PURE__ */ jsx("div", {
              className: " bg-primaries mt-2",
              style: {
                width: `${countdown * 10}px`,
                height: 10,
                transition: "1s"
              }
            })]
          })]
        })
      })
    })
  });
}
export {
  CreateApplication as default
};
