import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
/* empty css                               *//* empty css                */import { Form, Row, Col, Container } from "react-bootstrap";
import { Inertia } from "@inertiajs/inertia";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap/Nav";
import "@mui/material";
/* empty css                 */import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function CreateApplication(props) {
  const {
    auth,
    programs
  } = usePage().props;
  const [values, setValue] = useState({
    "firstname": "",
    "lastname": "",
    "country": "",
    "gender": "",
    "birthDate": "",
    "program": "",
    "desire": "",
    "address": "",
    "parentName": "",
    "state": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/profile/application-submit", values);
  };
  const countries = ["United States", "Canada", "Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and/or Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Cook Islands", "Costa Rica", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecudaor", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France, Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Ivory Coast", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kosovo", "Kuwait", "Kyrgyzstan", "Lao People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfork Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia South Sandwich Islands", "South Sudan", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbarn and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States minor outlying islands", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City State", "Venezuela", "Vietnam", "Virigan Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zaire", "Zambia", "Zimbabwe"];
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsxs("h2", {
        className: "font-semibold leading-tight",
        children: ["Welcome ", auth.user.name]
      }), /* @__PURE__ */ jsxs("h3", {
        className: "fs-6 pt-5 text-dark ",
        children: ["Congratulations !,", /* @__PURE__ */ jsx("br", {}), " You have successfully registered your account. Before getting started, we assume you have made neccessary research about", /* @__PURE__ */ jsxs("b", {
          children: [" ", "Vereda.co.in"]
        }), ", who we are, what we offer and benefits of Learning from us. ", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "Before you continue we would like you to properly introduce yourself formally to us, and give us a brief discussion of what you would desire to achieve with us as you are about to advance to the training session.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("b", {
          children: "Fill in the form below to continue"
        })]
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Profile Form"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-3xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "bg-white overflow-hidden shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 bg-white border-b border-gray-200",
            children: /* @__PURE__ */ jsxs("form", {
              onSubmit: HandleSubmit,
              children: [/* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  className: "fw-bold",
                  children: "First name *"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "text",
                  name: "firstname",
                  value: values.firstname,
                  onChange: HandleChange
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  className: "fw-bold",
                  children: "Last name *"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  type: "text",
                  name: "lastname",
                  value: values.lastname,
                  onChange: HandleChange
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  className: "fw-bold",
                  children: "Country *"
                }), /* @__PURE__ */ jsxs(Form.Select, {
                  value: values.country,
                  required: true,
                  name: "country",
                  onChange: HandleChange,
                  children: [/* @__PURE__ */ jsx("option", {
                    children: "select country"
                  }), countries.map((info, index) => {
                    return /* @__PURE__ */ jsx("option", {
                      value: info,
                      children: info
                    }, index);
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  className: "fw-bold",
                  children: "Address *"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  name: "address",
                  as: "textarea",
                  required: true,
                  value: values.address,
                  onChange: HandleChange
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  className: "fw-bold",
                  children: "Gender *"
                }), /* @__PURE__ */ jsxs(Form.Select, {
                  value: values.gender,
                  required: true,
                  name: "gender",
                  onChange: HandleChange,
                  children: [/* @__PURE__ */ jsx("option", {
                    children: "Select Gender"
                  }), /* @__PURE__ */ jsx("option", {
                    value: "male",
                    children: "Male"
                  }), /* @__PURE__ */ jsx("option", {
                    value: "female",
                    children: "Female"
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  className: "fw-bold",
                  children: "Intended program *"
                }), /* @__PURE__ */ jsxs(Form.Select, {
                  required: true,
                  value: values.program,
                  name: "program",
                  onChange: HandleChange,
                  children: [/* @__PURE__ */ jsx("option", {
                    children: "select program"
                  }), programs.map((data, index) => {
                    return /* @__PURE__ */ jsx("option", {
                      value: data.program,
                      children: data.program
                    }, index);
                  })]
                })]
              }), /* @__PURE__ */ jsxs(Row, {
                children: [/* @__PURE__ */ jsxs(Col, {
                  md: "6",
                  sm: "6",
                  lg: "6",
                  className: "mt-4",
                  children: [/* @__PURE__ */ jsx(Form.Label, {
                    className: "fw-bold",
                    children: "Date of birth *"
                  }), /* @__PURE__ */ jsx(Form.Control, {
                    type: "date",
                    required: true,
                    name: "birthDate",
                    value: values.birthDate,
                    onChange: HandleChange
                  })]
                }), /* @__PURE__ */ jsxs(Col, {
                  md: "6",
                  sm: "6",
                  lg: "6",
                  className: "mt-4",
                  children: [/* @__PURE__ */ jsx(Form.Label, {
                    className: "fw-bold",
                    children: "Parent Name *"
                  }), /* @__PURE__ */ jsx(Form.Control, {
                    type: "text",
                    required: true,
                    name: "parentName",
                    value: values.parentName,
                    onChange: HandleChange
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(Form.Label, {
                  className: "fw-bold",
                  children: "discuss your desire *"
                }), /* @__PURE__ */ jsx(Form.Control, {
                  name: "desire",
                  as: "textarea",
                  required: true,
                  value: values.desire,
                  onChange: HandleChange
                })]
              }), /* @__PURE__ */ jsx("hr", {
                className: "mt-5"
              }), /* @__PURE__ */ jsx("div", {
                className: "mt-5 ",
                children: /* @__PURE__ */ jsx(Container, {
                  children: /* @__PURE__ */ jsxs("p", {
                    children: ["Thank you for all this valuable information that we keep confidential.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "Your personal data are processed by Vereda.co.in acts as data controller, to enable the processing of your application. In the event that you would be eligible to Vereda.co.in, these data will be used for educational and adminstrative follow up.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "You have the right to access, Modify, delete and oppose your personal data. To excercise these rights, please send your request to Vereda Management digital training or ", /* @__PURE__ */ jsx("a", {
                      href: "mailto:Support@vereda.co.in",
                      children: "support@vereda.co.in"
                    }), ".", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {}), "To learn more about how we handle your personal data, please visit our Privacy Policy.", /* @__PURE__ */ jsx("br", {}), /* @__PURE__ */ jsx("br", {})]
                  })
                })
              }), /* @__PURE__ */ jsx(Col, {
                mx: "6",
                children: /* @__PURE__ */ jsx(PrimaryButton, {
                  children: "Continue"
                })
              })]
            })
          })
        })
      })
    })]
  });
}
export {
  CreateApplication as default
};
