import "react";
import { j as jsx } from "../ssr.mjs";
function Guest({
  children
}) {
  return /* @__PURE__ */ jsx("div", {
    className: "flex header-block",
    style: {
      width: "100%"
    },
    children
  });
}
export {
  Guest as G
};
