import { Link } from "@inertiajs/inertia-react";
import { j as jsx, a as jsxs } from "../ssr.mjs";
const PageHeader = ({
  title,
  curPage
}) => {
  return /* @__PURE__ */ jsx("div", {
    className: "pageheader-section",
    children: /* @__PURE__ */ jsx("div", {
      className: "container",
      children: /* @__PURE__ */ jsx("div", {
        className: "row",
        children: /* @__PURE__ */ jsx("div", {
          className: "col-12",
          children: /* @__PURE__ */ jsxs("div", {
            className: "pageheader-content text-left",
            children: [/* @__PURE__ */ jsx("h2", {
              children: title
            }), /* @__PURE__ */ jsx("nav", {
              "aria-label": "breadcrumb",
              children: /* @__PURE__ */ jsxs("ol", {
                className: "breadcrumb ",
                children: [/* @__PURE__ */ jsx("li", {
                  className: "breadcrumb-item",
                  children: /* @__PURE__ */ jsx(Link, {
                    to: "/",
                    children: "Home"
                  })
                }), /* @__PURE__ */ jsx("li", {
                  className: "breadcrumb-item active",
                  "aria-current": "page",
                  children: curPage
                })]
              })
            })]
          })
        })
      })
    })
  });
};
const PageHeader$1 = PageHeader;
export {
  PageHeader$1 as P
};
