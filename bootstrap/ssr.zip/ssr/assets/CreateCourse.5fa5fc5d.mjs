import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, useForm, Head, Link } from "@inertiajs/inertia-react";
import { Row, Col, Form } from "react-bootstrap";
/* empty css                 */import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { Inertia } from "@inertiajs/inertia";
import { Editor } from "react-draft-wysiwyg";
import { EditorState } from "draft-js";
import { convertToHTML } from "draft-convert";
/* empty css                               */import { CheckCircle } from "react-bootstrap-icons";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function CreateCourse(props) {
  const {
    program,
    code,
    all_batch,
    flash
  } = usePage().props;
  const {
    data,
    setData,
    post,
    progress
  } = useForm({
    "price": "",
    "filing": "",
    "batch": "",
    "Link": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setData((data2) => ({
      ...data2,
      [key]: value
    }));
  };
  const [editorState, setEditorState] = useState(() => EditorState.createEmpty());
  const [convertedContent, setConvertedContent] = useState(null);
  const HandleEditorChange = (state) => {
    setEditorState(state);
    convertContentToHTML();
  };
  const convertContentToHTML = () => {
    let currentContentAsHTML = convertToHTML(editorState.getCurrentContent());
    setConvertedContent(currentContentAsHTML);
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    const method = {
      _method: "put"
    };
    Inertia.post(`/moderator/edit-create-program/${program.topic.split(" ").join("-")}/${program.id}`, {
      "first": data,
      "type": program.sessiontype,
      "second": convertedContent,
      method
    });
  };
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Moderator Page"
      }), /* @__PURE__ */ jsxs("h3", {
        className: "fs-4 text-color-blue",
        children: [" Update ", program.topic, " for ", program.program]
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Create Course"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-12xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsxs("div", {
          className: "overflow-hidden bg-white shadow-sm sm:rounded-lg",
          children: [/* @__PURE__ */ jsxs("div", {
            className: "p-6 border-b border-gray-200",
            children: [/* @__PURE__ */ jsxs("form", {
              method: "POST",
              onSubmit: HandleSubmit,
              className: "mt-5",
              children: [/* @__PURE__ */ jsx("h1", {
                children: "Create Course"
              }), /* @__PURE__ */ jsxs(Row, {
                children: [/* @__PURE__ */ jsxs(Col, {
                  children: [/* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsxs(Form.Label, {
                      htmlFor: "file",
                      children: ["Upload ", program.sessiontype == "video" && "VIdeo" || program.sessiontype == "book" && "Studies pdf file" || program.sessiontype == "test" && "quiz"]
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "file",
                      name: "filing",
                      value: data.file,
                      onChange: (e) => setData("filing", e.target.files[0]),
                      accept: program.sessiontype == "video" && "video/*" || program.sessiontype == "book" && "application/pdf"
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      htmlFor: "price",
                      children: "For Batch"
                    }), /* @__PURE__ */ jsxs(Form.Select, {
                      value: data.batch,
                      onChange: HandleChange,
                      name: "batch",
                      required: true,
                      children: [/* @__PURE__ */ jsx("option", {
                        children: "select"
                      }), /* @__PURE__ */ jsxs("option", {
                        value: program.batch,
                        children: ["Batch ", program.batch]
                      })]
                    })]
                  }), program.sessiontype == "video" && /* @__PURE__ */ jsxs("div", {
                    className: "mt-3",
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      children: "Google meet Link"
                    }), /* @__PURE__ */ jsx(Form.Control, {
                      type: "text",
                      name: "Link",
                      placeholder: "meet.google.com/example",
                      onChange: HandleChange,
                      value: data.Link,
                      required: true
                    })]
                  })]
                }), /* @__PURE__ */ jsx(Col, {
                  md: "12",
                  lg: "6",
                  children: /* @__PURE__ */ jsxs("div", {
                    children: [/* @__PURE__ */ jsx(Form.Label, {
                      children: "Describe Content."
                    }), /* @__PURE__ */ jsx(Editor, {
                      editorState,
                      onEditorStateChange: HandleEditorChange,
                      toolbarClassName: "toolbar-class",
                      wrapperClassName: "wrapper-class",
                      editorClassName: "editor-class",
                      name: "description"
                    })]
                  })
                }), /* @__PURE__ */ jsx(Col, {
                  lg: "6",
                  md: "6",
                  children: /* @__PURE__ */ jsx(PrimaryButton, {
                    className: "mt-4",
                    children: "Submit"
                  })
                })]
              })]
            }), flash.success && /* @__PURE__ */ jsx("p", {
              children: flash.success
            })]
          }), program.action == "pending" ? /* @__PURE__ */ jsx("div", {
            className: "p-2",
            children: /* @__PURE__ */ jsxs(Link, {
              className: "flex",
              style: {
                width: "100%"
              },
              href: `/moderator/ready-quesiton/${program.id}`,
              children: ["click if ready ", /* @__PURE__ */ jsx("span", {
                className: "mt-1 ml-2",
                children: /* @__PURE__ */ jsx(CheckCircle, {})
              })]
            })
          }) : /* @__PURE__ */ jsx("div", {
            className: "p-2",
            children: /* @__PURE__ */ jsx("span", {
              className: " pl-2 ml-2",
              children: /* @__PURE__ */ jsx(CheckCircle, {
                style: {
                  color: "green"
                }
              })
            })
          })]
        })
      })
    })]
  });
}
export {
  CreateCourse as default
};
