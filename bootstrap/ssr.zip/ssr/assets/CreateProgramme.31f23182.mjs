import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { Head } from "@inertiajs/inertia-react";
import { Editor } from "react-draft-wysiwyg";
import { EditorState } from "draft-js";
import DOMPurify from "dompurify";
import "draft-convert";
/* empty css                               *//* empty css                */import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap";
import "react-bootstrap/Nav";
import "@mui/material";
/* empty css                 */import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function CreateProgramme(props) {
  const [editorState, setEditorState] = useState(() => EditorState.createEmpty());
  const [convertedContent, setConvertedContent] = useState(null);
  const HandleEditorChange = (state) => {
    setEditorState(state);
  };
  const createMarkup = (html) => {
    return {
      __html: DOMPurify.sanitize(html)
    };
  };
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Moderator"
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-4 text-color-blue",
        children: "Upload Course "
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Create / Programme"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-7xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "bg-white overflow-hidden shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsxs("div", {
            className: "p-6 bg-white border-b border-gray-200",
            children: [/* @__PURE__ */ jsx(Editor, {
              editorState,
              onEditorStateChange: HandleEditorChange,
              toolbarClassName: "toolbar-class",
              wrapperClassName: "wrapper-class",
              editorClassName: "editor-class"
            }), /* @__PURE__ */ jsx("div", {
              className: "preview",
              dangerouslySetInnerHTML: createMarkup(convertedContent)
            })]
          })
        })
      })
    })]
  });
}
export {
  CreateProgramme as default
};
