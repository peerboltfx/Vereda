import "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, Head } from "@inertiajs/inertia-react";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap-icons";
import "react-bootstrap";
import "react-bootstrap/Nav";
import "@mui/material";
/* empty css                 */import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Dashboard(props) {
  const {
    errorCode,
    errors,
    programs
  } = usePage().props;
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold ts-1 leading-tight",
        children: "Error Page"
      }), /* @__PURE__ */ jsxs("h3", {
        className: "fs-4 text-color-blue",
        children: [" ", errorCode, " "]
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Dashboard"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-7xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "bg-white overflow-hidden shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsx("div", {
            className: "p-6 bg-white border-b border-gray-200",
            children: /* @__PURE__ */ jsxs("h2", {
              className: "fs-6 p-5 text-color-gray",
              children: [" ", errors, " ", /* @__PURE__ */ jsx("span", {})]
            })
          })
        })
      })
    })]
  });
}
export {
  Dashboard as default
};
