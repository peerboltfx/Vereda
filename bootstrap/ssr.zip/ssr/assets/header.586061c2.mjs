import { useState } from "react";
import { usePage, Link } from "@inertiajs/inertia-react";
import { Alert } from "react-bootstrap";
import { Inertia } from "@inertiajs/inertia";
import { a as jsxs, j as jsx, F as Fragment } from "../ssr.mjs";
const Shape1 = "/build/assets/03.1c0d47e3.png";
const Shape2 = "/build/assets/04.c859db33.png";
const newsTitle = "Want Us To Email You About Special Offers And Updates?";
const siteTitle = "Site Map";
const useTitle = "Useful Links";
const socialTitle = "Social Contact";
const supportTitle = "Our Support";
const siteList = [{
  text: "Home",
  link: "/"
}, {
  text: "DashBoard",
  link: "/dashboard"
}, {
  text: "Login",
  link: "/login"
}, {
  text: "Register",
  link: "/register"
}];
const useList = [{
  text: "About Us",
  link: "/pages/about"
}, {
  text: "Refund Policy",
  link: route("RefundPolicy")
}, {
  text: "Terms & Conditions",
  link: route("TermsAndCond")
}, {
  text: "Contact Us",
  link: "/pages/contact"
}, {
  text: "Privacy Policy",
  link: route("PrivacyPolicy")
}];
const socialList$1 = [{
  text: "Facebook",
  link: "https://www.facebook.com/veredaindia?mibextid=LQQJ4d"
}, {
  text: "Instagram",
  link: "https://www.instagram.com/veredaindia"
}, {
  text: "LinkedIn",
  link: "https://www.linkedin.com/company/vereda-management-india/"
}];
const supportList = [
  {
    text: "Help Center",
    link: "https://wa.me/+919570994444"
  },
  {
    text: "Contact Support",
    link: "tel:+919570994444"
  }
];
const Footer = () => {
  const {
    flash
  } = usePage().props;
  const [values, setValue] = useState({
    "email": ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setValue((values2) => ({
      ...values2,
      [key]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/news-form", values);
  };
  return /* @__PURE__ */ jsxs("div", {
    className: "news-footer-wrap",
    children: [/* @__PURE__ */ jsxs("div", {
      className: "fs-shape",
      children: [/* @__PURE__ */ jsx("img", {
        src: Shape1,
        alt: "fst",
        className: "fst-1"
      }), /* @__PURE__ */ jsx("img", {
        src: Shape2,
        alt: "fst",
        className: "fst-2"
      })]
    }), /* @__PURE__ */ jsx("div", {
      className: "news-letter",
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "section-wrapper",
          children: [/* @__PURE__ */ jsx("div", {
            className: "news-title",
            children: /* @__PURE__ */ jsx("h3", {
              children: newsTitle
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "news-form rounded-md",
            children: /* @__PURE__ */ jsxs("form", {
              onSubmit: handleSubmit,
              children: [/* @__PURE__ */ jsxs("div", {
                className: "nf-list rounded-md",
                children: [/* @__PURE__ */ jsx("input", {
                  type: "email",
                  onChange: HandleChange,
                  value: values.email,
                  name: "email",
                  placeholder: "Enter Your Email"
                }), /* @__PURE__ */ jsx("input", {
                  type: "submit",
                  className: "rounded-md",
                  value: "Subscribe Now"
                })]
              }), flash.message && /* @__PURE__ */ jsx(Fragment, {
                children: /* @__PURE__ */ jsx(Alert, {
                  variant: "success",
                  className: "mt-3",
                  children: flash.message
                })
              })]
            })
          })]
        })
      })
    }), /* @__PURE__ */ jsxs("footer", {
      children: [/* @__PURE__ */ jsx("div", {
        className: "footer-top padding-tb pt-0",
        children: /* @__PURE__ */ jsx("div", {
          className: "container",
          children: /* @__PURE__ */ jsxs("div", {
            className: "row g-4 row-cols-xl-4 row-cols-md-2 row-cols-1 justify-content-center",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx("div", {
                className: "footer-item",
                children: /* @__PURE__ */ jsx("div", {
                  className: "footer-inner",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "footer-content",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "title",
                      children: /* @__PURE__ */ jsx("h4", {
                        children: siteTitle
                      })
                    }), /* @__PURE__ */ jsx("div", {
                      className: "content",
                      children: /* @__PURE__ */ jsx("ul", {
                        className: "lab-ul",
                        children: siteList.map((val, i) => /* @__PURE__ */ jsx("li", {
                          children: /* @__PURE__ */ jsx(Link, {
                            href: val.link,
                            children: val.text
                          })
                        }, i))
                      })
                    })]
                  })
                })
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx("div", {
                className: "footer-item",
                children: /* @__PURE__ */ jsx("div", {
                  className: "footer-inner",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "footer-content",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "title",
                      children: /* @__PURE__ */ jsx("h4", {
                        children: useTitle
                      })
                    }), /* @__PURE__ */ jsx("div", {
                      className: "content",
                      children: /* @__PURE__ */ jsx("ul", {
                        className: "lab-ul",
                        children: useList.map((val, i) => /* @__PURE__ */ jsx("li", {
                          children: /* @__PURE__ */ jsx("a", {
                            href: val.link,
                            children: val.text
                          })
                        }, i))
                      })
                    })]
                  })
                })
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx("div", {
                className: "footer-item",
                children: /* @__PURE__ */ jsx("div", {
                  className: "footer-inner",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "footer-content",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "title",
                      children: /* @__PURE__ */ jsx("h4", {
                        children: socialTitle
                      })
                    }), /* @__PURE__ */ jsx("div", {
                      className: "content",
                      children: /* @__PURE__ */ jsx("ul", {
                        className: "lab-ul",
                        children: socialList$1.map((val, i) => /* @__PURE__ */ jsx("li", {
                          children: /* @__PURE__ */ jsx(Link, {
                            href: val.link,
                            children: val.text
                          })
                        }, i))
                      })
                    })]
                  })
                })
              })
            }), /* @__PURE__ */ jsx("div", {
              className: "col",
              children: /* @__PURE__ */ jsx("div", {
                className: "footer-item",
                children: /* @__PURE__ */ jsx("div", {
                  className: "footer-inner",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "footer-content",
                    children: [/* @__PURE__ */ jsx("div", {
                      className: "title",
                      children: /* @__PURE__ */ jsx("h4", {
                        children: supportTitle
                      })
                    }), /* @__PURE__ */ jsx("div", {
                      className: "content",
                      children: /* @__PURE__ */ jsx("ul", {
                        className: "lab-ul",
                        children: supportList.map((val, i) => /* @__PURE__ */ jsx("li", {
                          children: /* @__PURE__ */ jsx("a", {
                            target: "_blank",
                            href: val.link,
                            children: val.text
                          })
                        }, i))
                      })
                    })]
                  })
                })
              })
            })]
          })
        })
      }), /* @__PURE__ */ jsx("div", {
        className: "footer-bottom style-2",
        children: /* @__PURE__ */ jsx("div", {
          className: "container",
          children: /* @__PURE__ */ jsx("div", {
            className: "section-wrapper",
            children: /* @__PURE__ */ jsxs("p", {
              children: [/* @__PURE__ */ jsx(Link, {
                href: "/",
                children: "Vereda Digital Learning"
              }), "\xA9 2023 "]
            })
          })
        })
      })]
    })]
  });
};
const Footer$1 = Footer;
const Logo = "/build/assets/03.59ee55c2.png";
const phoneNumber = "+91-9 570 994 444";
const address = "Sinha Library road, Venture park Patna";
let socialList = [{
  iconName: "icofont-facebook",
  siteLink: "https://www.facebook.com/veredaindia?mibextid=LQQJ4d"
}, {
  iconName: "icofont-linkedin",
  siteLink: "https://www.linkedin.com/company/vereda-management-india/"
}, {
  iconName: "icofont-instagram",
  siteLink: "https://www.instagram.com/veredaindia"
}];
const Header = () => {
  const [menuToggle, setMenuToggle] = useState(false);
  const [socialToggle, setSocialToggle] = useState(false);
  const [headerFiexd, setHeaderFiexd] = useState(false);
  window.addEventListener("scroll", () => {
    if (window.scrollY > 200) {
      setHeaderFiexd(true);
    } else {
      setHeaderFiexd(false);
    }
  });
  return /* @__PURE__ */ jsxs("header", {
    className: `header-section ${headerFiexd ? "header-fixed fadeInUp" : ""}`,
    children: [/* @__PURE__ */ jsx("div", {
      className: `header-top ${socialToggle ? "open" : ""}`,
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "header-top-area",
          children: [/* @__PURE__ */ jsxs("ul", {
            className: "lab-ul left",
            children: [/* @__PURE__ */ jsx("li", {
              children: /* @__PURE__ */ jsxs("a", {
                target: "_blank",
                href: "tel:+919 570 994 444",
                children: [/* @__PURE__ */ jsx("i", {
                  className: "icofont-ui-call"
                }), " ", /* @__PURE__ */ jsx("span", {
                  children: phoneNumber
                })]
              })
            }), /* @__PURE__ */ jsx("li", {
              children: /* @__PURE__ */ jsxs("a", {
                target: "_blank",
                href: "https://maps.app.goo.gl/5ExiesDgMEmgW6yo6",
                children: [/* @__PURE__ */ jsx("i", {
                  className: "icofont-location-pin"
                }), " ", address]
              })
            })]
          }), /* @__PURE__ */ jsxs("ul", {
            className: "lab-ul social-icons d-flex align-items-center",
            children: [/* @__PURE__ */ jsx("li", {
              children: /* @__PURE__ */ jsx("p", {
                children: "Find us on : "
              })
            }), socialList.map((val, i) => /* @__PURE__ */ jsx("li", {
              children: /* @__PURE__ */ jsx("a", {
                target: "_blank",
                href: val.siteLink,
                children: /* @__PURE__ */ jsx("i", {
                  className: val.iconName
                })
              })
            }, i))]
          })]
        })
      })
    }), /* @__PURE__ */ jsx("div", {
      className: "header-bottom",
      children: /* @__PURE__ */ jsx("div", {
        className: "container",
        children: /* @__PURE__ */ jsxs("div", {
          className: "header-wrapper",
          children: [/* @__PURE__ */ jsx("div", {
            className: "logo",
            children: /* @__PURE__ */ jsx(Link, {
              href: "/",
              children: /* @__PURE__ */ jsx("img", {
                src: Logo,
                alt: "logo"
              })
            })
          }), /* @__PURE__ */ jsxs("div", {
            className: "menu-area",
            children: [/* @__PURE__ */ jsx("div", {
              className: "menu",
              children: /* @__PURE__ */ jsxs("ul", {
                className: `lab-ul ${menuToggle ? "active" : ""}`,
                children: [/* @__PURE__ */ jsx("li", {
                  children: /* @__PURE__ */ jsx(Link, {
                    href: "/",
                    children: "Home"
                  })
                }), /* @__PURE__ */ jsx("li", {
                  children: /* @__PURE__ */ jsx(Link, {
                    href: "/pages/view-courses",
                    children: "Courses"
                  })
                }), /* @__PURE__ */ jsx("li", {
                  children: /* @__PURE__ */ jsx(Link, {
                    href: "/pages/contact",
                    children: "Contact"
                  })
                })]
              })
            }), /* @__PURE__ */ jsxs("a", {
              href: "/login",
              className: "login uppercase",
              children: [/* @__PURE__ */ jsx("i", {
                className: "icofont-user"
              }), " ", /* @__PURE__ */ jsx("span", {
                className: "ml-2",
                children: "login"
              }), " "]
            }), /* @__PURE__ */ jsxs("div", {
              className: `header-bar d-lg-none ${menuToggle ? "active" : ""}`,
              onClick: () => setMenuToggle(!menuToggle),
              children: [/* @__PURE__ */ jsx("span", {}), /* @__PURE__ */ jsx("span", {}), /* @__PURE__ */ jsx("span", {})]
            }), /* @__PURE__ */ jsx("div", {
              className: "ellepsis-bar d-lg-none",
              onClick: () => setSocialToggle(!socialToggle),
              children: /* @__PURE__ */ jsx("i", {
                className: "icofont-info-square"
              })
            })]
          })]
        })
      })
    })]
  });
};
const Header$1 = Header;
export {
  Footer$1 as F,
  Header$1 as H
};
