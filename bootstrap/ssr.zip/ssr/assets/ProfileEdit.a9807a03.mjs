import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout.074205d1.mjs";
import { usePage, useForm, Head } from "@inertiajs/inertia-react";
import "react-draft-wysiwyg";
import { EditorState } from "draft-js";
import "dompurify";
import "draft-convert";
/* empty css                               *//* empty css                */import { Col, Form, Alert } from "react-bootstrap";
import { Inertia } from "@inertiajs/inertia";
import { P as PrimaryButton } from "./PrimaryButton.4bb116fc.mjs";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { Book, Person } from "react-bootstrap-icons";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "./ApplicationLogo.c9284209.mjs";
import "./logo.d6c74f57.mjs";
import "react-bootstrap/Nav";
import "@mui/material";
/* empty css                 */import "@material-ui/core/Menu";
import "@material-ui/core/MenuItem";
import "@material-ui/core/Badge";
import "@material-ui/core/Tooltip";
import "@material-ui/core/ListItemIcon";
import "@material-ui/core/Typography";
import "@material-ui/core/styles";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function ProfileEdit(props) {
  const {
    auth,
    programs,
    flash,
    profile
  } = usePage().props;
  useState(() => EditorState.createEmpty());
  const [show, setShow] = useState(false);
  const HandleShow = () => {
    setShow(true);
  };
  const {
    data,
    setData,
    post,
    progress
  } = useForm({
    "firstname": profile ? profile.firstname : "",
    "lastname": profile ? profile.lastname : "",
    "country": profile ? profile.country : "",
    "gender": profile ? profile.gender : "",
    "birthDate": profile ? profile.birthDate : "",
    "desire": profile ? profile.desire : "",
    "email": auth.user.email || "",
    "phone": auth.user.phone || "",
    "address": profile ? profile.address : "",
    "education": profile ? profile.education : "",
    "avatar": profile ? profile.avatar : ""
  });
  const HandleChange = (e) => {
    const key = e.target.name;
    const value = e.target.value;
    setData((data2) => ({
      ...data2,
      [key]: value
    }));
  };
  const HandleSubmit = (e) => {
    e.preventDefault();
    Inertia.post("/profile/update", data);
  };
  const countries = ["United States", "Canada", "Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and/or Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Cook Islands", "Costa Rica", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecudaor", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France, Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Ivory Coast", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kosovo", "Kuwait", "Kyrgyzstan", "Lao People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfork Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia South Sandwich Islands", "South Sudan", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbarn and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States minor outlying islands", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City State", "Venezuela", "Vietnam", "Virigan Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zaire", "Zambia", "Zimbabwe"];
  const found = programs.filter((obj) => Object.values(obj).some((val) => typeof val == "string" && val.includes(data.search)));
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth: props.auth,
    errors: props.errors,
    header: /* @__PURE__ */ jsxs(Fragment, {
      children: [/* @__PURE__ */ jsx("h2", {
        className: "font-semibold fs-2 leading-tight",
        children: auth.user.name
      }), /* @__PURE__ */ jsx("h3", {
        className: "fs-4 fw-bold text-color-blue",
        children: " Edit Profile"
      })]
    }),
    Search: /* @__PURE__ */ jsxs("div", {
      className: "Search-container",
      children: [/* @__PURE__ */ jsx("input", {
        onClick: HandleShow,
        type: "text",
        name: "search",
        value: data.search,
        onChange: HandleChange
      }), /* @__PURE__ */ jsxs("div", {
        onBlur: () => setShow(false),
        tabIndex: "0",
        style: {
          height: "400px",
          overflowY: "scroll"
        },
        className: show ? "Searched bg-white active p-2" : "Searched",
        children: [/* @__PURE__ */ jsx("h6", {
          className: "fw-bold text-color-dark-blue text-center",
          children: "Search Course"
        }), found.map((data2, index) => {
          return /* @__PURE__ */ jsx("div", {
            className: "bg-white pt-2 mt-1 pb-2 pl-4 shadow-sm sm:rounded-lg",
            children: /* @__PURE__ */ jsx(Row, {
              children: /* @__PURE__ */ jsx(Col, {
                mx: "6",
                children: /* @__PURE__ */ jsx(Link, {
                  href: `/en/${data2.program.split(" ").join("-")}/session/${data2.random}`,
                  className: "text-color-dark-blue",
                  children: /* @__PURE__ */ jsxs("div", {
                    className: "flex pb-3",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "6",
                      className: "pt-0 ",
                      children: /* @__PURE__ */ jsx(Book, {
                        style: {
                          fontSize: "30px",
                          color: "#DC4731"
                        },
                        className: "pl-1"
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      className: "fs-5 fw-bold pl-0 ml-4 text-color-dark-blue",
                      children: data2.program
                    })]
                  })
                })
              })
            })
          }, index);
        })]
      })]
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Profile Form"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsx("div", {
        className: "max-w-8xl mx-auto sm:px-6 lg:px-8",
        children: /* @__PURE__ */ jsx("div", {
          className: "bg-white overflow-hidden shadow-sm sm:rounded-lg",
          children: /* @__PURE__ */ jsxs("div", {
            className: "p-6 bg-white border-b border-gray-200",
            children: [/* @__PURE__ */ jsx("form", {
              onSubmit: HandleSubmit,
              method: "POST",
              children: /* @__PURE__ */ jsxs("div", {
                className: "row",
                children: [/* @__PURE__ */ jsxs(Col, {
                  md: "3",
                  children: [/* @__PURE__ */ jsx("label", {
                    HtmlFor: "avatar",
                    className: "flex w-100 items-center",
                    children: /* @__PURE__ */ jsx(Person, {
                      className: "text-color-dark-blue",
                      style: {
                        fontSize: "150px"
                      }
                    })
                  }), /* @__PURE__ */ jsx(DndProvider, {
                    backend: HTML5Backend,
                    children: /* @__PURE__ */ jsx("input", {
                      type: "file",
                      required: true,
                      name: "avatar",
                      id: "avatar",
                      className: "block",
                      accept: "png/jpg",
                      onChange: (e) => setData("avatar", e.target.files[0])
                    })
                  })]
                }), /* @__PURE__ */ jsxs(Col, {
                  md: "9",
                  children: [/* @__PURE__ */ jsxs("div", {
                    className: "row",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          children: "First name"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          type: "text",
                          name: "firstname",
                          value: data.firstname,
                          onChange: HandleChange
                        })]
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          children: "Last name"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          type: "text",
                          name: "lastname",
                          value: data.lastname,
                          onChange: HandleChange
                        })]
                      })
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "row",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          className: "fw-bold",
                          children: "Date of Birth *"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          type: "date",
                          required: true,
                          name: "birthDate",
                          value: data.birthDate,
                          onChange: HandleChange
                        })]
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          className: "fw-bold",
                          children: "Parent Name *"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          type: "text",
                          required: true,
                          name: "ParentName",
                          placeholder: "Mana William",
                          value: data.ParentName,
                          onChange: HandleChange
                        })]
                      })
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "row",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          className: "fw-bold",
                          children: "Phone Number *"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          type: "text",
                          required: true,
                          name: "phone",
                          placeholder: "+123456798",
                          value: data.phone,
                          onChange: HandleChange
                        })]
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          className: "fw-bold",
                          children: "Email Address *"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          type: "text",
                          required: true,
                          name: "email",
                          placeholder: "william@gmail.com",
                          value: data.email,
                          onChange: HandleChange
                        })]
                      })
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "row",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          children: "Country"
                        }), /* @__PURE__ */ jsxs(Form.Select, {
                          value: data.country,
                          required: true,
                          name: "country",
                          onChange: HandleChange,
                          children: [/* @__PURE__ */ jsx("option", {
                            children: "select country"
                          }), countries.map((info, index) => {
                            return /* @__PURE__ */ jsx("option", {
                              value: info,
                              children: info
                            }, index);
                          })]
                        })]
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          className: "fw-bold",
                          children: "Highest Education *"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          type: "text",
                          required: true,
                          name: "education",
                          placeholder: "BSc Computer Science",
                          value: data.education,
                          onChange: HandleChange
                        })]
                      })
                    })]
                  }), /* @__PURE__ */ jsxs("div", {
                    className: "row",
                    children: [/* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          className: "fw-bold",
                          children: "Address *"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          name: "address",
                          as: "textarea",
                          value: data.address,
                          onChange: HandleChange
                        })]
                      })
                    }), /* @__PURE__ */ jsx(Col, {
                      md: "6",
                      children: /* @__PURE__ */ jsxs("div", {
                        className: "mt-4",
                        children: [/* @__PURE__ */ jsx(Form.Label, {
                          className: "fw-bold",
                          children: "discuss your desire"
                        }), /* @__PURE__ */ jsx(Form.Control, {
                          name: "desire",
                          as: "textarea",
                          required: true,
                          value: data.desire,
                          onChange: HandleChange
                        })]
                      })
                    })]
                  }), /* @__PURE__ */ jsx("div", {
                    className: "w-40 mt-5 float-right rounded-full",
                    children: /* @__PURE__ */ jsx(PrimaryButton, {
                      className: "float-right rounded-full",
                      children: "save"
                    })
                  })]
                })]
              })
            }), flash.message && /* @__PURE__ */ jsx(Alert, {
              variant: "success",
              children: " Successfully Updated."
            })]
          })
        })
      })
    })]
  });
}
export {
  ProfileEdit as default
};
