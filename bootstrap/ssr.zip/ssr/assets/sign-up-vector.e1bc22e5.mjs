const signup = "/build/assets/sign-up-vector.3354f6bf.jpg";
export {
  signup as s
};
