const Fullstack = "/build/assets/fullstack-2.dcf98972.webp";
export {
  Fullstack as F
};
