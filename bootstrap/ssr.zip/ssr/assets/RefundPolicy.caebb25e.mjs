import "react";
import Container from "react-bootstrap/Container";
import { usePage, Head } from "@inertiajs/inertia-react";
/* empty css                 *//* empty css                 */import { H as Header, F as Footer } from "./header.586061c2.mjs";
import { P as PageHeader } from "./pageheader.c3637c95.mjs";
import { a as jsxs, F as Fragment, j as jsx } from "../ssr.mjs";
import "react-bootstrap";
import "@inertiajs/inertia";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function RefundPolicy(props) {
  usePage().props;
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(Header, {}), /* @__PURE__ */ jsx(PageHeader, {
      title: "Our Refund Policy",
      curPage: "Refund Policy."
    }), /* @__PURE__ */ jsxs(Head, {
      title: "Our Refund Policy",
      children: [/* @__PURE__ */ jsx("meta", {
        property: "og:Vereda.co.in",
        content: "https://vereda.co.in"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:title",
        content: "Refund Policy"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:description",
        content: "What you need to know when making purchases from us"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:image",
        content: "../Images/banner.jpg"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:url",
        content: "https://vereda.co.in/pages/privacy-policy"
      }), /* @__PURE__ */ jsx("meta", {
        property: "og:type",
        content: "article"
      }), /* @__PURE__ */ jsx("meta", {
        name: "robots",
        content: "index,follow"
      }), /* @__PURE__ */ jsx("meta", {
        name: "google",
        content: "sitelinkssearchbox"
      }), /* @__PURE__ */ jsx("meta", {
        property: "url",
        content: "https://vereda.co.in"
      })]
    }), /* @__PURE__ */ jsx("section", {
      children: /* @__PURE__ */ jsxs(Container, {
        className: "mt-5 mb-5 pb-5",
        children: [/* @__PURE__ */ jsx("h4", {
          className: "fs-2 text-center fw-bold mt-5 p-4 pb-4",
          children: "When You make Purchases on our site, you are bind by(and must accept) this refund policy."
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5"
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue text-center fs-2 fw-bold mt-4",
            children: "All Sales Are Final"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "We do not offer refunds under any circumstances"
        }), /* @__PURE__ */ jsx("h4", {
          children: /* @__PURE__ */ jsx("b", {
            className: "text-color-dark-blue fs-2 fw-bold mt-4",
            children: "No Return or Exchanges."
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "mt-5 mb-5",
          children: "As we provide a digital service, returns and exchanges do not apply. We do not offer any kind of returns or exchanges."
        })]
      })
    }), /* @__PURE__ */ jsx(Footer, {})]
  });
}
export {
  RefundPolicy as default
};
