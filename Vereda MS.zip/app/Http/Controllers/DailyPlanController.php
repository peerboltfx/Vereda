<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\daily_plan;
use App\Models\Program;
use App\Models\batch;
use App\Models\Assignment;
use App\Models\subscribe;
use App\Events\NotifyPlan;
use App\Http\Requests\Storedaily_planRequest;
use App\Http\Requests\Updatedaily_planRequest;
use Inertia\Inertia;
use Illuminate\Support\Facades\DB;

class DailyPlanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $batch= batch::where('trainerid',auth()->user()->id)->get();
        $program=DB::table('programs')->get();
        return Inertia::render('Moderator/Scheduler',[
            'program'=> $program,
            'batch'=>$batch,
        ]);
    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       $first= $request['first'];
       $second= $request['second'];
        $role=auth()->user()->role;
        $toprogram=Program::where('random',$first['programs_code'])->first()->program;
        $users=subscribe::where(["batch"=>$first['batch'], "program" => $toprogram])->get();
        $message=[
            'date' =>$first['date'],
                'batch' =>$first['batch'],
                'topic'=>$first['topic'],
               'program'=> $toprogram,
                'sessiontype'=>$first['sessiontype'],
        ];
        if( $role == 'moderator'){
            $save=auth()->user()->daily_plan()->create([
                'date' =>$first['date'],
                'batch' =>$first['batch'],
                'topic'=>$first['topic'],
                'program'=>$toprogram,
                'program_code'=>$first['programs_code'],
                'sessiontype'=>$first['sessiontype'],
                'decription'=>$second,
                'assignment'=>$first['assignment'],
            ]);
            if($users){
                broadcast(new NotifyPlan($message));
            }
           
            return back()->with('message','schedule created Successfully');
        }
        else{
            return back()->with('error','You do not have the priviledge to take this action');
        }
    }

  public function deletePlan( $id){
    $user=daily_plan::find($id);
    $user->delete();
    return back()->with("message","successfully Deleted");
  }

  public function reuploadPlan($id) {
    $user=daily_plan::find($id);
    $user->update(['action'=>'pending']);
    return back()->with("message","Course Ready for edit");
  }

    /**
     * View a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Storedaily_planRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function view()
    {
        $data=daily_plan::all()->where('user_id',auth()->user()->id);
        
        return Inertia::render("Moderator/PlanTable",["plans"=>$data]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\daily_plan  $daily_plan
     * @return \Illuminate\Http\Response
     */
    public function createCourse($code, $id)
    {

        $schedule=daily_plan::where('id',$id)->first();
       $allbatch=batch::where('trainerid',auth()->user()->id)->get();
    
        if($schedule==NULL){
             return redirect("/error")->with('error','We couldnt find the page you are Looking for, please make sure you provided the correct link to the requested page.');        
        }
        
        else{
            if($schedule->sessiontype == "test"){
                return Inertia::render("Moderator/setQuiz",
            [ "program"=> $schedule,
            "program_code"=>$code,
            "all_batch"=>$allbatch
            ]
            );
            }
            else{
            return Inertia::render("Moderator/CreateCourse",[
                "program"=> $schedule,
                "program_code"=>$code,
                "all_batch"=>$allbatch
            ]);
        }
    }
}

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\daily_plan  $daily_plan
     * @return \Illuminate\Http\Response
     */
    public function creatingCourse($program,$id)
    {
        $check=DB::table("daily_plans")->where('id',$id);
        $data=request();
       $first= $data['first'];
       $second= $data['second'];
       $type=$data['type'];
       $name=$first["filing"];
        if($type =="book"){
        
        auth()->user()->UploadedCourse()->create([
            "name"=>$program.$id.".pdf",
            "batch"=>$first["batch"],
            "describe"=>$second,
            "course_id"=>$id,
        ]);
        
        }
        else if($type =="video")
        {
            $imagepath=$first['filing']->storeAs('video',$program.$id.".mp4","s3");
            auth()->user()->UploadedCourse()->create([
            "name"=>$program.$id.".mp4",
            "batch"=>$first["batch"],
            "describe"=>$second,
            "course_id"=>$id,
        ]);
        }
      
       return back()->with("success","successfully Created");
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Updatedaily_planRequest  $request
     * @param  \App\Models\daily_plan  $daily_plan
     * @return \Illuminate\Http\Response
     */
    public function addQuestions($topic, $id)
    {
        $datas=request();
        $batchInfo=$datas["batchInfo"];
        $data=$datas["data"];
       /** $getBatch = batch::where("id",$id);*/ 
    
        auth()->user()->Questions()->create([
            "question"=>$data["question"],
            "option1"=>$data["option1"],
            "option2"=>$data["option2"],
            "option3"=>$data["option3"],
            "option4"=>$data["option4"],
            "answer"=>$data["answer"],
            "batch"=>$batchInfo["id"],
            "trainerid"=>$batchInfo["trainer"],
            "course"=>$batchInfo["course"],
        ]);
        return back()->with("message", "question Added");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\daily_plan  $daily_plan
     * @return \Illuminate\Http\Response
     */
    public function readyquestion($id){
        $course= daily_plan::where("id",$id);
        $course->update([
            "action"=>"created",
        ]);
        return back()->with("message", "ready to begin quiz");
    }

    public function Assigmentview()
    {
        
        $assignment=daily_plan::where(["user_id"=>auth()->user()->id, 'assignment' => false])->get()->all();

        return Inertia::render("Moderator/Assignment",["assignments"=>$assignment]);
    }

    public function AssignmentViewID($id){
        $data=Assignment::where("topic_id",$id)->get();
    
        return Inertia::render("Moderator/ViewAssignment",["assignments"=>$data]);
    }

    public function assignmentUpdate($id){
    
        $assign=Assignment::where("id",$id)->get()->last();
        $decision="pass";
        $data=request();
        $datas=$data["score"];
        if($datas < 6){
            $decision ="fail";
        };
       
        $assign->update([
            "result"=>$datas,
            "decision"=>$decision
        ]);
        return back()->with("message","Student has been graded successfully");
        
    }
}
