<?php

namespace App\Http\Controllers;
use Redirect;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\requestCall;
use Illuminate\Support\Facades\Route;


class sendMail extends Controller
{
    
 public function mail(Request $request){

    }
}
