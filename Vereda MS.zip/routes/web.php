<?php

use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SendMailController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\FlutterpayController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DailyPlanController;
use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\DB;
use App\Models\Program;
use App\Models\subscribe;
use App\Models\daily_plan;
use App\Models\Messages;
use App\Models\testReport;
use App\Models\batch;
use App\Models\order_item;
use App\Events\NotifyPlan;
use Inertia\Inertia;
use Razorpay\Api\Api;
use App\Models\User;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/Home',function(){
    return Inertia::render("Home");
});

Route::get('/requesting',function(){
    return view("/emails/Request");
});

Route::get('/', function () {
    $program=DB::table('programs')->get();
   $batch=DB::table('batches')->where('options','open')->get();
   $fullstack=$batch->where("name","Full Stack Development Program")->last();
   $flutter=$batch->where("name","Flutter Development Program")->last();
 
    if(Inertia::render('Home')){
    return Inertia::render('Home', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
        'programs'=> $program,
        'batch'=>$batch,
        'fullstack'=>$fullstack,
        'flutter'=>$flutter,
    ]);
}
else{
    return view("welcome");
}
})->name('home');

Route::get('/pages/privacy-policy', function(){
    $programs=DB::table('programs')->get();
    return Inertia::render('PrivacyPolicy',['programs'=>$programs]);
})->name('PrivacyPolicy');

Route::get('/pages/refund-policy', function(){
    $programs=DB::table('programs')->get();
    return Inertia::render('RefundPolicy',['programs'=>$programs]);
})->name('RefundPolicy');

Route::get('/pages/terms-and-conditions', function(){
    $programs=DB::table('programs')->get();
    return Inertia::render("termsAndCondition",[
        'programs'=>$programs,
    ]);
})->name("TermsAndCond");

Route::get("/pages/view-courses",[SendMailController::class, "viewCourse"]);

Route::post("/news-form",[SendMailController::class, "newsForm"]);

Route::get("/pages/about", function(){
    return Inertia::render("about");
});

Route::get("/pages/contact", function(){
    return Inertia::render("contact");
});

Route::get('/moderator/create-study', function(){
    return Inertia::render('CreateProgramme');
})->middleware(['auth','verified'])->name('CreateProgramme');

Route::get('/Program/{program}', function($link){
    $explode=explode('-', $link);
    $implode=implode(' ',$explode);
    $programs=DB::table('programs')->get();
    $program=DB::table('programs')->where('program',$implode)->first();
    if($explode[0] == "Flutter"){
    return Inertia::render('FlutterDev', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'pricing'=> $program->price,
        'programs'=> $programs,
        'name'=>$program]
    );
}
else if($explode[0] == "Full"){
    return Inertia::render('FullstackDev', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'pricing'=> $program->price,
        'programs'=> $programs,
        'name'=>$program]
    );
}
else{
    return Inertia::render('/');
}    
});



Route::get('/error/',function(){
        $program=Program::all();
    return Inertia::render('ErrorPage',[
        'errors'=>'We couldnt find the page you are Looking for, please make sure you provided the correct link to the requested page.',
        'errorCode'=>'404',
        "programs"=>$program
    ]);
})->middleware(['auth']);


Route::get('/en/{session}/session/{link}',[SubscriptionController::class, 'index'])->middleware(['auth','ensurePayment'])->name('FullStackSession');

Route::get('/en/{session}/free-trial/{link}',[SubscriptionController::class,'trial'])->middleware(['auth','trialAttempt'])->name('FreeTrial');

Route::get('/payment/{link}',function($link){

    $program=DB::table('programs')->where('program',$link)->first();
   
    $order=order_item::where(["user_id"=>auth()->user()->id,"program"=>$link])->get()->last();

    $sub=subscribe::where('user_id',auth()->user()->id)->get();

    $batch=batch::where(["name"=>$link,"options"=>"open"])->get()->last();
    if($order){
        return Inertia::render('Payment',[
            'dev'=> $link,
            'price'=>$program->price,
            'name'=>auth()->user()->name,
            'orderId' => $order->orderId,
            'razorpayId' => $order->razorpayId,
            'amount' => $order->amount,
            'name' => $order->name,
            'currency' => 'INR',
            'program' => $order->program,
            "batch"=>$batch,
            "verified"=>$sub
        ]);
    }
    else{

   
    return Inertia::render('Payment',[
        'dev'=> $link,
        'price'=>$program->price,
        'hint'=>"",
        'name'=>auth()->user()->name,
        "batch"=>$batch,
        "verified"=>$sub
    ]); }
})->name('payment')->middleware(['auth']);

Route::post('/checkorder',[SubscriptionController::class, 'subscribing'])->middleware(['auth']);

Route::get('trial-attempt/{link}',function($link){
    $program=DB::table('programs')->where('program',$link)->first();
    return Inertia::render('Payment',[
        'dev'=> $link,
        'price'=>$program->price,
        'hint'=>"",
        'name'=>auth()->user()->name
    ]);
})->middleware(['auth']);

Route::post("/request/send-message",function(){
       $data=request()->all();
      Messages::create($data);
      return back()->with('success',"Message sent!, we'll get back to you via the email address you provided");
});

Route::get('/Program/Full-Stack-Development-Program', function(Program $check){
    
    $program=DB::table('programs')->where('program',"Full Stack Development Program")->first()->price;
   
    return Inertia::render('FullstackDev', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'pricing'=> $program,]);
})->name('FullStackDev');


Route::post('/request/call',[SendMailController::class,'mail']);


/**User Authentication : Admin, Student, Moderator */
Route::get('/dashboard', [ProfileController::class, "dashboard"])->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/application/edit-profile',function(){
    $user=auth()->user();
    $program=Program::all();
    return Inertia::render("CreateApplication",[
        "user"=>$user,
        "programs"=>$program
    ]);
})->middleware(['auth']);

Route::get('/profile/profile-edit',function(){
    $user=auth()->user();
    $profile=auth()->user()->Profile;
    $program=Program::all();
    $sub=subscribe::where('user_id',auth()->user()->id)->get();
    return Inertia::render("ProfileEdit",[
        "user"=>$user,
        "programs"=>$program,
        "profile"=>$profile,
        "verified" => $sub,
    ]);
})->middleware(['auth'])->name("EditProfile");

Route::post("/profile/application-submit",[ProfileController::class, "create"])->middleware(['auth']);

Route::post("/profile/update",[ProfileController::class, "update"])->middleware(['auth']);

Route::get("/profile",[ProfileController::class, "index"])->middleware(['auth'])->name("Profile");

Route::get("/student/en/study/{code}/{topic}/{id}",[SubscriptionController::class, 'studies'])->middleware(['auth']);

Route::get("/en/quiz/student/{origin}/{course}",[SubscriptionController::class, 'startQuiz'])->middleware(['auth']);

Route::post("/quiz/save",[SubscriptionController::class, "saveQuiz"])->middleware(["auth"]);

Route::get("/en/student-result",[SubscriptionController::class, "studentReport"])->middleware(["auth"])->name("StudentReportTable");

Route::post("/assignment/submit",[SubscriptionController::class, "Assignment"])->middleware(["auth"]);

Route::get("/student/my-assignments",[SubscriptionController::class, "viewAssignment"])->middleware(["auth"])->name("Assignment");

Route::get("/account/referral",[SubscriptionController::class, "ReferralPage"])->middleware(["auth"])->name('ReferralPage');

Route::post("/account/gerateReferral",[SubscriptionController::class,"GenerateReferral"])->middleware(["auth"]);

Route::get("/account/transactions",[SubscriptionController::class, "Transactions"])->middleware(["auth"])->name('Transactions');

Route::get("/get/{user}",function($user){
    $check=User::where("referral",$user)->get()->last();
    if($check){
        return redirect("/")->with('data', $check );
    }
    else{
        return redirect("/");
    }
});
/**
 * 
 *a routing post method for payment verification using razorpay
 *this will only perform after payment has successfully been made,
 * else payment verification middleware will prevent this action from taking place
 * PS: The two route belongs to Fullstack developement and Flutter developement
 * which is still under a static modulation
 */
Route::post('/razorpaypayment', [SubscriptionController::class, 'payment'])->name('payment');

Route::post('/razorpaypaymentflutter', [FlutterpayController::class, 'payment'])->name('payment');


/**
 * Below is routing session for moderator to perform a post, get , put 
 * patch etc.
 */

Route::get('/moderator/create/daily-plan',[DailyPlanController::class, 'index'])->middleware(['moderatorRole'])->name('dailyScheduler');

Route::post('/create/schedule-daily-plan',[DailyPlanController::class, 'create'])->middleware(['moderatorRole']);

Route::get("/moderator/en/daily-plan",[DailyPlanController::class, "view"])->middleware(['moderatorRole'])->name("DailyPlanView");

Route::get("/moderator/create-course/{code}/en/{id}",[DailyPlanController::class, "createCourse"])->middleware(["moderatorRole"]);

Route::post("/moderator/edit-create-program/{program}/{id}",[DailyPlanController::class, "creatingCourse"])->middleware(['moderatorRole']);

Route::post("/moderator/set-questions/{topic}/{id}",[DailyPlanController::class , "addQuestions"])->middleware(['moderatorRole']);

Route::get("/moderator/ready-quesiton/{id}",[DailyPlanController::class, "readyquestion"])->middleware(["moderatorRole"]);

Route::get("/moderator/delete-course/{id}",[DailyPlanController::class, "deletePlan"])->middleware(["moderatorRole"]);

Route::get("/moderator/reupload-course/{id}",[DailyPlanController::class, "reuploadPlan"])->middleware(["moderatorRole"]);

Route::get("/moderator/view-assignments",[DailyPlanController::class, "Assigmentview"])->middleware(["moderatorRole"]);

Route::get("/moderator/assignment-{id}",[DailyPlanController::class, "AssignmentViewID"])->middleware(["moderatorRole"]);

Route::post("/Moderator/assignment-update-{id}",[DailyPlanController::class, "assignmentUpdate"])->middleware(["moderatorRole"]);
//Administrator Routing Session for every activity including post/get/put/patch


Route::get('/admin/moderators',[AdminController::class, 'view'])->middleware(['Administrator'])->name('Moderators');

Route::get('/admin/all-users',[AdminController::class, 'Allusers'])->middleware(['Administrator'])->name('Users');

Route::get('/edit-moderator/{user}',[AdminController::class, 'editModerator'])->middleware(['Administrator']);

Route::get('/admin/create-program',[AdminController::class, 'createView'])->middleware(['Administrator'])->name('createProgram');

Route::get('/admin/all-students', [AdminController::class, 'AllStudents'])->middleware(['Administrator'])->name('AdminStudents');

Route::post('/admin/edit/moderator/{user}',[AdminController::class, 'editting'])->middleware(['Administrator']);

Route::post('/admin/create-new-program',[AdminController::class, 'createNewprogram'])->middleware(['Administrator']);

Route::post('/admin/edit-batch/{user}',[AdminController::class, 'editBatch'])->middleware(['Administrator']);

Route::post('/admin/create-batch',[AdminController::class, 'createBatch'])->middleware(['Administrator']);

Route::post("/admin/delete/batch/{id}",[AdminController::class, 'deleteBatch'])->middleware(['Administrator']);

Route::post("/admin/update/batch/{id}",[AdminController::class, 'updateBatch'])->middleware(['Administrator']);

Route::get("/admin/edit-program/{id}",[AdminController::class, 'editProgram'])->middleware(['Administrator']);

Route::post("/admin/edit-post-program/{id}",[AdminController::class,'updateProgram'])->middleware(['Administrator']);

Route::post("/admin/delete-program/{id}",[AdminController::class,'deleteProgram'])->middleware(['Administrator']);

Route::get('/en/Admin-dashboard',[AdminController::class,'AdminDashboard'])->middleware(['Administrator']);

Route::post("/admin/create-code",[AdminController::class, "DiscountCode"])->middleware(['Administrator']);

Route::get("/edit-users/{id}",[AdminController::class, 'editModerator'])->middleware(['Administrator']);

Route::get("/admin/create-course",[AdminController::class, 'createCourse'])->middleware(['Administrator']);

require __DIR__.'/auth.php';
